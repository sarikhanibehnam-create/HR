@echo off
setlocal
cd /d "%~dp0"
set "BEHNOVA_DATA_DIR=%~dp0data"
"%~dp0runtime\python.exe" "%~dp0app\backup.py"
pause
