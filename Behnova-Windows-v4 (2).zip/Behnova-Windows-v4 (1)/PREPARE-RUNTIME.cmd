@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0runtime\pythonw.exe" exit /b 0
if exist "%~dp0runtime" goto incomplete
where tar.exe >nul 2>&1
if errorlevel 1 goto no_tar
if not exist "%~dp0tools\xz\xz.exe" goto missing_tool
if not exist "%~dp0tools\xz\liblzma.dll" goto missing_tool
set "BEHNOVA_RT_STAGE=%~dp0.behnova-runtime-%RANDOM%-%RANDOM%"
echo BEHNOVA: preparing the offline runtime. First launch only; please wait.
echo The XZ decoder is INCLUDED. No download or external xz installation is needed.
powershell.exe -NoProfile -NonInteractive -Command "try { if ((Get-FileHash -LiteralPath 'runtime.tar.xz' -Algorithm SHA256 -ErrorAction Stop).Hash -ne '68d3f71e2369faa2b26b94ad598869fb90ee60954a8648da7f16fb57ef5e9880') { exit 1 }; if ((Get-FileHash -LiteralPath 'tools/xz/xz.exe' -Algorithm SHA256 -ErrorAction Stop).Hash -ne '855aadc2fe3ebc1ecb3b1e38e99dc517dbd12af948ce515cb3749f1b4d5604cf') { exit 1 }; if ((Get-FileHash -LiteralPath 'tools/xz/liblzma.dll' -Algorithm SHA256 -ErrorAction Stop).Hash -ne '4d1e6b60f9909bcf3db171fc4272b13f50bf47fdcb7a68a2941ab0fd6e369ca0') { exit 1 }; exit 0 } catch { exit 1 }"
if errorlevel 1 goto failed
mkdir "%BEHNOVA_RT_STAGE%"
if errorlevel 1 goto failed
echo Step 1 of 3: decompressing with the bundled Windows XZ decoder...
"%~dp0tools\xz\xz.exe" --threads=1 --memlimit-decompress=256MiB --decompress --stdout -- "%~dp0runtime.tar.xz" > "%BEHNOVA_RT_STAGE%\runtime.tar"
if errorlevel 1 goto failed
powershell.exe -NoProfile -NonInteractive -Command "try { $p=Join-Path $env:BEHNOVA_RT_STAGE 'runtime.tar'; if ((Get-FileHash -LiteralPath $p -Algorithm SHA256 -ErrorAction Stop).Hash -ne '79a897d6c757555660ae26a8148578dffb2ceb0ebe7b20bf2ebe217ce0708503') { exit 1 }; exit 0 } catch { exit 1 }"
if errorlevel 1 goto failed
echo Step 2 of 3: extracting the plain TAR, without XZ or network dependencies...
tar.exe -xf "%BEHNOVA_RT_STAGE%\runtime.tar" -C "%BEHNOVA_RT_STAGE%"
if errorlevel 1 goto failed
echo Step 3 of 3: verifying all runtime files...
powershell.exe -NoProfile -NonInteractive -Command "try { $m=Get-Content -LiteralPath 'RUNTIME-SHA256.json' -Raw -ErrorAction Stop | ConvertFrom-Json; foreach ($p in $m.PSObject.Properties) { $f=Join-Path $env:BEHNOVA_RT_STAGE $p.Name; if ((Get-FileHash -LiteralPath $f -Algorithm SHA256 -ErrorAction Stop).Hash -ne $p.Value) { exit 1 } }; exit 0 } catch { exit 1 }"
if errorlevel 1 goto failed
move "%BEHNOVA_RT_STAGE%\runtime" "%~dp0runtime" >nul
if errorlevel 1 goto failed
del "%BEHNOVA_RT_STAGE%\runtime.tar" >nul 2>&1
rd "%BEHNOVA_RT_STAGE%" >nul 2>&1
echo BEHNOVA: runtime verified and ready.
exit /b 0
:incomplete
echo An incomplete runtime folder already exists. No existing files were overwritten.
echo Extract the complete ZIP into a NEW empty folder, or ask IT to check this folder.
echo Do not delete your existing data or tls folders.
pause
exit /b 1
:no_tar
echo Windows tar.exe was not found. Windows 10 build 1803+ or Windows 11 is required.
echo No existing data, passwords or tls were changed. Ask IT to check Windows system tools.
pause
exit /b 1
:missing_tool
echo The INCLUDED XZ decoder is missing. Extract ALL contents of the full ZIP.
echo Do not download or install a separate xz utility.
pause
exit /b 1
:failed
echo Runtime preparation or verification failed. The application was NOT started.
echo Existing data, passwords and tls were not changed.
echo Extract the complete ZIP into a new local writable folder and try again.
echo No existing runtime was deleted. Ask IT to inspect any .behnova-runtime temporary folder.
pause
exit /b 1
