@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0runtime\pythonw.exe" (
  echo Runtime missing. Use Extract All on the entire ZIP.
  pause
  exit /b 1
)
if not exist "%~dp0app\launcher.pyw" (
  echo App missing. Keep app and runtime next to START.cmd.
  pause
  exit /b 1
)
start "" "%~dp0runtime\pythonw.exe" "%~dp0app\launcher.pyw"
exit /b
