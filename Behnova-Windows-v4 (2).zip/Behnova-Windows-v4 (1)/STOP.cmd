@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "%~dp0runtime\pythonw.exe" (
 echo Runtime missing. Extract the full Windows ZIP, without deleting data.
 pause
 exit /b 1
)
if not exist "%~dp0app\stop_server.pyw" (
 echo Stop tool missing. Extract the complete update.
 pause
 exit /b 1
)
start "" "%~dp0runtime\pythonw.exe" "%~dp0app\stop_server.pyw"
