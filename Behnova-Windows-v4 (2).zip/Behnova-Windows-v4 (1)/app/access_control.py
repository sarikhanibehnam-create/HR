"""Server-enforced per-account actions, with backward-compatible legacy account defaults."""
import json
from fastapi import HTTPException
PERMISSIONS={
'employees.read':'مشاهده پرونده کارکنان','employees.create':'ایجاد پرونده','employees.edit':'ویرایش اطلاعات کارکنان','employees.delete':'حذف پرونده با تأیید',
'employment.manage':'ثبت اتمام همکاری و همکاری مجدد','settlement.read':'مشاهده تسویه','settlement.edit':'ویرایش آماده‌سازی، امضا و تحویل مالی','settlement.pay':'ثبت و ویرایش پرداخت',
'reports.read':'مشاهده گزارش‌ها و نمودارها','export.excel':'دریافت Excel','export.pdf':'چاپ و PDF','import.create':'افزودن افراد جدید از Excel','import.update':'به‌روزرسانی افراد موجود از Excel',
'catalog.manage':'مدیریت واحدها و محل‌ها — نیازمند محدوده کل مجموعه','fields.manage':'مدیریت فیلدهای دلخواه — نیازمند محدوده کل مجموعه','audit.read':'مشاهده سابقه تغییرات پرونده‌های مجاز'}
PRESETS={
'hr':['employees.read','employees.create','employees.edit','employment.manage','settlement.read','settlement.edit','reports.read','export.excel','export.pdf','audit.read'],
'finance':['settlement.read','settlement.pay','export.excel','export.pdf'],
'reporter':['employees.read','settlement.read','reports.read','export.excel','export.pdf'],
'viewer':['employees.read','settlement.read','reports.read'],
'operator':['employees.read','employees.create','employees.edit','import.create']}

def permissions(u):
 if u['role']=='admin':return set(PERMISSIONS)
 raw=u['permissions'] if 'permissions' in u.keys() else ''
 if raw:
  try:return set(json.loads(raw))&set(PERMISSIONS)
  except (ValueError,TypeError):return set()
 return {'employees.read','settlement.read','reports.read'}|({'export.excel','export.pdf'} if u['can_export'] else set())

def can(u,key):return key in permissions(u)
def require(u,key):
 if not can(u,key):raise HTTPException(403,'این عملیات در سطح دسترسی حساب شما فعال نیست: '+PERMISSIONS[key])

def scope_lists(u):
 def values(k):
  try:return json.loads(u[k] or '[]') if k in u.keys() else []
  except ValueError:return []
 ds=values('departments_json');ls=values('locations_json')
 if not ds and not ls and not u['scope_all'] and u['department_scope']:ds=[u['department_scope']]
 return ds,ls

def within(u,row):
 if u['role']=='admin' or u['scope_all']:return True
 ds,ls=scope_lists(u)
 return bool(ds or ls) and (not ds or row.get('department','') in ds) and (not ls or row.get('location','') in ls)

def validate_settings(payload,old=None):
 role=payload.get('role',old['role'] if old else 'viewer')
 if role not in ['admin','viewer']:raise ValueError('نقش حساب نامعتبر است.')
 raw=payload.get('permissions',None)
 if raw is not None and (not isinstance(raw,list) or len(raw)>len(PERMISSIONS) or any(not isinstance(k,str) or k not in PERMISSIONS for k in raw) or len(raw)!=len(set(raw))):raise ValueError('فهرست مجوزها نامعتبر است.')
 if raw is not None:
  p=set(raw)
  if p&{'employees.create','employees.edit','employees.delete','employment.manage','reports.read','audit.read','import.create','import.update'} and 'employees.read' not in p:raise ValueError('مجوزهای پرونده، همکاری، گزارش و ورود اکسل به مشاهده پرونده نیاز دارند.')
  for key in p:
   if key.startswith('records.') and key.rsplit('.',1)[-1]!='read' and key.rsplit('.',1)[0]+'.read' not in p:raise ValueError('ثبت، ویرایش، حذف، تأیید و خروجی هر بخش به مشاهده همان بخش نیاز دارد.')
  if p&{'settlement.edit','settlement.pay'} and 'settlement.read' not in p:raise ValueError('ثبت مراحل تسویه به اجازه مشاهده تسویه نیاز دارد.')
 full=payload.get('full_scope',bool(old['scope_all']) if old else False)
 if type(full) is not bool:raise ValueError('محدوده همه مجموعه نامعتبر است.')
 def selection(key,fallback):
  v=payload.get(key,fallback)
  if not isinstance(v,list) or len(v)>200 or any(not isinstance(s,str) or not s.strip() or len(s)>180 for s in v):raise ValueError('واحدها و محل‌های مجاز نامعتبرند.')
  return list(dict.fromkeys(s.strip() for s in v))
 ds0,ls0=scope_lists(old) if old else ([],[])
 ds=selection('departments',ds0);ls=selection('locations',ls0)
 if not ds and payload.get('department_scope'):ds=selection('departments',[payload['department_scope']])
 if role=='admin':full=True
 if not full and not ds and not ls:raise ValueError('حداقل یک واحد یا محل مجاز، یا کل مجموعه را انتخاب کنید.')
 if raw and not full and set(raw)&{'catalog.manage','fields.manage'}:raise ValueError('مدیریت ساختار سراسری نیازمند محدوده کل مجموعه است.')
 disabled=payload.get('disabled',bool(old['disabled']) if old and 'disabled' in old.keys() else False)
 if type(disabled) is not bool:raise ValueError('وضعیت فعال بودن حساب نامعتبر است.')
 return role,raw,full,ds,ls,disabled
