"""Offline, device-bound Ed25519 licenses. Contains NO signing secret or bypass.
Authorization is independent of HR users/passwords and of installation path.
This is software licensing, not tamper-proof protection against local code edits.
"""
from pathlib import Path
from functools import lru_cache
import os,json,base64,hashlib,uuid,ctypes
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from license_public import PUBLIC_KEY_B64
from server_lifecycle import private_directory,write_json
PRODUCT='BEHNOVA'
REQUEST_PREFIX='BEHNOVA-REQUEST-1.'
LICENSE_PREFIX='BEHNOVA-LICENSE-1.'
SIGN_DOMAIN=b'BEHNOVA-OFFLINE-LICENSE-V1\x00'
class ActivationRequired(ValueError):pass

def b64(data):return base64.urlsafe_b64encode(data).decode('ascii').rstrip('=')
def unb64(text):
    if not isinstance(text,str) or not text or len(text)>16000 or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_' for c in text):raise ValueError('Invalid base64')
    return base64.b64decode(text+'='*((-len(text))%4),altchars=b'-_',validate=True)

def _firmware_uuid():
    """Raw SMBIOS type 1 UUID; no shell, WMIC, hostname, IP, disk letter or MAC."""
    try:
        f=ctypes.WinDLL('kernel32',use_last_error=True).GetSystemFirmwareTable
        f.argtypes=[ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32];f.restype=ctypes.c_uint32
        provider=int.from_bytes(b'RSMB','big');n=f(provider,0,None,0)
        if not 8<=n<=1024*1024:return ''
        buf=ctypes.create_string_buffer(n)
        if f(provider,0,buf,n)!=n:return ''
        raw=buf.raw;end=min(len(raw),8+int.from_bytes(raw[4:8],'little'));i=8
        while i+4<=end:
            kind,length=raw[i],raw[i+1]
            if length<4 or i+length>end:break
            if kind==1 and length>=24:
                value=raw[i+8:i+24]
                if value not in (b'\x00'*16,b'\xff'*16):return value.hex()
            if kind==127:break
            stop=raw.find(b'\x00\x00',i+length,end)
            if stop<0:break
            i=stop+2
    except (OSError,ValueError,AttributeError):pass
    return ''

@lru_cache(maxsize=1)
def device_fingerprint():
    if os.name=='nt':
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\Microsoft\Cryptography',0,winreg.KEY_READ|winreg.KEY_WOW64_64KEY) as k:
                guid=str(uuid.UUID(str(winreg.QueryValueEx(k,'MachineGuid')[0])))
        except (OSError,ValueError) as exc:raise ActivationRequired('شناسه پایدار ویندوز خوانده نشد؛ با مسئول IT بررسی کنید. داده و حساب‌ها تغییر نکرده‌اند.') from exc
        material='windows|'+guid+'|'+_firmware_uuid()
    else:
        try:guid=Path('/etc/machine-id').read_text().strip()
        except OSError:guid=''
        if not guid:raise ActivationRequired('شناسه پایدار سیستم موجود نیست.')
        try:hardware=Path('/sys/class/dmi/id/product_uuid').read_text().strip().lower()
        except OSError:hardware=''
        material='linux|'+guid+'|'+hardware
    return hashlib.sha256(b'BEHNOVA-DEVICE-V1\x00'+material.encode('utf-8')).hexdigest()

def request_code(label=''):
    payload={'v':1,'product':PRODUCT,'device':device_fingerprint(),'label':str(label)[:120]}
    return REQUEST_PREFIX+b64(json.dumps(payload,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode())

def verify_license(token):
    try:
        if not isinstance(token,str) or len(token)>16000:raise ValueError()
        token=token.strip()
        if not token.startswith(LICENSE_PREFIX):raise ValueError()
        payload64,sig64=token[len(LICENSE_PREFIX):].split('.')
        payload,signature=unb64(payload64),unb64(sig64)
        if len(signature)!=64:raise ValueError()
        Ed25519PublicKey.from_public_bytes(base64.b64decode(PUBLIC_KEY_B64,validate=True)).verify(signature,SIGN_DOMAIN+payload)
        obj=json.loads(payload)
        if set(obj)!={'v','product','device','license_id','issued_at'} or obj['v']!=1 or obj['product']!=PRODUCT:raise ValueError()
        if not isinstance(obj['device'],str) or len(obj['device'])!=64 or obj['device']!=device_fingerprint():raise ValueError()
        if not isinstance(obj['license_id'],str) or len(obj['license_id'])!=32 or any(c not in '0123456789abcdef' for c in obj['license_id']):raise ValueError()
        if not isinstance(obj['issued_at'],str) or not 10<=len(obj['issued_at'])<=50:raise ValueError()
        return obj
    except ActivationRequired:raise
    except Exception as exc:raise ActivationRequired('مجوز معتبر این کامپیوتر پیدا نشد. کد درخواست همین سیستم باید توسط مالک برنامه فعال شود؛ رمز ادمین جای مجوز را نمی‌گیرد.') from exc

def license_path(base):return Path(base).resolve()/'activation'/'behnova.license'
def require_license(base):
    path=license_path(base)
    try:
        if path.stat().st_size>16000:raise ValueError()
        return verify_license(path.read_text(encoding='utf-8-sig'))
    except ActivationRequired:raise
    except (OSError,UnicodeError,ValueError) as exc:raise ActivationRequired('این سیستم هنوز فعال نشده است. START.cmd را اجرا کنید و کد درخواست را برای مالک برنامه بفرستید. اطلاعات و رمزهای قبلی حفظ شده‌اند.') from exc

def install_license(base,token):
    value=verify_license(token) # MUST precede directory/file creation and all HR access.
    folder=license_path(base).parent;private_directory(folder)
    # Atomic text publication; no database, key, TLS, binding or session modifications.
    import secrets
    target=license_path(base);temp=folder/('.license-'+secrets.token_hex(12)+'.tmp')
    try:
        with temp.open('x',encoding='utf-8') as f:f.write(token.strip());f.flush();os.fsync(f.fileno())
        os.chmod(temp,0o600);os.replace(temp,target)
    finally:temp.unlink(missing_ok=True)
    return value

class LicenseMiddleware:
    def __init__(self,app,base):self.app=app;self.base=base
    async def __call__(self,scope,receive,send):
        if scope['type'] in ('http','websocket') and scope.get('path')!='/api/desktop/stop':
            try:require_license(self.base)
            except ActivationRequired:
                if scope['type']=='websocket':await send({'type':'websocket.close','code':1008});return
                from starlette.responses import JSONResponse
                await JSONResponse({'detail':'فعال‌سازی این سیستم لازم است؛ START.cmd را روی میزبان اجرا کنید.'},status_code=503,headers={'Cache-Control':'no-store'})(scope,receive,send);return
        await self.app(scope,receive,send)
