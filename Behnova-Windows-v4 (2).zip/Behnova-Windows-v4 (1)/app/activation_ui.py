"""One-time activation only. Ephemeral authenticated loopback page; no HR DB is opened."""
import json,secrets,socket,threading,time,webbrowser,os
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from activation_security import require_license,install_license,request_code,ActivationRequired
class ActivationServer:
    def __init__(self,base):
        self.base=Path(base).resolve();self.done=threading.Event();self.token=secrets.token_urlsafe(32)
        self.code=request_code(socket.gethostname());outer=self
        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                super().setup();self.connection.settimeout(5)
            def log_message(self,*args):pass # Never log the capability URL or license token.
            def valid(self,path):return self.headers.get('Host')==outer.host and self.path==('/'+outer.token+'/'+path)
            def reply(self,status,body,content='application/json; charset=utf-8'):
                self.send_response(status);self.send_header('Content-Type',content);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY');self.send_header('Content-Security-Policy',"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; img-src data:; form-action 'none'; frame-ancestors 'none'; base-uri 'none'");self.end_headers();self.wfile.write(body);self.wfile.flush()
            def do_GET(self):
                if not self.valid(''):self.reply(404,b'{}');return
                template=(outer.base/'app/templates/activation.html').read_text(encoding='utf-8')
                self.reply(200,template.replace('__REQUEST_JSON__',json.dumps(outer.code).replace('<','\\u003c')).encode('utf-8'),'text/html; charset=utf-8')
            def do_POST(self):
                if not self.valid('activate') or self.headers.get('Origin')!=outer.origin:self.reply(403,b'{}');return
                try:
                    if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError()
                    size=int(self.headers.get('Content-Length','0'))
                    if not 1<=size<=24000:raise ValueError()
                    value=json.loads(self.rfile.read(size));install_license(outer.base,value['license'])
                except (ActivationRequired,ValueError,KeyError,TypeError,UnicodeError) as exc:
                    self.reply(400,json.dumps({'ok':False,'message':'مجوز پذیرفته نشد؛ فایل مجوز باید توسط مالک برای همین کد درخواست صادر شده باشد.'},ensure_ascii=False).encode());return
                except OSError:
                    self.reply(500,json.dumps({'ok':False,'message':'مجوز معتبر است اما ذخیره نشد. مجوز نوشتن پوشه نصب و فضای دیسک را بررسی کنید.'},ensure_ascii=False).encode());return
                self.reply(200,json.dumps({'ok':True,'message':'فعال‌سازی انجام شد. برنامه در حال راه‌اندازی است؛ این صفحه را می‌توانید ببندید.'},ensure_ascii=False).encode());outer.done.set()
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler);self.server.daemon_threads=True
        self.host='127.0.0.1:'+str(self.server.server_port);self.origin='http://'+self.host;self.url=self.origin+'/'+self.token+'/'
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
    def start(self):self.thread.start()
    def close(self):self.server.shutdown();self.server.server_close();self.thread.join(timeout=3)

def ensure_activation(base):
    try:require_license(base);return
    except ActivationRequired:pass
    server=ActivationServer(base);server.start()
    try:
        # Headless automation receives no interactive bypass; it must already be licensed.
        if os.environ.get('BEHNOVA_NO_BROWSER')=='1':raise ActivationRequired('فعال‌سازی لازم است. برنامه بدون مجوز در حالت بدون مرورگر شروع نمی‌شود.')
        if not webbrowser.open(server.url,new=2):
            if os.name=='nt':
                import ctypes
                ctypes.windll.user32.MessageBoxW(None,'مرورگر خودکار باز نشد. این آدرس را فقط روی همین سیستم در مرورگر باز کنید:\n'+server.url,'BEHNOVA activation',0x40)
            else:print('Activation page (this computer only): '+server.url)
        if not server.done.wait(600):raise ActivationRequired('فعال‌سازی تکمیل نشد. اطلاعات تغییر نکردند؛ برای دریافت کد و واردکردن مجوز، START.cmd را دوباره اجرا کنید.')
        require_license(base)
    finally:server.close()
