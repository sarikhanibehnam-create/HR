from pathlib import Path
from activation_security import require_license, LicenseMiddleware
require_license(Path(__file__).resolve().parent.parent)
import unified_excel
import release_info
import os, sqlite3, secrets, random, time, io, threading, ipaddress, json, unicodedata
from urllib.parse import quote
from security_core import cipher_for, token_hash, new_totp_secret, totp_counter, recovery_codes, recovery_hash
from cryptography.fernet import InvalidToken
from reporting import validate_spec, add_report_sheet
from excel_rows import sparse_rows,has_value
from import_workflow import ImportProblem,parse_excel,make_plan,page_of,fingerprint
from custom_fields import init_registry,schema_for,definitions,normalized_definition,value_for,new_key,template_bytes,MAX_FIELDS
from catalog import KINDS,init_catalog,sync_catalog,valid_name,catalog_rows
from pathlib import Path
from datetime import date, datetime, timedelta, timezone
from collections import defaultdict
from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from werkzeug.security import generate_password_hash, check_password_hash
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import jdatetime
import settlement
import access_control as ac
import workforce
import personnel_records
import vehicle_import
import choice_settings
import record_import
import sys
from decimal import Decimal

ASSET_ROOT = Path(__file__).resolve().parent
ROOT = str(ASSET_ROOT)
DATA_DIR = Path(globals().get('_COMPANY_DATA_DIR') or os.environ.get('BEHNOVA_DATA_DIR', os.environ.get('NAMAA_DATA_DIR', str(ASSET_ROOT / 'data')))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
from restore_support import recover_interrupted
recover_interrupted(DATA_DIR)
if os.name!='nt':os.chmod(DATA_DIR,0o700)
SECRET_PATH = DATA_DIR / 'session.key'
if not SECRET_PATH.exists():
    try:
        with SECRET_PATH.open('x', encoding='utf-8') as f: f.write(secrets.token_hex(48))
        os.chmod(SECRET_PATH, 0o600)
    except FileExistsError: pass
SECRET = os.environ.get('SECRET_KEY') or SECRET_PATH.read_text(encoding='utf-8').strip()
DB = str(DATA_DIR / 'hr.sqlite3')
DESKTOP = os.environ.get('BEHNOVA_DESKTOP') == '1'
SHARED = os.environ.get('BEHNOVA_SHARED') == '1'
CIPHER = cipher_for(DATA_DIR)
SESSION_SECONDS = 4*60*60
IDLE_SECONDS = 30*60
DUMMY_PASSWORD_HASH = generate_password_hash(secrets.token_urlsafe(24))
app = FastAPI(title='BEHNOVA HR', version=str(release_info.SERIAL), docs_url=None, redoc_url=None, openapi_url=None)

def tehran_now(): return datetime.now(timezone(timedelta(hours=3, minutes=30)))
def tehran_today(): return tehran_now().date()
def json_response(_status=200, **data): return JSONResponse(data, status_code=_status)
async def json_data(request: Request):
    try: data = await request.json()
    except Exception: raise HTTPException(400, 'بدنه درخواست باید JSON معتبر باشد.')
    if not isinstance(data, dict): raise HTTPException(400, 'ساختار داده باید یک شیء باشد.')
    return data

def excel_response(buffer, filename):
    if globals().get('_COMPANY_GUID'):
        from company_excel import stamp
        buffer=io.BytesIO(stamp(buffer.getvalue(),_COMPANY_GUID,_COMPANY_NAME))
    return Response(buffer.getvalue(), media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    headers={'Content-Disposition': f'attachment; filename="{filename}"'})

async def maybe_user(request: Request):
    if hasattr(request.state, 'auth_user'): return request.state.auth_user
    sid=request.session.get('sid', '');now=time.time();u=None
    if sid:
        with db() as c:
            row=c.execute('SELECT users.*,sessions.expires,sessions.last_seen FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token_hash=?', (token_hash(sid),)).fetchone()
            if row and not row['disabled'] and row['expires']>now and row['last_seen']>now-IDLE_SECONDS:
                u=row
                if now-row['last_seen']>60:c.execute('UPDATE sessions SET last_seen=? WHERE token_hash=?',(now,token_hash(sid)))
            else:c.execute('DELETE FROM sessions WHERE token_hash=?',(token_hash(sid),))
    if not u:
        request.session.pop('uid',None);request.session.pop('sid',None)
    request.state.auth_user=u
    return u

async def require_user(request: Request):
    u=await maybe_user(request)
    if not u:raise HTTPException(401,'نشست پایان یافته یا دسترسی لغو شده است؛ دوباره وارد شوید.')
    return u

def transaction_user(c,request):
    """Recheck account, session and grants in the same write snapshot (not request cache)."""
    validator=getattr(request.state,'company_origin_validator',None)
    if validator and not validator():raise HTTPException(401,'نشست اصلی پایان یافته است؛ دوباره وارد شوید.')
    now=time.time();row=c.execute('SELECT users.*,sessions.expires,sessions.last_seen FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token_hash=?',(token_hash(request.session.get('sid','')),)).fetchone()
    if not row or row['disabled'] or row['expires']<=now or row['last_seen']<=now-IDLE_SECONDS:raise HTTPException(401,'نشست پایان یافته یا دسترسی لغو شده است؛ دوباره وارد شوید.')
    return row

async def require_export(request: Request):
    u=await require_user(request)
    ac.require(u,'export.excel')
    return u

async def require_admin(request: Request):
    u = await require_user(request)
    if u['role'] != 'admin': raise HTTPException(403, 'این عملیات فقط برای مدیر مجاز است.')
    return u

def permitted(key):
    async def dependency(request:Request):
        u=await require_user(request);ac.require(u,key)
        if key in ['fields.manage','catalog.manage'] and u['role']!='admin' and not u['scope_all']:raise HTTPException(403,'این تنظیم سراسری فقط در محدوده کل مجموعه مجاز است.')
        return u
    return dependency

async def require_data(request:Request):
    u=await require_user(request)
    if not (ac.can(u,'employees.read') or ac.can(u,'settlement.read')):raise HTTPException(403,'دسترسی مشاهده اطلاعات فعال نیست.')
    return u

async def require_importer(request:Request):
    u=await require_user(request)
    if not (ac.can(u,'import.create') or ac.can(u,'import.update')):raise HTTPException(403,'اجازه ورود اکسل ندارید.')
    return u

@app.exception_handler(HTTPException)
async def handle_http_error(request: Request, error: HTTPException):
    return json_response(error=error.detail, _status=error.status_code)

@app.middleware('http')
async def security(request: Request, call_next):
    if request.method in ('POST', 'PUT', 'PATCH', 'DELETE') and not secrets.compare_digest(request.headers.get('X-CSRF-Token', ''), request.session.get('csrf', '!')):
        response = json_response(error='نشست معتبر نیست؛ صفحه را دوباره باز کنید.', _status=403)
    else:
        response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'same-origin'
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Robots-Tag']='noindex, nofollow'
    response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
    if request.url.scheme=='https':response.headers['Strict-Transport-Security']='max-age=31536000'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'" + ("; frame-ancestors 'none'" if DESKTOP else '')
    return response

class BodyLimitMiddleware:
    def __init__(self, app, limit=8*1024*1024): self.app, self.limit = app, limit
    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http' or scope['method'] not in ('POST', 'PUT', 'PATCH'):
            return await self.app(scope, receive, send)
        length = 0; chunks = []
        while True:
            message = await receive()
            if message['type'] == 'http.disconnect': return
            length += len(message.get('body', b''))
            if length > self.limit:
                return await json_response(error='حداکثر اندازه درخواست ۸ مگابایت است.', _status=413)(scope, receive, send)
            chunks.append(message)
            if not message.get('more_body', False): break
        index = 0
        async def replay():
            nonlocal index
            if index < len(chunks):
                item = chunks[index]; index += 1; return item
            return await receive()
        await self.app(scope, replay, send)

FIELDS = [('code', 'کد پرسنلی'), ('name', 'نام و نام خانوادگی'), ('gender', 'جنسیت'), ('birth_date', 'تاریخ تولد'), ('hire_date', 'تاریخ استخدام'), ('education', 'مدرک تحصیلی'), ('major', 'رشته تحصیلی'), ('related', 'ارتباط رشته با شغل'), ('marital', 'وضعیت تأهل'), ('position', 'سمت'), ('department', 'واحد سازمانی'), ('manager', 'مدیر مستقیم'), ('cost_center', 'مرکز هزینه'), ('location', 'محل فعالیت'), ('contract_end', 'تاریخ پایان قرارداد'), ('children', 'تعداد فرزندان'), ('insurance', 'وضعیت بیمه'), ('dependents', 'تعداد افراد تحت پوشش بیمه')]
EXTRA_FIELDS=[('job_code','کد شغل'),('job','شغل'),('org_position_title','عنوان سمت سازمانی'),('org_position','سمت سازمانی'),('insurance_number','شماره بیمه'),('education_history','سوابق تحصیلی'),('field_of_study_title','عنوان رشته')]
SETTLEMENT_FIELDS=settlement.FIELDS
SETTLEMENT_KEYS=settlement.KEYS
FIELDS+=EXTRA_FIELDS+SETTLEMENT_FIELDS
EXTRA_KEYS={key for key,_ in EXTRA_FIELDS}|SETTLEMENT_KEYS
KEYS = [x[0] for x in FIELDS]
DATE_KEYS = ['birth_date', 'hire_date', 'contract_end']+[key for key,_ in SETTLEMENT_FIELDS]
OPTIONS = {'gender': ['زن', 'مرد', 'سایر'], 'education': ['بی سواد و کم سواد', 'زیر دیپلم', 'دیپلم', 'کاردانی', 'کارشناسی', 'کارشناسی ارشد', 'دکتری'], 'related': ['مرتبط', 'نیمه مرتبط', 'غیرمرتبط', 'نامشخص'], 'marital': ['مجرد', 'متأهل'], 'insurance': ['تأمین اجتماعی', 'بیمه خدمات درمانی', 'سایر', 'فاقد بیمه']}
# Only controlled choices are canonicalized; personnel identifiers and free text stay intact.
def option_key(value):
    text=unicodedata.normalize('NFKC',value).translate(str.maketrans({'ي':'ی','ى':'ی','ك':'ک'}))
    ignored='\u200c\u200d\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069\ufeff\u0640'
    return ''.join(c for c in text if not c.isspace() and c not in ignored and unicodedata.category(c)!='Mn')

OPTION_LOOKUP={kind:{option_key(value):value for value in values} for kind,values in OPTIONS.items()}
for kind,aliases in {
    'education':{'فوق دیپلم':'کاردانی','لیسانس':'کارشناسی','فوق لیسانس':'کارشناسی ارشد','دکترا':'دکتری'},
    'marital':{'متاهل':'متأهل'},
    'insurance':{'تامین اجتماعی':'تأمین اجتماعی'},
}.items():
    OPTION_LOOKUP[kind].update({option_key(label):value for label,value in aliases.items()})

def canonical_option(kind,value,choices=None):
    return choice_settings.canonical(kind,value,choices)

login_attempts = defaultdict(list)

from contextlib import contextmanager

@contextmanager
def db():
    c = sqlite3.connect(DB, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    try:
        with c: yield c
    finally: c.close()

def fa_date(d):
    return jdatetime.date.fromgregorian(date=d).strftime('%Y/%m/%d')

def parse_date(s):
    s = str(s or '').strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')).replace('-', '/')
    if not s:
        return ''
    try:
        y, m, d = [int(x) for x in s.split('/')]
        value = jdatetime.date(y, m, d).togregorian() if y < 1700 else date(y, m, d)
        return value.isoformat()
    except Exception:
        raise ValueError('تاریخ نامعتبر؛ نمونه صحیح: ۱۴۰۳/۰۶/۱۵')

def import_columns(header,schema=None):
    schema=schema or current_schema()
    lookup={option_key(label):key for key,label in schema['fields']}
    inactive=set()
    for definition in schema['all_defs']:
        for label in [definition['label']]+definition['aliases']:
            if definition['active']:lookup[option_key(label)]=definition['key']
            else:inactive.add(option_key(label))
    lookup.update({option_key('نام'):'_first_name',option_key('نام خانوادگی'):'_last_name'})
    columns=[];found=set()
    for index,label in enumerate(header):
        if isinstance(label,str) and option_key(label) in inactive:raise ValueError('ستون «'+label+'» غیرفعال است؛ ابتدا آن فیلد را فعال کنید یا ستون را از فایل کنار بگذارید.')
        key=lookup.get(option_key(label)) if isinstance(label,str) else None
        if not key:continue
        if key in found:raise ValueError('ستون تکراری یا معادل تکراری در فایل: '+str(label))
        columns.append((index,key));found.add(key)
    if 'code' not in found:raise ValueError('ستون «کد پرسنلی» لازم است.')
    split={'_first_name','_last_name'}
    if found&split and not split.issubset(found):raise ValueError('برای نام جدا، هر دو ستون «نام» و «نام خانوادگی» را وارد کنید.')
    if 'name' not in found and not split.issubset(found):raise ValueError('ستون «نام و نام خانوادگی» یا دو ستون جداگانه «نام» و «نام خانوادگی» لازم است.')
    return columns,split.issubset(found)

def imported_name(data,split):
    if not split:return
    first=str(data.get('_first_name') if data.get('_first_name') is not None else '').strip()
    last=str(data.get('_last_name') if data.get('_last_name') is not None else '').strip()
    full=str(data.get('name') if data.get('name') is not None else '').strip()
    if not first and not last and full:return
    if not first or not last:raise ValueError('در قالب نام جدا، مقدار هر دو ستون «نام» و «نام خانوادگی» الزامی است.')
    combined=first+' '+last
    if full and option_key(full)!=option_key(combined):raise ValueError('نام کامل با ستون‌های جداگانه «نام» و «نام خانوادگی» مطابقت ندارد.')
    data['name']=full or combined

def validate(data,base_options=None):
    result = {k: str(data.get(k, '') if data.get(k) is not None else '').strip() for k in KEYS}
    for k, v in result.items():
        limit=1000 if k=='education_history' else 180
        if len(v)>limit:raise ValueError('طول '+dict(FIELDS)[k]+' نباید بیشتر از '+str(limit)+' کاراکتر باشد.')
    if not result['code'] or not result['name']:
        raise ValueError('کد پرسنلی و نام الزامی است.')
    for k in DATE_KEYS:
        if k in SETTLEMENT_KEYS and option_key(result[k])==option_key(settlement.MISSING):result[k]=''
        try:result[k] = parse_date(result[k])
        except ValueError as error:raise ValueError(dict(FIELDS)[k]+'؛ '+str(error))
    for k in ['children', 'dependents']:
        s = result[k].translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')) or '0'
        try:
            n = int(s)
            if n < 0 or n > 50:
                raise ValueError()
            result[k] = n
        except:
            raise ValueError('تعداد فرزندان و افراد تحت پوشش باید عدد بین صفر تا ۵۰ باشد.')
    for k in OPTIONS:
        result[k]=canonical_option(k,result[k],base_options[k] if base_options else None)
    today = tehran_today().isoformat()
    if result['birth_date'] and result['birth_date'] > today:
        raise ValueError('تاریخ تولد نمی\u200cتواند در آینده باشد.')
    if result['hire_date'] and result['hire_date'] > today:
        raise ValueError('تاریخ استخدام نمی\u200cتواند در آینده باشد.')
    if result['hire_date'] and result['birth_date'] and (result['hire_date'] < result['birth_date']):
        raise ValueError('تاریخ استخدام نمی\u200cتواند قبل از تولد باشد.')
    return result

def current_schema(c=None):
    if c is None:
        with db() as connection:return current_schema(connection)
    result=schema_for(c,FIELDS,DATE_KEYS,choice_settings.choices(c),option_key)
    revision=choice_settings.signature(c)
    if revision:
        import hashlib
        result['revision']=hashlib.sha256((result['revision']+revision).encode()).hexdigest()
    return result

def schema_metadata(schema):
    return dict(fields=schema['fields'],options=schema['options'],custom_fields=schema['defs'],schema_revision=schema['revision'])

def employee_values(payload,schema,existing=None,importing=False):
    payload=dict(payload)
    if existing:
        for key in SETTLEMENT_KEYS:
            if key not in payload:payload[key]=existing.get(key,'')
    result=validate(payload,schema['options'])
    for definition in schema['defs']:
        key=definition['key'];value=payload.get(key,existing.get(key,'') if existing else '')
        result[key]=value_for(value,definition,parse_date,option_key,required=not (importing and key not in payload))
    return result

def check_schema(payload,schema):
    if payload.get('schema_revision') is not None and payload['schema_revision']!=schema['revision']:
        raise ImportProblem('تعریف فیلدها تغییر کرده است؛ صفحه را تازه‌سازی و دوباره بررسی کنید.',status=409)

@app.get('/api/custom-fields',dependencies=[Depends(permitted('fields.manage'))])
async def get_custom_fields(request:Request):
    schema=current_schema();return json_response(rows=schema['all_defs'],**schema_metadata(schema))

@app.post('/api/custom-fields',dependencies=[Depends(permitted('fields.manage'))])
async def create_custom_field(request:Request):
    payload=await json_data(request)
    try:
        with db() as c:
            c.execute('BEGIN IMMEDIATE');schema=current_schema(c);check_schema(payload,schema)
            if len(schema['all_defs'])>=MAX_FIELDS:raise ValueError('حداکثر ۵۰ فیلد دلخواه، با احتساب غیرفعال‌ها، قابل ساخت است.')
            value=normalized_definition(payload,None,schema['all_defs'],[label for _,label in FIELDS]+['نام','نام خانوادگی','گروه سنی','بازه سابقه همکاری','وضعیت قرارداد'],option_key);key=new_key()
            c.execute(f"ALTER TABLE employees ADD COLUMN {key} TEXT NOT NULL DEFAULT ''")
            c.execute('INSERT INTO custom_fields(key,label,kind,options,required,active,position,aliases) VALUES(?,?,?,?,?,?,?,?)',(key,value['label'],value['kind'],json.dumps(value['options'],ensure_ascii=False),int(value['required']),int(value['active']),value['position'],json.dumps(value['aliases'],ensure_ascii=False)))
            audit(request,c,'ساخت فیلد دلخواه',value['label'])
        return json_response(ok=True,key=key,**schema_metadata(current_schema()))
    except ImportProblem as error:return json_response(error=str(error),_status=error.status)
    except ValueError as error:return json_response(error=str(error),_status=400)

@app.put('/api/custom-fields/{key}',dependencies=[Depends(permitted('fields.manage'))])
async def change_custom_field(request:Request,key:str):
    payload=await json_data(request)
    try:
        with db() as c:
            c.execute('BEGIN IMMEDIATE');schema=current_schema(c);check_schema(payload,schema);old=next((item for item in schema['all_defs'] if item['key']==key),None)
            if old is None:return json_response(error='فیلد پیدا نشد.',_status=404)
            if type(payload.get('version')) is not int or payload['version']!=old['version']:return json_response(error='تعریف فیلد تغییر کرده است؛ تازه‌سازی کنید.',_status=409)
            merged={**old,**payload};value=normalized_definition(merged,old,schema['all_defs'],[label for _,label in FIELDS]+['نام','نام خانوادگی','گروه سنی','بازه سابقه همکاری','وضعیت قرارداد'],option_key)
            if old['kind']=='select':
                used={r[0] for r in c.execute(f"SELECT DISTINCT {key} FROM employees WHERE {key}<>''")}
                if used-set(value['options']):raise ValueError('گزینه‌ای که در پرونده‌ها استفاده شده قابل حذف یا تغییر نام نیست؛ گزینه‌های جدید را اضافه کنید.')
            c.execute('UPDATE custom_fields SET label=?,options=?,required=?,active=?,position=?,aliases=?,version=version+1 WHERE key=?',(value['label'],json.dumps(value['options'],ensure_ascii=False),int(value['required']),int(value['active']),value['position'],json.dumps(value['aliases'],ensure_ascii=False),key))
            audit(request,c,'ویرایش فیلد دلخواه',old['label']+' ← '+value['label']+('؛ فعال' if value['active'] else '؛ غیرفعال، اطلاعات محفوظ'))
        return json_response(ok=True,**schema_metadata(current_schema()))
    except ImportProblem as error:return json_response(error=str(error),_status=error.status)
    except ValueError as error:return json_response(error=str(error),_status=400)

def public_user(u):
    result={k:u[k] for k in ['id','username','name','role']}
    result.update(permissions=sorted(ac.permissions(u)),departments=ac.scope_lists(u)[0],locations=ac.scope_lists(u)[1],disabled=bool(u['disabled']),can_export=bool(ac.permissions(u)&{'export.excel','export.pdf'}), department_scope=u['department_scope'],full_scope=u['role']=='admin' or bool(u['scope_all']), mfa_enabled=bool(u['mfa_secret']))
    return result

def scope_for(u):return '' if u['role']=='admin' or u['scope_all'] or ac.scope_lists(u)[0] or ac.scope_lists(u)[1] else '__BEHNOVA_NO_SCOPE__'

def create_session(request, c, ident):
    sid=secrets.token_urlsafe(40);now=time.time()
    c.execute('DELETE FROM sessions WHERE expires<? OR last_seen<?',(now,now-IDLE_SECONDS))
    c.execute('INSERT INTO sessions(token_hash,user_id,created,last_seen,expires) VALUES(?,?,?,?,?)',(token_hash(sid),ident,now,now,now+SESSION_SECONDS))
    request.session.clear();request.session.update(uid=ident,sid=sid,csrf=secrets.token_urlsafe(32))

def reauthenticate(u,password):
    from company_context import origin_identity
    identity=origin_identity()
    if identity and str(u['username']).startswith('__behnova_owner_'):
        original,actor=identity
        return original.reauthenticate(actor,password)
    now=time.time();key='reauth:'+str(u['id'])
    with db() as c:
        c.execute('DELETE FROM login_failures WHERE created<?',(now-900,))
        count=c.execute('SELECT COUNT(*) FROM login_failures WHERE key=? AND created>?',(key,now-300)).fetchone()[0]
        if count>=5:raise HTTPException(429,'تلاش تأیید بیش از حد؛ پنج دقیقه صبر کنید.')
        valid=check_password_hash(u['password_hash'],str(password)[:200])
        if not valid:c.execute('INSERT INTO login_failures(key,created) VALUES(?,?)',(key,now))
        else:c.execute('DELETE FROM login_failures WHERE key=?',(key,))
    return valid

def failed_login(c,ip,username):
    c.executemany('INSERT INTO login_failures(key,created) VALUES(?,?)',[("ip:"+ip,time.time()),("user:"+username,time.time())])

def verify_mfa(c,u,code):
    if not u['mfa_secret']:return True
    try:secret=CIPHER.decrypt(u['mfa_secret'].encode()).decode()
    except InvalidToken:return False
    step=totp_counter(secret,code,u['mfa_counter'])
    if step is not None:
        c.execute('UPDATE users SET mfa_counter=? WHERE id=?',(step,u['id']));return True
    hashes=json.loads(u['recovery_hashes'] or '[]');candidate=recovery_hash(code)
    for existing in hashes:
        if secrets.compare_digest(existing,candidate):
            hashes.remove(existing);c.execute('UPDATE users SET recovery_hashes=? WHERE id=?',(json.dumps(hashes),u['id']));return True
    return False

def audit(request: Request, c, action, detail=''):
    c.execute('INSERT INTO audit(user_id,action,detail,created_at) VALUES(?,?,?,?)', (request.session.get('uid'), action, detail, tehran_now().isoformat(timespec='seconds')))

@app.get('/')
async def index(request: Request):
    return HTMLResponse((ASSET_ROOT / 'templates' / 'index.html').read_text(encoding='utf-8'))

@app.get('/api/session')
async def get_session(request: Request):
    u=await maybe_user(request)
    if 'csrf' not in request.session:request.session['csrf']=secrets.token_urlsafe(32)
    with db() as c:needs_setup=not bool(c.execute('SELECT 1 FROM users LIMIT 1').fetchone())
    return json_response(user=public_user(u) if u else None,csrf=request.session['csrf'],version=app.version,**(schema_metadata(workforce.public_schema(current_schema(),u)) if u else dict(fields=FIELDS,options=OPTIONS,custom_fields=[],schema_revision=None)),today=fa_date(tehran_today()),desktop=DESKTOP,shared=SHARED,can_stop=DESKTOP and loopback(request),needs_setup=needs_setup)

@app.post('/api/login')
async def login(request: Request):
    d=await json_data(request);ip=request.client.host if request.client else 'unknown';username=str(d.get('username','')).strip()[:80];now=time.time()
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute('DELETE FROM login_failures WHERE created<?',(now-900,))
        counts=[c.execute('SELECT COUNT(*) FROM login_failures WHERE key=? AND created>?',(key,now-300)).fetchone()[0] for key in ['ip:'+ip,'user:'+username]]
        if max(counts)>=10:return json_response(error='تلاش بیش از حد؛ پنج دقیقه دیگر دوباره امتحان کنید.',_status=429)
        u=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
        valid=check_password_hash(u['password_hash'] if u else DUMMY_PASSWORD_HASH,str(d.get('password',''))[:200])
        if not u or u['disabled'] or not valid:
            failed_login(c,ip,username);return json_response(error='اطلاعات ورود نادرست است.',_status=401)
        if u['mfa_secret'] and not str(d.get('otp','')).strip():
            failed_login(c,ip,username);return json_response(error='کد تأیید دومرحله‌ای یا کد بازیابی را وارد کنید.',otp_required=True,_status=401)
        if not verify_mfa(c,u,str(d.get('otp',''))):
            failed_login(c,ip,username);return json_response(error='اطلاعات ورود نادرست است.',_status=401)
        c.execute('DELETE FROM login_failures WHERE key=?',('user:'+username,))
        create_session(request,c,u['id']);audit(request,c,'ورود به سامانه')
    return json_response(user=public_user(u),csrf=request.session['csrf'])

@app.post('/api/logout')
async def logout(request: Request):
    with db() as c:
        c.execute('DELETE FROM import_previews WHERE session_id=?',(token_hash(request.session.get('sid','')),))
        c.execute('DELETE FROM vehicle_import_previews WHERE session_id=?',(token_hash(request.session.get('sid','')),))
        c.execute('DELETE FROM record_import_previews WHERE session_id=?',(token_hash(request.session.get('sid','')),))
        c.execute('DELETE FROM unified_excel_previews WHERE session_id=?',(token_hash(request.session.get('sid','')),))
        c.execute('DELETE FROM sessions WHERE token_hash=?',(token_hash(request.session.get('sid','')),))
    request.session.clear();return json_response(ok=True)

@app.get('/api/employees',dependencies=[Depends(require_data)])
async def employees(request:Request):
    user=await require_user(request);scope=scope_for(user)
    with db() as c:
        c.execute('BEGIN');schema=current_schema(c);rows=[dict(row) for row in c.execute("SELECT * FROM employees WHERE (?='' OR department=?) ORDER BY id DESC",(scope,scope))]
    rows=[row for row in rows if ac.within(user,row)];workforce.enrich(rows)
    today=tehran_today();active=set(schema['keys'])
    for row in rows:
        for date_key in DATE_KEYS:row[date_key+'_iso']=row.get(date_key,'')
        row['hire_date_iso']=row['hire_date']
        for key in SETTLEMENT_KEYS:row[key+'_iso']=row.get(key,'')
        for source,target in [('birth_date','age'),('hire_date','tenure')]:row[target]=round((today-date.fromisoformat(row[source])).days/365.2425,1) if row[source] else None
        row['remaining_days']=(date.fromisoformat(row['contract_end'])-today).days if row['contract_end'] else None
        if row.get('employment_periods'):
            ps=row['employment_periods'];row['tenure']=round(sum(max(0,((min(date.fromisoformat(p['end_date']),today) if p['end_date'] else today)-date.fromisoformat(p['start_date'])).days) for p in ps)/365.2425,1) if all(p['start_date'] for p in ps) else None
        for key in schema['dates']:row[key]=fa_date(date.fromisoformat(row[key])) if row.get(key) else ''
        for key in list(row):
            if key.startswith('cf_') and key not in active:del row[key]
    return json_response(rows=workforce.public_rows(rows,user),**schema_metadata(workforce.public_schema(schema,user)))

@app.post('/api/employees',dependencies=[Depends(permitted('employees.create'))])
async def add_employee(request:Request):
    payload=await json_data(request)
    try:
        with db() as c:
            c.execute('BEGIN IMMEDIATE');schema=current_schema(c);check_schema(payload,schema);values=employee_values(payload,schema);u=await require_user(request);workforce.check_employee_values(u,None,values,creating=True);values['id']=workforce.reserve_id(c);keys=['id']+schema['keys']
            c.execute(f"INSERT INTO employees({','.join(keys)}) VALUES({','.join('?' for _ in keys)})",[values[key] for key in keys]);audit(request,c,'ثبت پرسنل',values['code']);workforce.capture(c,u['id'],'ایجاد پرونده',None,dict(c.execute('SELECT * FROM employees WHERE id=?',(values['id'],)).fetchone()));sync_catalog(c)
        return json_response(ok=True)
    except ImportProblem as error:return json_response(error=str(error),_status=error.status)
    except ValueError as error:return json_response(error=str(error),_status=400)
    except sqlite3.IntegrityError:return json_response(error='کد پرسنلی تکراری است.',_status=409)

@app.put('/api/employees/{ident}',dependencies=[Depends(permitted('employees.edit'))])
async def update_employee(request:Request,ident:int):
    payload=await json_data(request)
    try:revision=int(payload.get('version',0))
    except (TypeError,ValueError):revision=0
    if revision<1:return json_response(error='نسخه پرونده مشخص نیست؛ اطلاعات را تازه‌سازی کنید.',_status=409)
    try:
        with db() as c:
            c.execute('BEGIN IMMEDIATE');schema=current_schema(c);check_schema(payload,schema);old=c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone()
            if old is None or old['version']!=revision:return json_response(error='پرونده تغییر کرده یا حذف شده است؛ تازه‌سازی کنید و دوباره ویرایش کنید.',_status=409)
            values=employee_values(payload,schema,dict(old));u=await require_user(request);workforce.check_employee_values(u,dict(old),values);keys=schema['keys']
            c.execute(f"UPDATE employees SET {','.join(key+'=?' for key in keys)},version=version+1 WHERE id=? AND version=?",[values[key] for key in keys]+[ident,revision]);audit(request,c,'ویرایش پرسنل',values['code']);workforce.capture(c,u['id'],'ویرایش پرونده',dict(old),dict(c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone()));sync_catalog(c)
        return json_response(ok=True)
    except ImportProblem as error:return json_response(error=str(error),_status=error.status)
    except ValueError as error:return json_response(error=str(error),_status=400)
    except sqlite3.IntegrityError:return json_response(error='کد پرسنلی تکراری است.',_status=409)

async def delete_records(request,ids,d):
    if not isinstance(ids,list) or not ids or len(ids)>5000 or any(type(x)!=int for x in ids) or len(set(ids))!=len(ids):return json_response(error='انتخاب حذف نامعتبر است.',_status=400)
    if d.get('confirmation')!=f'DELETE {len(ids)}':return json_response(error='تأیید تعداد رکوردهای حذف لازم است.',_status=400)
    u=await require_user(request);ac.require(u,'employees.delete')
    if not reauthenticate(u,d.get('password','')):return json_response(error='رمز عبور مدیر نادرست است.',_status=403)
    marks=','.join('?' for _ in ids)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        rows=c.execute(f'SELECT * FROM employees WHERE id IN ({marks})',ids).fetchall()
        if any(not ac.within(u,dict(row)) for row in rows):raise HTTPException(403,'حذف خارج از محدوده مجاز است.')
        if len(rows)!=len(ids):return json_response(error='برخی پرونده‌ها تغییر کرده یا حذف شده‌اند؛ تازه‌سازی کنید.',_status=409)
        for row in rows:workforce.capture(c,u['id'],'حذف تأییدشده پرونده',dict(row),None)
        c.execute(f'DELETE FROM employees WHERE id IN ({marks})',ids)
        audit(request,c,'حذف تأییدشده پرسنل',f'{len(ids)} نفر؛ کدها: '+','.join(r['code'] for r in rows[:50]))
    return json_response(ok=True,deleted=len(ids))

@app.delete('/api/employees/{ident}',dependencies=[Depends(permitted('employees.delete'))])
async def delete_employee(request:Request,ident:int):return await delete_records(request,[ident],await json_data(request))

@app.post('/api/employees/bulk-delete',dependencies=[Depends(permitted('employees.delete'))])
async def bulk_delete(request:Request):
    d=await json_data(request);return await delete_records(request,d.get('ids'),d)

def workbook_response(rows, filename, report=None, columns=None,schema=None):
    schema=schema or current_schema();active_fields=schema['fields']
    selected_fields=[(key,dict(active_fields)[key]) for key in columns] if columns else active_fields
    selected_keys=[key for key,_ in selected_fields]
    custom_kinds={item['key']:item['kind'] for item in schema['defs']}
    w = openpyxl.Workbook()
    w.properties.creator = 'BEHNOVA'
    w.properties.title = 'BEHNOVA — گزارش منابع انسانی'
    s = w.active
    s.title = 'پرسنل'
    s.sheet_view.rightToLeft = True
    s.append([label for _, label in selected_fields])
    for row_number,r in enumerate(rows,2):
        vals=[]
        for k in selected_keys:
            v=r.get(k,'')
            if k in schema['dates'] and v and '-' in str(v):v=fa_date(date.fromisoformat(v))
            if custom_kinds.get(k)=='number' and v and len(Decimal(v).as_tuple().digits)<=15:v=float(v) if '.' in v else int(v)
            if k in SETTLEMENT_KEYS and not v:v=settlement.MISSING
            vals.append(v)
        s.append(vals)
        for col_number,value in enumerate(vals,1):
            if isinstance(value,str):s.cell(row_number,col_number).data_type='s'
            if selected_keys[col_number-1] in ['code','job_code','insurance_number'] or custom_kinds.get(selected_keys[col_number-1]) in ['text','date','select'] or (custom_kinds.get(selected_keys[col_number-1])=='number' and isinstance(value,str)):s.cell(row_number,col_number).number_format='@'
            if selected_keys[col_number-1]=='education_history':s.cell(row_number,col_number).alignment=Alignment(horizontal='right',wrap_text=True)
    for cell in s[1]:
        cell.data_type='s'
        cell.font = Font(color='FFFFFF', bold=True)
        cell.fill = PatternFill('solid', fgColor='12665C')
        cell.alignment = Alignment(horizontal='right')
    for col in s.columns:
        s.column_dimensions[col[0].column_letter].width = 24
    s.freeze_panes = 'A2'
    s.auto_filter.ref = s.dimensions
    if report:
        report_rows=[dict(row) for row in rows]
        for row in report_rows:
            for key in set(schema['dates'])-set(['birth_date','hire_date','contract_end']):
                if row.get(key):row[key]=fa_date(date.fromisoformat(row[key]))
        add_report_sheet(w,report_rows,report,active_fields,tehran_today(),fa_date(tehran_today()))
    if rows and 'employment_periods' in rows[0] and (columns is None or set(columns)==set(schema['keys'])):
        status_sheet=w.create_sheet('وضعیت همکاری');status_sheet.sheet_view.rightToLeft=True
        status_sheet.append(['کد پرسنلی','نام و نام خانوادگی','وضعیت همکاری امروز','شروع آخرین دوره — شمسی','اتمام مؤثر آخرین دوره — شمسی','تعداد دوره‌ها'])
        for person in rows:
            periods=person['employment_periods'];last=periods[-1] if periods else {}
            status_sheet.append([person['code'],person['name'],person.get('employment_state_label',''),last.get('start_fa') or 'ثبت نشده',last.get('end_fa') or 'ثبت نشده',len(periods)])
        for status_row in status_sheet:
            for cell in status_row:
                if isinstance(cell.value,str):cell.data_type='s';cell.number_format='@'
                cell.alignment=Alignment(horizontal='right',wrap_text=True)
        for col in status_sheet.columns:status_sheet.column_dimensions[col[0].column_letter].width=30
        status_sheet.freeze_panes='A2';status_sheet.auto_filter.ref=status_sheet.dimensions
        for cell in status_sheet[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='155F51')
    b = io.BytesIO()
    w.save(b)
    b.seek(0)
    return excel_response(b, filename)

@app.get('/api/template', dependencies=[Depends(require_user)])
async def template(request: Request):
    filename='BEHNOVA-Excel-Template.xlsx'
    schema=workforce.public_schema(current_schema(),await require_data(request))
    return excel_response(io.BytesIO(template_bytes(schema,schema['options'])),filename)

@app.post('/api/export', dependencies=[Depends(require_export)])
async def export(request: Request):
    payload=await json_data(request)
    ids=payload.get('ids',[])
    u=await require_user(request);ac.require(u,'employees.read');
    if isinstance(payload.get('report_range'),dict) and payload['report_range'].get('basis') in SETTLEMENT_KEYS:ac.require(u,'settlement.read')
    schema=workforce.public_schema(current_schema(),u);keys=schema['keys']
    try:check_schema(payload,schema)
    except ImportProblem as error:return json_response(error=str(error),_status=error.status)
    columns=payload.get('columns')
    if columns is not None and (not isinstance(columns,list) or not 1<=len(columns)<=len(keys) or any(not isinstance(key,str) or key not in keys for key in columns) or len(set(columns))!=len(columns)):
        return json_response(error='حداقل یک ستون معتبر و بدون تکرار انتخاب کنید.',_status=400)
    report=None
    if payload.get('report') is not None:
        ac.require(u,'reports.read')
        try:report=validate_spec(payload['report'],schema['fields'])
        except ValueError as e:return json_response(error=str(e),_status=400)
    if not isinstance(ids, list) or len(ids) > 10000 or any((type(x) != int for x in ids)):
        return json_response(error='انتخاب نامعتبر است.', _status=400)
    u=await require_user(request);scope=scope_for(u);selected=set(ids)
    with db() as c:
        rows=[dict(r) for r in c.execute("SELECT * FROM employees WHERE (?='' OR department=?) ORDER BY id DESC",(scope,scope)) if r['id'] in selected and ac.within(u,dict(r))]
        if len(rows)!=len(selected):return json_response(error='برخی رکوردها خارج از محدوده دسترسی شما هستند.',_status=403)
        audit(request, c, 'دریافت خروجی اکسل', str(len(rows)))
    try:rows=workforce.filter_export(rows,payload)
    except ValueError as e:return json_response(error=str(e),_status=400)
    order={ident:i for i,ident in enumerate(ids)}
    rows.sort(key=lambda row:order[row['id']])
    return workbook_response(rows,'BEHNOVA-HR-report.xlsx',report,columns,schema)

@app.post('/api/settlements/validate-filters',dependencies=[Depends(require_user)])
async def validate_settlement_filters(request:Request):
    try:
        f=settlement.validate_filters(await json_data(request),parse_date)
        return json_response(filters=f,from_fa=fa_date(date.fromisoformat(f['from'])) if f['from'] else '',to_fa=fa_date(date.fromisoformat(f['to'])) if f['to'] else '')
    except ValueError as error:return json_response(error=str(error),_status=400)

@app.post('/api/settlements/export',dependencies=[Depends(require_export)])
async def export_settlements(request:Request):
    payload=await json_data(request);ids=payload.get('ids')
    if not isinstance(ids,list) or len(ids)>10000 or any(type(x) is not int for x in ids) or len(set(ids))!=len(ids):return json_response(error='انتخاب افراد نامعتبر است.',_status=400)
    try:f=settlement.validate_filters(payload.get('filters',{}),parse_date)
    except ValueError as error:return json_response(error=str(error),_status=400)
    u=await require_user(request);ac.require(u,'settlement.read');scope=scope_for(u);chosen=set(ids)
    with db() as c:
        rows=[dict(r) for r in c.execute("SELECT * FROM employees WHERE (?='' OR department=?) ORDER BY id DESC",(scope,scope)) if r['id'] in chosen and ac.within(u,dict(r))]
        if len(rows)!=len(chosen):return json_response(error='برخی افراد خارج از محدوده دسترسی شما هستند.',_status=403)
        workforce.enrich(rows,c);rows=[r for r in rows if r['settlement_eligible'] and settlement.matches(r,f)]
        if not rows:return json_response(error='فرد دارای اتمام همکاری مؤثر در این محدوده وجود ندارد.',_status=400)
        order={ident:i for i,ident in enumerate(ids)};rows.sort(key=lambda r:order[r['id']]);audit(request,c,'دریافت گزارش پیگیری تسویه',str(len(rows)))
    context_parts=[]
    for ident,key,label,_ in settlement.STAGES:
        flag=f['stages'].get(key,'')
        if flag:context_parts.append(label+': '+('تاریخ ثبت شده' if flag=='registered' else settlement.MISSING))
    if f['latest']:context_parts.append('آخرین مرحله: '+next((label for ident,_,label,_ in settlement.STAGES if ident==f['latest']),settlement.MISSING))
    if f['from'] or f['to']:context_parts.append(dict(settlement.FIELDS)[f['date_stage']]+': '+(fa_date(date.fromisoformat(f['from'])) if f['from'] else 'بدون حد شروع')+' تا '+(fa_date(date.fromisoformat(f['to'])) if f['to'] else 'بدون حد پایان'))
    if f['search']:context_parts.append('جست‌وجو: '+f['search'])
    context='فقط افراد دارای اتمام همکاری ثبت‌شده و مؤثر | '+(' | '.join(context_parts) or 'همه مراحل؛ افراد انتخاب‌شده در محدوده مجاز')
    raw=settlement.workbook_bytes(rows,fa_date,tehran_today(),context,dict(current_schema()['fields']))
    return excel_response(io.BytesIO(raw),'BEHNOVA-Settlement-report.xlsx')

@app.post('/api/validate-hire-range',dependencies=[Depends(require_user)])
async def validate_hire_range(request:Request):
    payload=await json_data(request)
    try:
        lower=parse_date(payload.get('from'));upper=parse_date(payload.get('to'))
        for value in [payload.get('from'),payload.get('to')]:
            normalized=str(value or '').strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')).replace('-','/')
            if normalized and int(normalized.split('/')[0])>=1700:raise ValueError('بازه را با تاریخ شمسی وارد کنید؛ نمونه ۱۴۰۳/۰۱/۰۱.')
        if lower and upper and lower>upper:raise ValueError('تاریخ شروع نباید بعد از تاریخ پایان باشد.')
    except ValueError as error:return json_response(error=str(error),_status=400)
    return json_response(from_iso=lower,to_iso=upper,from_fa=fa_date(date.fromisoformat(lower)) if lower else '',to_fa=fa_date(date.fromisoformat(upper)) if upper else '')

# Every upload only produces a preview. Personnel writes require a separate confirmation.
@app.post('/api/import',dependencies=[Depends(require_importer)])
@app.post('/api/import/preview',dependencies=[Depends(require_importer)])
async def preview_import(request:Request):
    form=await request.form();file=form.get('file')
    if not file or not str(getattr(file,'filename','')).lower().endswith('.xlsx'):return json_response(error='یک فایل اکسل با پسوند xlsx انتخاب کنید.',_status=400)
    unknown=[]
    try:
        raw=await file.read();schema=current_schema()
        def validate_import(data):
            try:return employee_values(data,schema,importing=True)
            except choice_settings.UnknownChoice as e:
                item=choice_settings.unknown_payload(e)
                if len(unknown)<100 and item not in unknown:unknown.append(item)
                raise
        parsed,present=parse_excel(raw,lambda header:import_columns(header,schema),imported_name,validate_import,schema['dates'])
        token=secrets.token_urlsafe(32);owner=request.session['uid'];session=token_hash(request.session['sid']);expires=time.time()+600
        with db() as c:
            c.execute('BEGIN IMMEDIATE')
            if current_schema(c)['revision']!=schema['revision']:raise ImportProblem('فیلدها هنگام بررسی تغییر کرده‌اند؛ دوباره بررسی کنید.',status=409)
            actor=transaction_user(c,request)
            for entry in parsed:
                candidate=c.execute('SELECT * FROM employees WHERE code=?',(entry['value']['code'],)).fetchone()
                if candidate and not ac.within(actor,dict(candidate)):raise HTTPException(403,'فایل شامل پرونده خارج از محدوده مجاز است.')
            plan=make_plan(c,parsed,present,form.get('mode','new'),schema['keys'],schema['fields'],EXTRA_KEYS|{item['key'] for item in schema['defs']})
            actor=transaction_user(c,request)
            for record in plan['records']:
                old_row=c.execute('SELECT * FROM employees WHERE code=?',(record['value']['code'],)).fetchone()
                workforce.check_employee_values(actor,dict(old_row) if old_row else None,record['value'],creating=record['status']=='new',importing=True)
            for record,item in zip(plan['records'],plan['items']):
                try:
                    for definition in schema['defs']:value_for(record['value'][definition['key']],definition,parse_date,option_key)
                except ValueError as error:raise ImportProblem('هیچ ردیفی ذخیره نشد.',[f"ردیف {item['line']}: {error}"])
            plan['schema_revision']=schema['revision'];plan['date_keys']=schema['dates']
            c.execute('DELETE FROM import_previews WHERE expires<?',(time.time(),))
            if c.execute('SELECT COUNT(*) FROM import_previews').fetchone()[0]>=16:raise ImportProblem('پیش‌نمایش‌های در انتظار زیاد است؛ چند دقیقه دیگر تلاش کنید.',status=429)
            # Keep at most two previews per account. Payloads are encrypted at rest.
            old=c.execute('SELECT token_hash FROM import_previews WHERE user_id=? ORDER BY expires DESC',(owner,)).fetchall()
            for item in old[1:]:c.execute('DELETE FROM import_previews WHERE token_hash=?',(item['token_hash'],))
            c.execute('INSERT INTO import_previews VALUES(?,?,?,?,?)',(token_hash(token),owner,session,expires,CIPHER.encrypt(json.dumps(plan,ensure_ascii=False).encode())))
        return json_response(preview_token=token,expires_in=600,**page_of(plan))
    except ImportProblem as error:return json_response(error=str(error),errors=error.errors,unknown_choices=unknown if (await require_user(request))['role']=='admin' else [],_status=error.status)
    except (ValueError,StopIteration) as error:return json_response(error=str(error) or 'فایل خالی است.',_status=400)
    except HTTPException:raise
    except Exception:return json_response(error='فایل اکسل قابل خواندن نیست؛ از فایل الگو استفاده کنید.',_status=400)

def owned_preview(c,request,token):
    if not isinstance(token,str) or not 20<=len(token)<=100:raise ImportProblem('شناسه پیش‌نمایش نامعتبر است.',status=400)
    item=c.execute('SELECT * FROM import_previews WHERE token_hash=? AND user_id=? AND session_id=? AND expires>?',(token_hash(token),request.session['uid'],token_hash(request.session['sid']),time.time())).fetchone()
    if not item:raise ImportProblem('پیش‌نمایش منقضی یا لغو شده، قبلاً ثبت شده، یا به این نشست تعلق ندارد. فهرست را تازه‌سازی و فایل را دوباره بررسی کنید.',status=409)
    try:return json.loads(CIPHER.decrypt(item['payload']))
    except (InvalidToken,ValueError):raise ImportProblem('پیش‌نمایش قابل خواندن نیست؛ فایل را دوباره بررسی کنید.',status=409)

@app.get('/api/import/preview/{token}',dependencies=[Depends(require_importer)])
async def import_preview_page(request:Request,token:str,page:int=1):
    try:
        with db() as c:plan=owned_preview(c,request,token)
        return json_response(**page_of(plan,page))
    except ImportProblem as error:return json_response(error=str(error),_status=error.status)

@app.delete('/api/import/preview/{token}',dependencies=[Depends(require_importer)])
async def cancel_import_preview(request:Request,token:str):
    with db() as c:c.execute('DELETE FROM import_previews WHERE token_hash=? AND user_id=? AND session_id=?',(token_hash(token),request.session['uid'],token_hash(request.session['sid'])))
    return json_response(ok=True)

@app.post('/api/import/commit',dependencies=[Depends(require_importer)])
async def commit_import(request:Request):
    payload=await json_data(request)
    if payload.get('confirm') is not True:return json_response(error='تأیید صریح پیش‌نمایش لازم است.',_status=400)
    try:
        with db() as c:
            c.execute('BEGIN IMMEDIATE');plan=owned_preview(c,request,payload.get('token'));schema=current_schema(c);keys=schema['keys']
            if plan.get('schema_revision')!=schema['revision']:raise ImportProblem('تعریف فیلدها پس از پیش‌نمایش تغییر کرده است؛ فایل را دوباره بررسی کنید.',status=409)
            existing={r['code']:dict(r) for r in c.execute('SELECT * FROM employees')}
            actor=transaction_user(c,request)
            for record in plan['records']:workforce.check_employee_values(actor,existing.get(record['value']['code']),record['value'],creating=record['status']=='new',importing=True)
            for code,expected in plan['baseline'].items():
                if fingerprint(existing.get(code),keys)!=expected:raise ImportProblem('اطلاعات مرتبط پس از پیش‌نمایش تغییر کرده است؛ هیچ ردیفی ذخیره نشد. فایل را دوباره بررسی کنید.',status=409)
            for item in plan['records']:
                value=item['value']
                if item['status']=='new':c.execute(f"INSERT INTO employees(id,{','.join(keys)}) VALUES(?,{','.join('?' for _ in keys)})",[workforce.reserve_id(c)]+[value[key] for key in keys])
                elif item['status']=='update':c.execute(f"UPDATE employees SET {','.join(key+'=?' for key in keys)},version=version+1 WHERE code=?",[value[key] for key in keys]+[value['code']])
                if item['status']!='unchanged':workforce.capture(c,actor['id'],'ورود اکسل — '+item['status'],existing.get(value['code']),dict(c.execute('SELECT * FROM employees WHERE code=?',(value['code'],)).fetchone()))
            counts=plan['counts'];audit(request,c,'ورود اکسل با تأیید پیش‌نمایش',f"{counts['added']} ثبت، {counts['updated']} ویرایش، {counts['unchanged']} بدون تغییر")
            sync_catalog(c);c.execute('DELETE FROM import_previews WHERE token_hash=?',(token_hash(payload['token']),))
        return json_response(ok=True,**counts)
    except ImportProblem as error:return json_response(error=str(error),_status=error.status)

@app.get('/api/master-data',dependencies=[Depends(permitted('catalog.manage'))])
async def get_master_data(request:Request):
    with db() as c:rows=catalog_rows(c)
    return json_response(rows=rows)

@app.post('/api/master-data',dependencies=[Depends(permitted('catalog.manage'))])
async def add_master_data(request:Request):
    payload=await json_data(request);kind=payload.get('kind')
    if not isinstance(kind,str) or kind not in KINDS:return json_response(error='نوع اطلاعات پایه نامعتبر است.',_status=400)
    try:name=valid_name(payload.get('name'))
    except ValueError as e:return json_response(error=str(e),_status=400)
    try:
        with db() as c:
            c.execute('INSERT INTO master_items(kind,name) VALUES(?,?)',(kind,name))
            audit(request,c,'افزودن '+KINDS[kind],name)
    except sqlite3.IntegrityError:return json_response(error='این نام از قبل ثبت شده است.',_status=409)
    return json_response(ok=True)

@app.put('/api/master-data/{ident}',dependencies=[Depends(permitted('catalog.manage'))])
async def rename_master_data(request:Request,ident:int):
    payload=await json_data(request)
    try:name=valid_name(payload.get('name'))
    except ValueError as e:return json_response(error=str(e),_status=400)
    if type(payload.get('version')) is not int:return json_response(error='اطلاعات نسخه معتبر نیست؛ فهرست را تازه‌سازی کنید.',_status=409)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        item=c.execute('SELECT * FROM master_items WHERE id=?',(ident,)).fetchone()
        if not item:return json_response(error='مورد پیدا نشد.',_status=404)
        if item['version']!=payload['version']:return json_response(error='نام قبلاً ویرایش شده است؛ فهرست را تازه‌سازی کنید.',_status=409)
        if name==item['name']:return json_response(ok=True,employees_updated=0,scopes_updated=0)
        if c.execute('SELECT 1 FROM master_items WHERE kind=? AND name=? AND id<>?',(item['kind'],name,ident)).fetchone():return json_response(error='این نام از قبل وجود دارد؛ دو واحد یا محل به‌صورت خودکار ادغام نمی‌شوند.',_status=409)
        kind=item['kind'];old=item['name']
        count=c.execute(f'UPDATE employees SET {kind}=?,version=version+1 WHERE {kind}=?',(name,old)).rowcount
        scopes=c.execute("UPDATE users SET department_scope=? WHERE department_scope=? AND role='viewer'",(name,old)).rowcount if kind=='department' else 0
        for account in c.execute('SELECT id,departments_json,locations_json FROM users').fetchall():
            column='departments_json' if kind=='department' else 'locations_json';values=json.loads(account[column]);values=[name if v==old else v for v in values];c.execute('UPDATE users SET '+column+'=? WHERE id=?',(json.dumps(values,ensure_ascii=False),account['id']))
        c.execute('UPDATE master_items SET name=?,version=version+1 WHERE id=?',(name,ident))
        audit(request,c,'تغییر نام '+KINDS[kind],f'{old} ← {name}؛ {count} پرونده و {scopes} محدوده حساب هماهنگ شد')
    return json_response(ok=True,employees_updated=count,scopes_updated=scopes)

@app.get('/api/users', dependencies=[Depends(require_admin)])
async def users(request: Request):
    with db() as c:
        rows = [public_user(r) for r in c.execute('SELECT * FROM users')]
    return json_response(rows=rows)

@app.post('/api/users', dependencies=[Depends(require_admin)])
async def create_user(request: Request):
    d = await json_data(request) or {}
    username = str(d.get('username', '')).strip()
    name = str(d.get('name', '')).strip()
    pw = str(d.get('password', ''))
    role = d.get('role')
    full_scope=d.get('full_scope') is True if role=='viewer' else True
    scope=str(d.get('department_scope','')).strip()[:180] if role=='viewer' and not full_scope else ''
    if role=='viewer' and not scope and not full_scope and not d.get('departments') and not d.get('locations'):return json_response(error='یک واحد مجاز یا اجازه صریح مشاهده همه واحدها را مشخص کنید.',_status=400)
    try:role,perms,full_scope,ds,ls,disabled=ac.validate_settings(d)
    except ValueError as e:return json_response(error=str(e),_status=400)
    can_export=bool(set(perms)&{'export.excel','export.pdf'}) if perms is not None else d.get('can_export') is True if role=='viewer' else True
    if not username or not name or len(username) > 80 or (len(name) > 100) or (len(pw) < 12) or (len(pw) > 200) or (role not in ['admin', 'viewer']):
        return json_response(error='نام، نام کاربری، نقش و رمز عبور حداقل ۱۲ کاراکتری لازم است.', _status=400)
    try:
        with db() as c:
            c.execute('INSERT INTO users(username,name,password_hash,role,department_scope,can_export,scope_all) VALUES(?,?,?,?,?,?,?)',(username,name,generate_password_hash(pw),role,scope,int(can_export),int(full_scope)))
            ident=c.execute('SELECT id FROM users WHERE username=?',(username,)).fetchone()[0]
            c.execute('UPDATE users SET permissions=?,departments_json=?,locations_json=?,disabled=? WHERE id=?',(json.dumps(perms) if perms is not None else '',json.dumps(ds,ensure_ascii=False),json.dumps(ls,ensure_ascii=False),int(disabled),ident))
            audit(request, c, 'ایجاد کاربر', username)
            sync_catalog(c)
    except sqlite3.IntegrityError:
        return json_response(error='نام کاربری تکراری است.', _status=409)
    return json_response(ok=True)

@app.delete('/api/users/{ident}', dependencies=[Depends(require_admin)])
async def remove_user(request: Request, ident: int):
    if ident == request.session['uid']:
        return json_response(error='حذف حساب خودتان مجاز نیست.', _status=400)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT role,disabled FROM users WHERE id=?',(ident,)).fetchone()
        if old and old['role']=='admin' and not old['disabled'] and not c.execute("SELECT 1 FROM users WHERE role='admin' AND disabled=0 AND id<>?",(ident,)).fetchone():return json_response(error='آخرین مدیر اصلی را نمی‌توان حذف کرد.',_status=400)
        c.execute('DELETE FROM sessions WHERE user_id=?',(ident,))
        c.execute('DELETE FROM mfa_pending WHERE user_id=?',(ident,))
        c.execute('DELETE FROM users WHERE id=?', (ident,))
        audit(request, c, 'حذف دسترسی کاربر', str(ident))
    return json_response(ok=True)

@app.post('/api/password', dependencies=[Depends(require_user)])
async def password(request: Request):
    d = await json_data(request) or {}
    pw = str(d.get('password', ''))
    if len(pw) < 12 or len(pw) > 200:
        return json_response(error='رمز جدید باید بین ۱۲ تا ۲۰۰ کاراکتر باشد.', _status=400)
    u=await require_user(request)
    if not reauthenticate(u,d.get('old','')):return json_response(error='رمز فعلی نادرست است.',_status=400)
    with db() as c:
        c.execute('UPDATE users SET password_hash=? WHERE id=?', (generate_password_hash(pw), u['id']))
        c.execute('DELETE FROM sessions WHERE user_id=? AND token_hash!=?',(u['id'],token_hash(request.session['sid'])))
        audit(request, c, 'تغییر رمز عبور و ابطال نشست‌های دیگر')
    return json_response(ok=True)

@app.get('/api/audit', dependencies=[Depends(require_admin)])
async def audit_list(request: Request):
    with db() as c:
        rows = [dict(r) for r in c.execute('SELECT audit.*,users.name FROM audit LEFT JOIN users ON users.id=audit.user_id ORDER BY audit.id DESC LIMIT 100')]
    return json_response(rows=rows)

def init():
    with db() as c:
        c.execute('PRAGMA journal_mode=WAL')
        c.execute('BEGIN IMMEDIATE')
        c.execute('CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY,value TEXT)')
        c.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL)')
        for key,definition in [('department_scope',"TEXT NOT NULL DEFAULT ''"),('can_export','INTEGER NOT NULL DEFAULT 0'),('scope_all','INTEGER NOT NULL DEFAULT 0'),('mfa_secret',"TEXT NOT NULL DEFAULT ''"),('mfa_counter','INTEGER NOT NULL DEFAULT -1'),('recovery_hashes',"TEXT NOT NULL DEFAULT '[]'")]:
            if key not in [r['name'] for r in c.execute('PRAGMA table_info(users)')]:c.execute(f'ALTER TABLE users ADD COLUMN {key} {definition}')
        c.execute('CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,created REAL NOT NULL,last_seen REAL NOT NULL,expires REAL NOT NULL)')
        c.execute('CREATE INDEX IF NOT EXISTS sessions_user ON sessions(user_id)')
        c.execute('CREATE TABLE IF NOT EXISTS login_failures(key TEXT,created REAL)')
        c.execute('CREATE INDEX IF NOT EXISTS login_key ON login_failures(key,created)')
        c.execute('CREATE TABLE IF NOT EXISTS mfa_pending(user_id INTEGER PRIMARY KEY,secret TEXT,expires REAL)')
        c.execute('CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY,' + ','.join((k + (' INTEGER DEFAULT 0' if k in ['children', 'dependents'] else ' TEXT DEFAULT ""') + (' UNIQUE NOT NULL' if k == 'code' else '') for k in KEYS)) + ')')
        c.execute('CREATE INDEX IF NOT EXISTS employees_department ON employees(department)')
        c.execute('CREATE INDEX IF NOT EXISTS employees_location ON employees(location)')
        if 'version' not in [r['name'] for r in c.execute('PRAGMA table_info(employees)')]: c.execute('ALTER TABLE employees ADD COLUMN version INTEGER NOT NULL DEFAULT 1')
        existing_columns={r['name'] for r in c.execute('PRAGMA table_info(employees)')}
        for key,_ in EXTRA_FIELDS+SETTLEMENT_FIELDS:
            if key not in existing_columns:c.execute(f"ALTER TABLE employees ADD COLUMN {key} TEXT NOT NULL DEFAULT ''")
        c.execute('CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,user_id INTEGER,action TEXT,detail TEXT,created_at TEXT)')
        init_catalog(c)
        init_registry(c)
        c.execute('CREATE TABLE IF NOT EXISTS import_previews(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,session_id TEXT NOT NULL,expires REAL NOT NULL,payload BLOB NOT NULL)')
        c.execute('CREATE INDEX IF NOT EXISTS import_previews_expiry ON import_previews(expires)')
        c.execute('DELETE FROM import_previews WHERE expires<?',(time.time(),))
        workforce.init_storage(c)
        personnel_records.init_storage(c)
        vehicle_import.init_storage(c)
        choice_settings.init_storage(c)
        record_import.init_storage(c)
        unified_excel.init_storage(c)

@app.get('/api/release')
async def release_status(request: Request):
    await require_user(request)
    return release_info.status()


@app.get('/api/health')
async def health():
    return {'product': 'behnova-fastapi', 'version': str(release_info.SERIAL), 'release_serial': release_info.SERIAL, 'desktop': DESKTOP, 'instance': getattr(app.state, 'instance_id', None), 'installation_id': getattr(app.state, 'installation_id', None)}

@app.post('/api/setup')
async def setup(request: Request):
    if DESKTOP and not loopback(request): return json_response(error='حساب مدیر باید روی خود کامپیوتر مرکزی ساخته شود.', _status=403)
    d = await json_data(request)
    password = str(d.get('password', ''))
    if len(password) < 12 or len(password) > 200:
        return json_response(error='رمز عبور باید بین ۱۲ تا ۲۰۰ کاراکتر باشد.', _status=400)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        if c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
            return json_response(error='حساب مدیر قبلاً ساخته شده است.', _status=409)
        cur = c.execute('INSERT INTO users(username,name,password_hash,role) VALUES(?,?,?,?)',
                        ('admin', 'مدیر اصلی', generate_password_hash(password), 'admin'))
        ident = cur.lastrowid
        create_session(request,c,ident)
        audit(request, c, 'ساخت حساب مدیر')
    return json_response(user={'id':ident,'username':'admin','name':'مدیر اصلی','role':'admin','can_export':True,'department_scope':'','full_scope':True,'mfa_enabled':False},csrf=request.session['csrf'])

@app.post('/api/desktop/stop', dependencies=[Depends(require_admin)])
async def stop_desktop(request: Request):
    callback = getattr(app.state, 'shutdown_callback', None)
    if not DESKTOP or not loopback(request) or callback is None:
        return json_response(error='توقف کامل فقط توسط ادمین از خود کامپیوتر سرور مجاز است؛ کاربران شبکه نباید سرور دیگران را خاموش کنند.', _status=400)
    timer = threading.Timer(0.7, callback); timer.daemon = True; timer.start()
    return json_response(ok=True)


def loopback(request: Request):
    try: return ipaddress.ip_address(request.client.host).is_loopback
    except (ValueError, AttributeError): return False

@app.get('/api/connection', dependencies=[Depends(require_admin)])
async def connection(request: Request):
    return {'shared':SHARED, 'local_url':getattr(app.state, 'local_url', str(request.base_url).rstrip('/')),
            'share_urls':getattr(app.state, 'share_urls', []), 'can_stop':DESKTOP and loopback(request),
            'https':request.url.scheme == 'https','capacity_note':'تست‌شده با ۳۰۰۰ پرونده؛ سقف ۵۰۰۰ ردیف در هر بار ورود اکسل'}


@app.get('/api/mfa/status',dependencies=[Depends(require_user)])
async def mfa_status(request:Request):
    u=await require_user(request)
    with db() as c:count=c.execute('SELECT COUNT(*) FROM sessions WHERE user_id=? AND expires>? AND last_seen>?',(u['id'],time.time(),time.time()-IDLE_SECONDS)).fetchone()[0]
    return {'enabled':bool(u['mfa_secret']),'recovery_remaining':len(json.loads(u['recovery_hashes'] or '[]')),'sessions':count}

@app.post('/api/mfa/enroll',dependencies=[Depends(require_user)])
async def mfa_enroll(request:Request):
    u=await require_user(request);d=await json_data(request)
    if u['mfa_secret']:return json_response(error='تأیید دومرحله‌ای قبلاً فعال شده است.',_status=409)
    if not reauthenticate(u,d.get('password','')):return json_response(error='رمز فعلی نادرست است.',_status=403)
    secret=new_totp_secret()
    with db() as c:c.execute('INSERT OR REPLACE INTO mfa_pending(user_id,secret,expires) VALUES(?,?,?)',(u['id'],CIPHER.encrypt(secret.encode()).decode(),time.time()+600))
    return {'secret':secret,'uri':'otpauth://totp/'+quote('BEHNOVA:'+u['username'])+'?secret='+secret+'&issuer=BEHNOVA&digits=6&period=30'}

@app.post('/api/mfa/confirm',dependencies=[Depends(require_user)])
async def mfa_confirm(request:Request):
    u=await require_user(request);d=await json_data(request)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        pending=c.execute('SELECT * FROM mfa_pending WHERE user_id=?',(u['id'],)).fetchone()
        if not pending or pending['expires']<time.time():return json_response(error='درخواست فعال‌سازی پایان یافته؛ دوباره آغاز کنید.',_status=400)
        try:secret=CIPHER.decrypt(pending['secret'].encode()).decode()
        except InvalidToken:return json_response(error='کلید امنیتی قابل خواندن نیست؛ با مدیر سیستم تماس بگیرید.',_status=400)
        step=totp_counter(secret,d.get('otp',''))
        if step is None:return json_response(error='کد شش‌رقمی معتبر نیست.',_status=400)
        codes,hashes=recovery_codes()
        c.execute('UPDATE users SET mfa_secret=?,mfa_counter=?,recovery_hashes=? WHERE id=?',(pending['secret'],step,json.dumps(hashes),u['id']))
        c.execute('DELETE FROM mfa_pending WHERE user_id=?',(u['id'],))
        c.execute('DELETE FROM sessions WHERE user_id=? AND token_hash!=?',(u['id'],token_hash(request.session['sid'])))
        audit(request,c,'فعال‌سازی تأیید دومرحله‌ای')
    return {'ok':True,'recovery_codes':codes}

@app.post('/api/mfa/disable',dependencies=[Depends(require_user)])
async def mfa_disable(request:Request):
    u=await require_user(request);d=await json_data(request)
    if not u['mfa_secret']:return json_response(error='تأیید دومرحله‌ای فعال نیست.',_status=400)
    if not reauthenticate(u,d.get('password','')):return json_response(error='اطلاعات تأیید نادرست است.',_status=403)
    with db() as c:
        c.execute('BEGIN IMMEDIATE')
        current=c.execute('SELECT * FROM users WHERE id=?',(u['id'],)).fetchone()
        if not verify_mfa(c,current,d.get('otp','')):return json_response(error='اطلاعات تأیید نادرست است.',_status=403)
        c.execute("UPDATE users SET mfa_secret='',mfa_counter=-1,recovery_hashes='[]' WHERE id=?",(u['id'],))
        c.execute('DELETE FROM sessions WHERE user_id=? AND token_hash!=?',(u['id'],token_hash(request.session['sid'])))
        audit(request,c,'غیرفعال‌سازی تأیید دومرحله‌ای')
    return {'ok':True}

@app.post('/api/sessions/revoke-others',dependencies=[Depends(require_user)])
async def revoke_other_sessions(request:Request):
    u=await require_user(request)
    with db() as c:
        c.execute('DELETE FROM sessions WHERE user_id=? AND token_hash!=?',(u['id'],token_hash(request.session['sid'])))
        audit(request,c,'ابطال نشست‌های دیگر')
    return {'ok':True}

@app.post('/api/users/{ident}/revoke-sessions',dependencies=[Depends(require_admin)])
async def revoke_user_sessions(request:Request,ident:int):
    if ident==request.session['uid']:return json_response(error='برای حساب خود از بستن نشست‌های دیگر استفاده کنید.',_status=400)
    with db() as c:
        c.execute('DELETE FROM sessions WHERE user_id=?',(ident,));audit(request,c,'ابطال نشست‌های کاربر',str(ident))
    return {'ok':True}

from company_context import set_default
if not globals().get('_IS_COMPANY_CHILD'):set_default(sys.modules[__name__])
workforce.register(sys.modules[__name__])
personnel_records.register(sys.modules[__name__])
vehicle_import.register(sys.modules[__name__])
choice_settings.register(sys.modules[__name__])
record_import.register(sys.modules[__name__])
unified_excel.register(sys.modules[__name__])

app.mount('/static', StaticFiles(directory=str(ASSET_ROOT / 'static')), name='static')
app.add_middleware(SessionMiddleware, secret_key=SECRET, max_age=SESSION_SECONDS,
                   same_site='lax', https_only=os.environ.get('COOKIE_SECURE') == '1', session_cookie='behnova_session')
app.add_middleware(BodyLimitMiddleware)
if not globals().get('_IS_COMPANY_CHILD'):
    from company_gateway import CompanyGateway
    app.add_middleware(CompanyGateway,module=sys.modules[__name__])
if DESKTOP:
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=['127.0.0.1','localhost','[::1]'] + os.environ.get('BEHNOVA_ALLOWED_HOSTS', '').split(','))
app.add_middleware(LicenseMiddleware,base=ASSET_ROOT.parent)
init()
if os.name!='nt':os.chmod(DB,0o600)
if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host=os.environ.get('HOST', '127.0.0.1'), port=int(os.environ.get('PORT', '3000')))
