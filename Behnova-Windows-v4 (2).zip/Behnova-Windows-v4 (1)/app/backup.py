"""Local IT backup of the whole installation (not the selected-company in-app export).
Each SQLite DB is snapshotted consistently; no dependency on an installed Python.
Protect this folder: it contains ALL companies, credential material and encryption keys.
"""
from pathlib import Path
import sqlite3,datetime,os,shutil,json,hashlib
from contextlib import closing
BASE=Path(__file__).resolve().parent.parent
DATA=Path(os.environ.get('BEHNOVA_DATA_DIR',str(BASE/'data'))).resolve()
if not (DATA/'hr.sqlite3').exists():
 print('No database yet. Run START.cmd first.');raise SystemExit(1)
folder=BASE/'backups'/datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f');folder.mkdir(parents=True,mode=0o700)
def snapshot(src,dest):
 dest.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 with closing(sqlite3.connect(src)) as source,closing(sqlite3.connect(dest)) as target:
  source.backup(target);target.execute('PRAGMA journal_mode=DELETE');target.commit()
 os.chmod(dest,0o600)
try:
 companies=[(DATA,Path('.'))]
 if (DATA/'companies.sqlite3').exists():
  snapshot(DATA/'companies.sqlite3',folder/'companies.sqlite3')
  with closing(sqlite3.connect(folder/'companies.sqlite3')) as c:
   for ident,guid in c.execute('SELECT id,guid FROM companies WHERE id<>1'):
    if len(guid)!=32 or any(ch not in '0123456789abcdef' for ch in guid):raise ValueError('Invalid company identity')
    src=DATA/'companies'/guid
    if (src/'hr.sqlite3').exists():companies.append((src,Path('companies')/guid))
 for src,relative in companies:
  target=folder/relative;snapshot(src/'hr.sqlite3',target/'hr.sqlite3')
  for name in ['security.key','session.key']:
   if not (src/name).exists():raise ValueError('Company security keys are missing')
   shutil.copy2(src/name,target/name);os.chmod(target/name,0o600)
 if (DATA/'behnova-server.json').exists():shutil.copy2(DATA/'behnova-server.json',folder/'behnova-server.json')
 manifest={str(p.relative_to(folder)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}
 (folder/'INSTALLATION-SHA256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 print('ALL-COMPANY installation snapshot created:',folder)
 print('Company databases:',len(companies))
 print('CONFIDENTIAL: ALL companies and security keys. Restrict access and encrypt the destination volume.')
 print('For ordinary selected-company backups/restores, use the in-app backup and RESTORE.cmd.')
 print('This installation snapshot is for a stopped-server recovery by authorized IT; it is NOT an in-app company ZIP.')
except Exception as error:
 shutil.rmtree(folder,ignore_errors=True)
 print('Backup failed; incomplete snapshot removed:',error);raise SystemExit(1)
