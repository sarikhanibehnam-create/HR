"""Persistent organizational units and locations, without sample entries."""
KINDS={'department':'واحد سازمانی','location':'محل فعالیت'}
def init_catalog(connection):
 connection.execute("CREATE TABLE IF NOT EXISTS master_items(id INTEGER PRIMARY KEY,kind TEXT NOT NULL CHECK(kind IN ('department','location')),name TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1,UNIQUE(kind,name))")
 sync_catalog(connection)
def sync_catalog(connection):
 for kind in KINDS:
  connection.execute(f"INSERT OR IGNORE INTO master_items(kind,name) SELECT ?,{kind} FROM employees WHERE {kind} IS NOT NULL AND {kind}<>''",(kind,))
 connection.execute("INSERT OR IGNORE INTO master_items(kind,name) SELECT 'department',department_scope FROM users WHERE role='viewer' AND department_scope<>''")
def valid_name(value):
 if not isinstance(value,str):raise ValueError('نام معتبر وارد کنید.')
 value=value.strip()
 if not value or len(value)>180 or any(ord(c)<32 for c in value):raise ValueError('نام باید بین ۱ تا ۱۸۰ کاراکتر و بدون نویسه کنترلی باشد.')
 return value
def catalog_rows(connection):
 result=[]
 for kind in KINDS:
  counts={r['name']:r['n'] for r in connection.execute(f'SELECT {kind} AS name,COUNT(*) AS n FROM employees GROUP BY {kind}')}
  scopes={r['name']:r['n'] for r in connection.execute("SELECT department_scope AS name,COUNT(*) AS n FROM users WHERE role='viewer' AND scope_all=0 GROUP BY department_scope")} if kind=='department' else {}
  for item in connection.execute('SELECT * FROM master_items WHERE kind=? ORDER BY name',(kind,)):
   result.append(dict(item)|{'employee_count':counts.get(item['name'],0),'scoped_accounts':scopes.get(item['name'],0)})
 return result
