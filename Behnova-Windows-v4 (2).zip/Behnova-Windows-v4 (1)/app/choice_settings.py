"""Administrator-controlled descriptive choices and explicit import aliases; no auto-accept."""
import json,hashlib,sqlite3
from fastapi import Request,HTTPException
from company_context import current_app as A
FIELDS={'gender':'جنسیت','education':'مدرک تحصیلی','related':'ارتباط رشته با شغل','marital':'وضعیت تأهل','insurance':'وضعیت بیمه'}
class UnknownChoice(ValueError):
 def __init__(self,field,value,choices):
  self.field=field;self.value=value;self.choices=choices
  super().__init__('مقدار «'+value+'» برای '+FIELDS[field]+' نامعتبر است. مقادیر مجاز: '+'، '.join(choices))

def init_storage(c):
 c.execute('CREATE TABLE IF NOT EXISTS choice_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,field TEXT NOT NULL,label TEXT NOT NULL,norm TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,UNIQUE(field,norm))')
 c.execute('CREATE TABLE IF NOT EXISTS choice_aliases(id INTEGER PRIMARY KEY AUTOINCREMENT,field TEXT NOT NULL,label TEXT NOT NULL,norm TEXT NOT NULL,target TEXT NOT NULL,UNIQUE(field,norm))')

def choices(c):
 result={k:list(v) for k,v in A.OPTIONS.items()}
 for row in c.execute('SELECT * FROM choice_entries WHERE active=1 ORDER BY id'):
  if row['field'] in result and row['label'] not in result[row['field']]:result[row['field']].append(row['label'])
 return result

def signature(c):
 data=[list(r) for r in c.execute('SELECT field,label,active FROM choice_entries ORDER BY id')]+[list(r) for r in c.execute('SELECT field,label,target FROM choice_aliases ORDER BY id')]
 return hashlib.sha256(json.dumps(data,ensure_ascii=False).encode()).hexdigest() if data else ''

def canonical(field,value,options=None,c=None):
 if c is None:
  with A.db() as con:return canonical(field,value,options,con)
 allowed=options if options is not None else choices(c)[field];key=A.option_key(value)
 if not key:return ''
 lookup={A.option_key(v):v for v in allowed}
 if key in lookup:return lookup[key]
 original=A.OPTION_LOOKUP[field].get(key)
 if original in allowed:return original
 row=c.execute('SELECT target FROM choice_aliases WHERE field=? AND norm=?',(field,key)).fetchone()
 if row and row['target'] in allowed:return row['target']
 raise UnknownChoice(field,value,allowed)

def unknown_payload(error):return dict(field=error.field,label=FIELDS[error.field],value=error.value,choices=error.choices)

def register(module):
 app=module.app
 @app.get('/api/choice-settings')
 async def listing(request:Request):
  await A.require_admin(request)
  with A.db() as c:
   rows=[]
   for key,label in FIELDS.items():
    entries=[]
    for value in A.OPTIONS[key]:entries.append(dict(id=None,label=value,base=True,active=True))
    entries.extend(dict(r)|{'base':False} for r in c.execute('SELECT * FROM choice_entries WHERE field=? ORDER BY id',(key,)))
    rows.append(dict(field=key,label=label,entries=entries,aliases=[dict(r) for r in c.execute('SELECT * FROM choice_aliases WHERE field=? ORDER BY id',(key,))]))
  return dict(rows=rows)
 @app.post('/api/choice-settings')
 async def save(request:Request):
  u=await A.require_admin(request);p=await A.json_data(request);field=p.get('field');value=p.get('value');target=p.get('alias_of','')
  if not isinstance(field,str) or field not in FIELDS or not isinstance(value,str) or not 1<=len(value.strip())<=100 or value.strip()[0] in '=+-@' or any(ord(ch)<32 or ord(ch)==127 for ch in value):raise HTTPException(400,'فهرست و مقدار معتبر، بدون علامت فرمول در ابتدا، وارد کنید.')
  if not isinstance(target,str):raise HTTPException(400,'مقدار مقصد نامعتبر است.')
  value=value.strip();norm=A.option_key(value)
  if not norm:raise HTTPException(400,'مقدار خالی مجاز نیست.')
  try:
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request)
    if u['role']!='admin':raise HTTPException(403,'این عملیات فقط برای مدیر مجاز است.')
    allowed=choices(c)[field];base=A.OPTION_LOOKUP[field]
    if norm in {A.option_key(v) for v in allowed} or norm in base or c.execute('SELECT 1 FROM choice_aliases WHERE field=? AND norm=?',(field,norm)).fetchone():raise HTTPException(409,'این مقدار یا معادل آن قبلاً تعریف شده است.')
    if target:
     if c.execute('SELECT COUNT(*) FROM choice_aliases WHERE field=?',(field,)).fetchone()[0]>=200:raise HTTPException(400,'حداکثر ۲۰۰ تطبیق برای هر فهرست.')
     if target not in allowed:raise HTTPException(400,'مقصد باید یکی از گزینه‌های فعال همین فهرست باشد.')
     c.execute('INSERT INTO choice_aliases(field,label,norm,target) VALUES(?,?,?,?)',(field,value,norm,target));action='تطبیق صریح مقدار ورودی'
    else:
     if len(allowed)>=100:raise HTTPException(400,'حداکثر ۱۰۰ گزینه فعال برای هر فهرست.')
     old=c.execute('SELECT * FROM choice_entries WHERE field=? AND norm=?',(field,norm)).fetchone()
     if old:c.execute('UPDATE choice_entries SET active=1 WHERE id=?',(old['id'],))
     else:c.execute('INSERT INTO choice_entries(field,label,norm) VALUES(?,?,?)',(field,value,norm))
     action='افزودن گزینه فهرست'
    A.audit(request,c,action,FIELDS[field]+': '+value+(' ← '+target if target else ''))
  except sqlite3.IntegrityError:raise HTTPException(409,'مقدار تکراری است.')
  return dict(ok=True)
 @app.delete('/api/choice-settings/{ident}')
 async def remove(request:Request,ident:int):
  await A.require_admin(request);typ=request.query_params.get('type','entry')
  if typ not in ['entry','alias']:raise HTTPException(400,'نوع مورد نامعتبر است.')
  with A.db() as c:
   c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request)
   if u['role']!='admin':raise HTTPException(403,'این عملیات فقط برای مدیر مجاز است.')
   table='choice_entries' if typ=='entry' else 'choice_aliases';row=c.execute('SELECT * FROM '+table+' WHERE id=?',(ident,)).fetchone()
   if not row:raise HTTPException(404,'مورد پیدا نشد.')
   if typ=='entry':
    if c.execute('SELECT 1 FROM employees WHERE '+row['field']+'=? LIMIT 1',(row['label'],)).fetchone():raise HTTPException(409,'این گزینه در پرونده‌ها استفاده شده؛ غیرفعال‌سازی مجاز نیست.')
    if row['field']=='education':
     for r in c.execute('SELECT payload FROM personnel_records WHERE kind="education" AND deleted=0'):
      if A.personnel_records.dec(r['payload']).get('degree')==row['label']:raise HTTPException(409,'این مدرک در سوابق ارتقا استفاده شده است.')
    if c.execute('SELECT 1 FROM choice_aliases WHERE field=? AND target=?',(row['field'],row['label'])).fetchone():raise HTTPException(409,'ابتدا تطبیق‌های وابسته به این گزینه را حذف کنید.')
    c.execute('UPDATE choice_entries SET active=0 WHERE id=?',(ident,))
   else:c.execute('DELETE FROM choice_aliases WHERE id=?',(ident,))
   A.audit(request,c,'غیرفعال‌سازی گزینه' if typ=='entry' else 'حذف تطبیق ورودی',row['field']+': '+row['label'])
  return dict(ok=True)
