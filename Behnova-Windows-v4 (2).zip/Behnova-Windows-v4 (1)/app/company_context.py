"""Request-local application binding; never mutate process-global tenant state."""
from contextvars import ContextVar
_binding=ContextVar('behnova_company_app',default=None)
_default=None

def bind(module):return _binding.set(module)
def unbind(token):_binding.reset(token)
def set_default(module):
 global _default
 if _default is None:_default=module

def module():
 value=_binding.get() or _default
 if value is None:raise RuntimeError('Company context has not been initialized')
 return value

class AppProxy:
 def __getattr__(self,name):return getattr(module(),name)
 def __setattr__(self,name,value):setattr(module(),name,value)
current_app=AppProxy()

_identity=ContextVar('behnova_origin_identity',default=None)
def bind_identity(value):return _identity.set(value)
def unbind_identity(token):_identity.reset(token)
def origin_identity():return _identity.get()
