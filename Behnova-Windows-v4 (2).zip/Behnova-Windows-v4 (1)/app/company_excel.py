"""Append a small company identity sheet without parsing/rebuilding personnel cells.
Preserves workbook data/types/styles, cached template bytes and large-export performance.
"""
import io,zipfile
from xml.etree import ElementTree as E
S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P='http://schemas.openxmlformats.org/package/2006/relationships'
C='http://schemas.openxmlformats.org/package/2006/content-types'
def stamp(raw,guid,name):
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  book=E.fromstring(z.read('xl/workbook.xml'));rels=E.fromstring(z.read('xl/_rels/workbook.xml.rels'));types=E.fromstring(z.read('[Content_Types].xml'))
  sheets=book.find('{'+S+'}sheets');existing=next((x for x in sheets if x.get('name')=='شرکت'),None)
  path='xl/worksheets/behnova-company.xml';changed={}
  if existing is None:
   ids={x.get('Id') for x in rels};rid='rIdBehnovaCompany'
   while rid in ids:rid+='X'
   E.SubElement(sheets,'{'+S+'}sheet',{'name':'شرکت','sheetId':str(1+max(int(x.get('sheetId')) for x in sheets)),'{'+R+'}id':rid})
   E.SubElement(rels,'{'+P+'}Relationship',{'Id':rid,'Type':R+'/worksheet','Target':'/'+path})
   E.SubElement(types,'{'+C+'}Override',{'PartName':'/'+path,'ContentType':'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml'})
   for n,v in [('xl/workbook.xml',book),('xl/_rels/workbook.xml.rels',rels),('[Content_Types].xml',types)]:changed[n]=E.tostring(v,encoding='utf-8',xml_declaration=True)
  else:
   rel=next(x for x in rels if x.get('Id')==existing.get('{'+R+'}id'));target=rel.get('Target');path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
  sheet=E.Element('{'+S+'}worksheet');views=E.SubElement(sheet,'{'+S+'}sheetViews');E.SubElement(views,'{'+S+'}sheetView',{'workbookViewId':'0','rightToLeft':'1'});cols=E.SubElement(sheet,'{'+S+'}cols');E.SubElement(cols,'{'+S+'}col',{'min':'1','max':'2','width':'48','customWidth':'1'});data=E.SubElement(sheet,'{'+S+'}sheetData')
  for i,values in enumerate([('شناسه شرکت',guid),('نام شرکت',name)],1):
   row=E.SubElement(data,'{'+S+'}row',{'r':str(i)})
   for letter,value in zip('AB',values):
    cell=E.SubElement(row,'{'+S+'}c',{'r':letter+str(i),'t':'inlineStr'});inline=E.SubElement(cell,'{'+S+'}is');E.SubElement(inline,'{'+S+'}t').text=value
  changed[path]=E.tostring(sheet,encoding='utf-8',xml_declaration=True);out=io.BytesIO()
  with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as dest:
   for info in z.infolist():dest.writestr(info,changed.pop(info.filename,z.read(info.filename)))
   for n,v in changed.items():
    info=zipfile.ZipInfo(n,(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;dest.writestr(info,v)
 return out.getvalue()
