"""Company boundary: separate application/database/key space, request-local routing.
Existing installation stays company 1 in-place. No data copy and no synchronization.
An opaque server-side portal session links a login to explicitly authorized companies.
Root administrators may manage companies; company-local accounts cannot leave their own.
"""
import base64,contextlib,importlib.util,json,secrets,sqlite3,sys,threading,time,uuid
from pathlib import Path
from http.cookies import SimpleCookie
from itsdangerous import TimestampSigner,BadSignature
from starlette.responses import JSONResponse
from security_core import token_hash
from company_context import bind,unbind,bind_identity,unbind_identity

RESERVED='__behnova_owner_'
class CompanyGateway:
 def __init__(self,app,module):
  self.app=app;self.root=module;self.lock=threading.RLock();self.modules={1:module}
  self.path=module.DATA_DIR/'companies.sqlite3';self.cookie='behnova_portal'
  with self.store() as c:
   c.execute('CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,guid TEXT UNIQUE NOT NULL,created_at TEXT NOT NULL)')
   c.execute('INSERT OR IGNORE INTO companies(id,name,guid,created_at) VALUES(1,?,?,?)',('شرکت اول',uuid.uuid4().hex,module.tehran_now().isoformat()))
   c.execute('CREATE TABLE IF NOT EXISTS portals(token_hash TEXT PRIMARY KEY,origin_id INTEGER NOT NULL,origin_sid BLOB NOT NULL,active_id INTEGER NOT NULL,expires REAL NOT NULL)')
   c.execute('CREATE TABLE IF NOT EXISTS tickets(portal_hash TEXT NOT NULL,company_id INTEGER NOT NULL,sid BLOB NOT NULL,csrf TEXT NOT NULL,uid INTEGER NOT NULL,PRIMARY KEY(portal_hash,company_id),FOREIGN KEY(portal_hash) REFERENCES portals(token_hash) ON DELETE CASCADE)')
   c.execute('DELETE FROM portals WHERE expires<?',(time.time(),))
   row=dict(c.execute('SELECT * FROM companies WHERE id=1').fetchone())
  self.identify(module,row)
 @contextlib.contextmanager
 def store(self):
  c=sqlite3.connect(self.path,timeout=20);c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON')
  try:
   with c:yield c
  finally:c.close()
 def identify(self,m,row):
  m._COMPANY_ID=row['id'];m._COMPANY_NAME=row['name'];m._COMPANY_GUID=row['guid']
  with m.db() as c:
   c.execute('INSERT OR IGNORE INTO app_meta(key,value) VALUES(?,?)',('company_instance_id',row['guid']))
   guid=c.execute("SELECT value FROM app_meta WHERE key='company_instance_id'").fetchone()[0]
   # The DB identifier is authoritative across a restore of this company's own backup.
   if guid!=row['guid']:raise RuntimeError('شناسه بانک اطلاعاتی با شرکت انتخاب‌شده مطابقت ندارد.')
 def get_module(self,cid):
  with self.lock:
   with self.store() as c:r=c.execute('SELECT * FROM companies WHERE id=?',(cid,)).fetchone()
   if r is None:raise ValueError('شرکت مجاز پیدا نشد.')
   row=dict(r)
   if cid in self.modules:
    m=self.modules[cid];m._COMPANY_NAME=row['name'];return m
   folder=(self.root.DATA_DIR/'companies'/row['guid']).resolve()
   if folder.parent!=(self.root.DATA_DIR/'companies').resolve():raise ValueError('مسیر شرکت نامعتبر است.')
   name='_behnova_company_'+row['guid'];spec=importlib.util.spec_from_file_location(name,self.root.ASSET_ROOT/'app.py');m=importlib.util.module_from_spec(spec)
   m._COMPANY_DATA_DIR=str(folder);m._IS_COMPANY_CHILD=True;m._COMPANY_ID=cid;m._COMPANY_GUID=row['guid'];m._COMPANY_NAME=row['name'];sys.modules[name]=m
   tok=bind(m)
   try:spec.loader.exec_module(m);self.identify(m,row)
   except BaseException:
    sys.modules.pop(name,None);raise
   finally:unbind(tok)
   self.modules[cid]=m;return m
 def unpack(self,m,value):
  try:return json.loads(base64.b64decode(TimestampSigner(str(m.SECRET)).unsign(value,max_age=m.SESSION_SECONDS)))
  except (BadSignature,ValueError,TypeError):return {}
 def pack(self,m,value):return TimestampSigner(str(m.SECRET)).sign(base64.b64encode(json.dumps(value).encode())).decode()
 def enc(self,s):return self.root.CIPHER.encrypt(s.encode())
 def dec(self,s):return self.root.CIPHER.decrypt(s).decode()
 def authenticated(self,m,sid):
  now=time.time()
  with m.db() as c:
   u=c.execute('SELECT users.*,sessions.expires,sessions.last_seen FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token_hash=?',(token_hash(sid),)).fetchone()
   if not u or u['disabled'] or u['expires']<=now or u['last_seen']<=now-m.IDLE_SECONDS:return None
   if now-u['last_seen']>60:c.execute('UPDATE sessions SET last_seen=? WHERE token_hash=?',(now,token_hash(sid)))
   return dict(u)
 def origin(self,cookie):
  if not cookie:return None,None
  try:
   with self.store() as c:p=c.execute('SELECT * FROM portals WHERE token_hash=? AND expires>?',(token_hash(cookie),time.time())).fetchone()
   if p is None:return None,None
   p=dict(p);m=self.get_module(p['origin_id']);u=self.authenticated(m,self.dec(p['origin_sid']))
   return (p,u) if u else (None,None)
  except Exception as error:
   # Restored keys or revoked sessions invalidate portal tickets, never bypass auth.
   from cryptography.fernet import InvalidToken
   if isinstance(error,(InvalidToken,ValueError)):return None,None
   raise
 def is_manager(self,p,u):return bool(p and p['origin_id']==1 and u and u['role']=='admin')
 def allowed(self,p,u,cid):return bool(p and u and (cid==p['origin_id'] or self.is_manager(p,u)))
 def ticket(self,p,u,cid):
  if not self.allowed(p,u,cid):raise PermissionError('اجازه ورود به این شرکت را ندارید.')
  m=self.get_module(cid)
  with self.lock:
   with self.store() as c:t=c.execute('SELECT * FROM tickets WHERE portal_hash=? AND company_id=?',(p['token_hash'],cid)).fetchone()
   if cid==p['origin_id']:
    if not t:raise PermissionError('نشست شرکت پایان یافته است؛ دوباره وارد شوید.')
    return m,dict(t),{'sid':self.dec(t['sid']),'csrf':t['csrf'],'uid':t['uid']}
   # Only an authenticated administrator of company 1 can reach this branch.
   with m.db() as c:
    username=RESERVED+str(u['id'])
    c.execute('INSERT OR IGNORE INTO users(username,name,password_hash,role,scope_all,can_export) VALUES(?,?,?,?,1,1)',(username,u['name'],m.DUMMY_PASSWORD_HASH,'admin'))
    c.execute("UPDATE users SET name=?,password_hash=?,role='admin',scope_all=1,can_export=1,disabled=0,permissions='',department_scope='',departments_json='[]',locations_json='[]' WHERE username=?",(u['name'],m.DUMMY_PASSWORD_HASH,username));uid=c.execute('SELECT id FROM users WHERE username=?',(username,)).fetchone()[0]
   if t and self.authenticated(m,self.dec(t['sid'])):
    return m,dict(t),{'sid':self.dec(t['sid']),'csrf':t['csrf'],'uid':uid}
   sid=secrets.token_urlsafe(40);csrf=secrets.token_urlsafe(32);now=time.time()
   with m.db() as c:c.execute('INSERT INTO sessions VALUES(?,?,?,?,?)',(token_hash(sid),uid,now,now,min(p['expires'],now+m.SESSION_SECONDS)))
   with self.store() as c:c.execute('INSERT OR REPLACE INTO tickets VALUES(?,?,?,?,?)',(p['token_hash'],cid,self.enc(sid),csrf,uid))
   t={'sid':self.enc(sid),'csrf':csrf,'uid':uid};return m,t,{'sid':sid,'csrf':csrf,'uid':uid}
 def context(self,p,u,cid):
  with self.store() as c:
   rows=[{'id':r['id'],'name':r['name']} for r in c.execute('SELECT id,name FROM companies ORDER BY id') if p and (self.is_manager(p,u) or r['id']==p['origin_id'])]
  return {'active_id':cid,'companies':rows,'can_manage':self.is_manager(p,u),'independent':True}
 def create_portal(self,m,data):
  u=self.authenticated(m,data.get('sid',''))
  if not u:return None,None,None
  token=secrets.token_urlsafe(40);key=token_hash(token);cid=m._COMPANY_ID
  with self.store() as c:
   c.execute('DELETE FROM portals WHERE expires<?',(time.time(),))
   c.execute('INSERT INTO portals VALUES(?,?,?,?,?)',(key,cid,self.enc(data['sid']),cid,u['expires']))
   c.execute('INSERT INTO tickets VALUES(?,?,?,?,?)',(key,cid,self.enc(data['sid']),data['csrf'],u['id']))
  p={'token_hash':key,'origin_id':cid,'active_id':cid,'origin_sid':self.enc(data['sid']),'expires':u['expires']}
  return token,p,u
 def retire_previews(self,m,sid):
  with m.db() as c:
   for table in ['import_previews','vehicle_import_previews','record_import_previews','unified_excel_previews']:c.execute('DELETE FROM '+table+' WHERE session_id=?',(token_hash(sid),))
 def logout(self,p):
  if not p:return
  with self.store() as c:ts=[dict(t) for t in c.execute('SELECT * FROM tickets WHERE portal_hash=?',(p['token_hash'],))]
  for t in ts:
   m=self.get_module(t['company_id']);sid=self.dec(t['sid']);self.retire_previews(m,sid)
   with m.db() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(token_hash(sid),))
  with self.store() as c:c.execute('DELETE FROM portals WHERE token_hash=?',(p['token_hash'],))
 async def respond(self,scope,receive,send,status=200,**data):
  r=JSONResponse(data,status_code=status,headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})
  return await r(scope,receive,send)
 async def body(self,receive):
  chunks=[];n=0
  while True:
   message=await receive()
   if message['type']!='http.request':raise ValueError('درخواست ناقص است.')
   n+=len(message.get('body',b''))
   if n>8*1024*1024:raise ValueError('حداکثر اندازه درخواست ۸ مگابایت است.')
   chunks.append(message.get('body',b''))
   if not message.get('more_body'):return b''.join(chunks)
 async def __call__(self,scope,receive,send):
  if scope['type']!='http':return await self.app(scope,receive,send)
  path=scope['path'];method=scope['method'];headers={k.decode().lower():v.decode('latin1') for k,v in scope['headers']}
  if not path.startswith('/api/') or path=='/api/health':
   tok=bind(self.root)
   try:return await self.app(scope,receive,send)
   finally:unbind(tok)
  cookie=SimpleCookie()
  try:cookie.load(headers.get('cookie',''))
  except Exception:cookie=SimpleCookie()
  portal_cookie=cookie[self.cookie].value if self.cookie in cookie else '';p,u=self.origin(portal_cookie)
  raw_cid=headers.get('x-behnova-company','')
  try:
   if raw_cid and (not raw_cid.isascii() or not raw_cid.isdigit() or len(raw_cid)>8):raise ValueError()
   cid=int(raw_cid) if raw_cid else p['active_id'] if p else 1
   if cid<1:raise ValueError()
  except ValueError:return await self.respond(scope,receive,send,400,error='شناسه شرکت نامعتبر است.')
  if p and not self.allowed(p,u,cid):return await self.respond(scope,receive,send,403,error='اجازه دسترسی به شرکت انتخاب‌شده را ندارید.')
  if not p and cid!=1:return await self.respond(scope,receive,send,401,error='برای انتخاب شرکت ابتدا وارد حساب شوید.')
  raw=None;forward_scope=dict(scope);forward_scope['state']=dict(scope.get('state',{}));target=None;session={}
  if p:
   try:target,t,session=self.ticket(p,u,cid)
   except (PermissionError,ValueError):return await self.respond(scope,receive,send,403,error='شرکت یا نشست مجاز پیدا نشد.')
   forward_scope['state']['company_origin_validator']=lambda:self.allowed(*self.origin(portal_cookie),cid)
  if path.startswith('/api/companies'):
   if not p:return await self.respond(scope,receive,send,401,error='برای مدیریت شرکت وارد حساب شوید.')
   if method not in ['GET','HEAD'] and not secrets.compare_digest(headers.get('x-csrf-token',''),session['csrf']):return await self.respond(scope,receive,send,403,error='نشست معتبر نیست؛ صفحه را دوباره باز کنید.')
   if path=='/api/companies' and method=='GET':return await self.respond(scope,receive,send,**self.context(p,u,cid))
   if method in ['POST','PUT']:
    try:
     raw=await self.body(receive);d=json.loads(raw)
     if not isinstance(d,dict):raise ValueError()
    except (ValueError,TypeError):return await self.respond(scope,receive,send,400,error='ساختار درخواست شرکت معتبر نیست.')
    if path=='/api/companies/switch' and method=='POST':
     new=d.get('company_id')
     if type(new) is not int or not self.allowed(p,u,new):return await self.respond(scope,receive,send,403,error='اجازه ورود به این شرکت را ندارید.')
     try:new_m,_,new_s=self.ticket(p,u,new)
     except ValueError:return await self.respond(scope,receive,send,404,error='شرکت پیدا نشد.')
     self.retire_previews(target,session['sid'])
     with self.store() as c:c.execute('UPDATE portals SET active_id=? WHERE token_hash=?',(new,p['token_hash']))
     return await self.respond(scope,receive,send,ok=True,csrf=new_s['csrf'],company_context=self.context(p,u,new))
    if not self.is_manager(p,u):return await self.respond(scope,receive,send,403,error='تعریف و تغییر شرکت فقط برای مدیر مجموعه مجاز است.')
    name=d.get('name','')
    if not isinstance(name,str) or not name.strip() or len(name.strip())>120 or any(ord(ch)<32 for ch in name):return await self.respond(scope,receive,send,400,error='نام شرکت باید متن معتبر تا ۱۲۰ نویسه باشد.')
    name=name.strip()
    with self.lock:
     with self.store() as c:
      try:rename_id=int(path.rsplit('/',1)[1]) if method=='PUT' else 0
      except ValueError:rename_id=0
      if c.execute('SELECT 1 FROM companies WHERE name=? AND id<>?',(name,rename_id)).fetchone():return await self.respond(scope,receive,send,409,error='شرکتی با این نام قبلاً تعریف شده است.')
      if path=='/api/companies' and method=='POST':
       ident=c.execute('INSERT INTO companies(name,guid,created_at) VALUES(?,?,?)',(name,uuid.uuid4().hex,self.root.tehran_now().isoformat())).lastrowid
      elif path.startswith('/api/companies/') and method=='PUT':
       try:ident=int(path.rsplit('/',1)[1])
       except ValueError:return await self.respond(scope,receive,send,404,error='شرکت پیدا نشد.')
       if c.execute('UPDATE companies SET name=? WHERE id=?',(name,ident)).rowcount!=1:return await self.respond(scope,receive,send,404,error='شرکت پیدا نشد.')
      else:return await self.respond(scope,receive,send,404,error='مسیر شرکت پیدا نشد.')
    # Initialization is lazy, under a lock. No existing HR data is copied.
    return await self.respond(scope,receive,send,ok=True,id=ident,company_context=self.context(p,u,cid))
   return await self.respond(scope,receive,send,405,error='عملیات شرکت مجاز نیست.')
  if path=='/api/login' and method=='POST':
   global_login_key='company-login-ip:'+str((scope.get('client') or ('unknown',0))[0])
   with self.root.db() as c:
    if c.execute('SELECT COUNT(*) FROM login_failures WHERE key=? AND created>?',(global_login_key,time.time()-300)).fetchone()[0]>=10:return await self.respond(scope,receive,send,429,error='تلاش ورود بیش از حد؛ پنج دقیقه دیگر دوباره امتحان کنید.')
   try:
    raw=await self.body(receive);login_data=json.loads(raw)
    with self.root.db() as c:legacy_exact=c.execute('SELECT 1 FROM users WHERE username=?',(str(login_data.get('username','')).strip() if isinstance(login_data,dict) else '',)).fetchone()
    if isinstance(login_data,dict) and str(login_data.get('username','')).split('/',1)[-1].startswith(RESERVED) and not legacy_exact:return await self.respond(scope,receive,send,401,error='اطلاعات ورود نادرست است.')
   except (ValueError,TypeError):return await self.respond(scope,receive,send,400,error='درخواست ورود نامعتبر است.')
  if path=='/api/login' and method=='POST' and not p:
   try:d=json.loads(raw)
   except (ValueError,TypeError):return await self.respond(scope,receive,send,400,error='درخواست ورود نامعتبر است.')
   if not isinstance(d,dict):return await self.respond(scope,receive,send,400,error='درخواست ورود نامعتبر است.')
   username=str(d.get('username','')).strip();chosen=1
   if legacy_exact:pass
   elif '/' in username:
    code,username=username.split('/',1)
    if not code.isascii() or not code.isdigit():return await self.respond(scope,receive,send,401,error='اطلاعات ورود نادرست است.')
    chosen=int(code);d['username']=username
   else:
    with self.root.db() as c:root_match=c.execute('SELECT 1 FROM users WHERE username=?',(username,)).fetchone()
    if not root_match:
     with self.store() as c:ids=[(r[0],r[1]) for r in c.execute('SELECT id,guid FROM companies WHERE id<>1')]
     matches=[]
     for ident,guid in ids:
      file=self.root.DATA_DIR/'companies'/guid/'hr.sqlite3'
      if not file.is_file():continue
      with contextlib.closing(sqlite3.connect(file)) as c:
       if c.execute('SELECT 1 FROM users WHERE username=?',(username,)).fetchone():matches.append(ident)
     if len(matches)>1:return await self.respond(scope,receive,send,401,error='برای حساب شرکتی از «شماره شرکت/نام کاربری» استفاده کنید.')
     if matches:chosen=matches[0]
   if username.startswith(RESERVED) and not legacy_exact:return await self.respond(scope,receive,send,401,error='اطلاعات ورود نادرست است.')
   try:target=self.get_module(chosen)
   except ValueError:return await self.respond(scope,receive,send,401,error='اطلاعات ورود نادرست است.')
   cid=chosen;raw=json.dumps(d).encode()
   anon=self.unpack(self.root,cookie['behnova_session'].value) if 'behnova_session' in cookie else {}
   session={'csrf':anon.get('csrf','')}
  if target is None:target=self.root
  # Account security belongs to the original authenticated identity, not a bridge account.
  account=path=='/api/password' or path.startswith('/api/mfa/') or path=='/api/sessions/revoke-others'
  if p and path=='/api/desktop/stop' and self.is_manager(p,u):account=True
  if p and account:
   if method not in ['GET','HEAD'] and not secrets.compare_digest(headers.get('x-csrf-token',''),session['csrf']):return await self.respond(scope,receive,send,403,error='نشست معتبر نیست؛ صفحه را دوباره باز کنید.')
   target,_,session=self.ticket(p,u,p['origin_id']);headers['x-csrf-token']=session['csrf']
  if p and path.startswith('/api/users/') and method in ['PUT','DELETE','POST']:
   try:
    ident=int(path.split('/')[3])
    with target.db() as c:protected=c.execute('SELECT username FROM users WHERE id=?',(ident,)).fetchone()
    if target._COMPANY_ID!=1 and protected and protected[0].startswith(RESERVED):return await self.respond(scope,receive,send,403,error='حساب مدیر مجموعه از پنل شرکت قابل حذف یا تغییر نیست.')
   except (ValueError,IndexError):pass
  if path=='/api/users' and method=='POST':
   raw=await self.body(receive)
   try:
    d=json.loads(raw)
    if isinstance(d,dict) and (str(d.get('username','')).startswith(RESERVED) or '/' in str(d.get('username',''))):return await self.respond(scope,receive,send,400,error='نام کاربری شامل عبارت رزروشده یا / نباشد.')
   except ValueError:pass
  # Never expose a physical path or allow the caller to select a DB filename.
  if session:
   cookie['behnova_session']=self.pack(target,session);headers['cookie']='; '.join(k+'='+v.coded_value for k,v in cookie.items())
  if raw is not None:headers['content-length']=str(len(raw))
  forward_scope['headers']=[(k.encode(),v.encode('latin1')) for k,v in headers.items()]
  events=[]
  async def capture(message):events.append(message)
  sent=False
  async def replay():
   nonlocal sent
   if not sent:sent=True;return {'type':'http.request','body':raw,'more_body':False}
   return await receive()
  tok=bind(target);identity_token=bind_identity((self.get_module(p['origin_id']),u) if p and target._COMPANY_ID!=p['origin_id'] else None)
  try:
   await (self.app if target is self.root else target.app)(forward_scope,replay if raw is not None else receive,capture)
  finally:unbind_identity(identity_token);unbind(tok)
  if not events:return
  if path=='/api/login' and method=='POST' and events[0].get('status') in [401,429]:
   with self.root.db() as c:c.execute('INSERT INTO login_failures(key,created) VALUES(?,?)',(global_login_key,time.time()))
  start=events[0];status=start.get('status',500);out_headers=start.get('headers',[]);new_session=None
  for k,v in out_headers:
   if k.lower()==b'set-cookie':
    parsed=SimpleCookie();parsed.load(v.decode('latin1'))
    if 'behnova_session' in parsed:new_session=self.unpack(target,parsed['behnova_session'].value)
  # Starlette may omit Set-Cookie for an unmodified existing session.
  if path=='/api/session' and status==200 and not p and not new_session and 'behnova_session' in cookie:
   new_session=self.unpack(target,cookie['behnova_session'].value)
  new_cookie=None
  if path in ['/api/login','/api/setup'] and status==200 and new_session:
   if p:self.logout(p)
   new_cookie,p,u=self.create_portal(target,new_session);cid=target._COMPANY_ID
  elif path=='/api/session' and status==200 and not p and new_session and new_session.get('sid'):
   # Adopt an already authenticated legacy root session; never force a logout just
   # to obtain company context. create_portal revalidates the live DB session.
   legacy_data=json.loads(b''.join(e.get('body',b'') for e in events if e['type']=='http.response.body'))
   if legacy_data.get('user'):
    new_cookie,p,u=self.create_portal(target,new_session);cid=target._COMPANY_ID
  elif p and new_session and new_session.get('sid'):
   with self.store() as c:c.execute('UPDATE tickets SET sid=?,csrf=?,uid=? WHERE portal_hash=? AND company_id=?',(self.enc(new_session['sid']),new_session['csrf'],new_session['uid'],p['token_hash'],target._COMPANY_ID))
  if path=='/api/logout' and status==200:
   self.logout(p);p=None;u=None
  body=b''.join(e.get('body',b'') for e in events if e['type']=='http.response.body')
  typ=next((v for k,v in out_headers if k.lower()==b'content-type'),b'')
  if b'application/json' in typ and path in ['/api/session','/api/login','/api/setup'] and status==200:
   d=json.loads(body);d['company_context']=self.context(p,u,cid)
   if p and d.get('user'):d['user']['mfa_enabled']=bool(u.get('mfa_secret'))
   if 'can_stop' in d:d['can_stop']=bool(d['can_stop'] and self.is_manager(p,u))
   body=json.dumps(d,ensure_ascii=False).encode()
  out_headers=[(k,v) for k,v in out_headers if k.lower() not in [b'content-length',b'x-behnova-company']]
  out_headers.append((b'content-length',str(len(body)).encode()));out_headers.append((b'x-behnova-company',str(cid).encode()))
  if new_cookie:
   v=self.cookie+'='+new_cookie+'; Path=/; HttpOnly; SameSite=Lax; Max-Age='+str(self.root.SESSION_SECONDS)
   if __import__('os').environ.get('COOKIE_SECURE')=='1':v+='; Secure'
   out_headers.append((b'set-cookie',v.encode()))
  if path=='/api/logout' and status==200:out_headers.append((b'set-cookie',(self.cookie+'=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0').encode()))
  await send({'type':'http.response.start','status':status,'headers':out_headers});await send({'type':'http.response.body','body':body})
