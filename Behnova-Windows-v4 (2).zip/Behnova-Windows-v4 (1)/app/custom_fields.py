"""Registry-backed custom columns, canonical validation and empty dynamic XLSX templates."""
import json,secrets,re,hashlib,io
from decimal import Decimal,InvalidOperation
from functools import lru_cache
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.comments import Comment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.utils import get_column_letter
TYPES={'text':'متن','number':'عدد','date':'تاریخ شمسی','select':'فهرست گزینه‌ها'}
MAX_FIELDS=50

def init_registry(c):
 c.execute("CREATE TABLE IF NOT EXISTS custom_fields(key TEXT PRIMARY KEY,label TEXT NOT NULL,kind TEXT NOT NULL,options TEXT NOT NULL DEFAULT '[]',required INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,position INTEGER NOT NULL,version INTEGER NOT NULL DEFAULT 1,aliases TEXT NOT NULL DEFAULT '[]')")

def definitions(c,active=None):
 result=[]
 for row in c.execute('SELECT * FROM custom_fields ORDER BY position,key'):
  value=dict(row);value['options']=json.loads(value['options']);value['aliases']=json.loads(value['aliases']);value['active']=bool(value['active']);value['required']=bool(value['required'])
  if active is None or value['active']==active:result.append(value)
 return result

def schema_for(c,base_fields,base_dates,base_options,normalize=lambda s:s):
 all_defs=definitions(c)
 # Keep pre-existing manager fields intact if their names match new built-in stages.
 occupied={normalize(label) for d in all_defs for label in [d['label']]+d['aliases']}
 adjusted=[]
 for key,label in base_fields:
  if key.startswith('settlement_'):
   original=label;index=1
   while normalize(label) in occupied:
    label=original+' (پیگیری تسویه'+(' '+str(index) if index>1 else '')+')';index+=1
  adjusted.append((key,label))
 base_fields=adjusted
 active=[d for d in all_defs if d['active']];fields=base_fields+[(d['key'],d['label']) for d in active]
 return {'fields':fields,'keys':[key for key,_ in fields],'dates':base_dates+[d['key'] for d in active if d['kind']=='date'],'defs':active,'all_defs':all_defs,'options':base_options|{d['key']:d['options'] for d in active if d['kind']=='select'},'revision':hashlib.sha256(json.dumps({'base_fields':base_fields,'base_dates':base_dates,'base_options':base_options,'custom':all_defs},ensure_ascii=False,sort_keys=True).encode()).hexdigest()}

def normalized_definition(payload,existing,all_defs,reserved,normalize):
 if not isinstance(payload.get('label'),str):raise ValueError('نام فیلد باید متن باشد.')
 label=payload['label'].strip()
 if not 1<=len(label)<=80 or label[0] in '=+-@' or any(ord(ch)<32 or ord(ch)==127 for ch in label):raise ValueError('نام فیلد باید ۱ تا ۸۰ کاراکتر و بدون خط جدید یا علامت فرمول در ابتدا باشد.')
 occupied={normalize(value) for value in reserved}
 if existing:occupied.discard(normalize(existing['label']))
 for item in all_defs:
  if not existing or item['key']!=existing['key']:occupied.update(normalize(value) for value in [item['label']]+item['aliases'])
 if normalize(label) in occupied:raise ValueError('نام فیلد تکراری یا معادل یکی از عنوان‌های قبلی است.')
 kind=payload.get('kind',existing['kind'] if existing else 'text')
 if kind not in TYPES:raise ValueError('نوع فیلد معتبر نیست.')
 if existing and kind!=existing['kind']:raise ValueError('برای حفاظت از اطلاعات قبلی، نوع فیلد قابل تغییر نیست؛ فیلد دیگری بسازید.')
 for flag in ['required','active']:
  if flag in payload and type(payload[flag]) is not bool:raise ValueError('وضعیت اجباری یا فعال نامعتبر است.')
 values=payload.get('options',existing['options'] if existing else [])
 if not isinstance(values,list) or len(values)>50 or any(not isinstance(v,str) for v in values):raise ValueError('گزینه‌ها باید فهرستی با حداکثر ۵۰ مقدار باشند.')
 values=[value.strip() for value in values]
 if kind=='select':
  if not values or any(not value or len(value)>100 or any(ord(ch)<32 for ch in value) for value in values):raise ValueError('برای فهرست، ۱ تا ۵۰ گزینه غیرخالی با حداکثر ۱۰۰ کاراکتر وارد کنید.')
  if len({normalize(value) for value in values})!=len(values):raise ValueError('گزینه تکراری یا معادل تکراری است.')
 else:values=[]
 position=payload.get('position',existing['position'] if existing else max([d['position'] for d in all_defs],default=0)+10)
 if type(position)!=int or not 0<=position<=99999:raise ValueError('ترتیب نمایش باید عدد صحیح از صفر تا ۹۹۹۹۹ باشد.')
 aliases=list(existing['aliases']) if existing else []
 if existing and existing['label']!=label and existing['label'] not in aliases:aliases.append(existing['label'])
 if len(aliases)>100:raise ValueError('تعداد تغییر نام زیاد است؛ فیلد جدید بسازید.')
 return {'label':label,'kind':kind,'options':values,'required':payload.get('required',existing['required'] if existing else False),'active':payload.get('active',existing['active'] if existing else True),'position':position,'aliases':aliases}

def value_for(value,definition,parse_date,normalize,required=True):
 text=str(value if value is not None else '').strip()
 if not text:
  if required and definition['required']:raise ValueError('تکمیل «'+definition['label']+'» الزامی است.')
  return ''
 if len(text)>1000:raise ValueError('مقدار «'+definition['label']+'» نباید بیش از ۱۰۰۰ کاراکتر باشد.')
 kind=definition['kind']
 if kind=='date':
  try:return parse_date(text)
  except ValueError:raise ValueError('تاریخ «'+definition['label']+'» نامعتبر است؛ نمونه ۱۴۰۳/۰۱/۰۱.')
 if kind=='number':
  raw=text.translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')).replace('٫','.')
  if len(raw)>60:raise ValueError('عدد «'+definition['label']+'» بیش از حد طولانی است.')
  try:
   number=Decimal(raw)
   if not number.is_finite() or number.copy_abs()>=Decimal('1e24') or number.as_tuple().exponent < -12:raise InvalidOperation
   canonical=format(number,'f')
   if '.' in canonical:canonical=canonical.rstrip('0').rstrip('.')
   return canonical if number else '0'
  except InvalidOperation:raise ValueError('«'+definition['label']+'» باید عدد متناهی با حداکثر ۲۴ رقم صحیح و ۱۲ رقم اعشار باشد.')
 if kind=='select':
  match={normalize(v):v for v in definition['options']}.get(normalize(text))
  if match is None:raise ValueError('مقدار «'+text+'» برای «'+definition['label']+'» مجاز نیست. گزینه‌ها: '+'، '.join(definition['options']))
  return match
 return text

def new_key():return 'cf_'+secrets.token_hex(8)

def template_bytes(schema,base_options):
 return _template_cached(json.dumps({'fields':schema['fields'],'defs':schema['defs'],'options':base_options|{d['key']:d['options'] for d in schema['defs'] if d['kind']=='select'}},ensure_ascii=False,sort_keys=True))

@lru_cache(maxsize=4)
def _template_cached(signature):
 spec=json.loads(signature);defs={d['key']:d for d in spec['defs']};columns=[]
 for key,label in spec['fields']:columns.extend([('_first_name','نام'),('_last_name','نام خانوادگی')] if key=='name' else [(key,label)])
 book=openpyxl.Workbook();book.properties.creator='BEHNOVA';book.properties.title='BEHNOVA — نمونه فایل ورودی';sheet=book.active;sheet.title='کارکنان';sheet.sheet_view.rightToLeft=True;sheet.append([label for _,label in columns]);sheet.freeze_panes='A2';sheet.auto_filter.ref=f'A1:{get_column_letter(len(columns))}1';sheet.row_dimensions[1].height=42
 lists=book.create_sheet('گزینه‌ها');lists.sheet_state='hidden';list_column=0
 for index,(key,label) in enumerate(columns,1):
  letter=get_column_letter(index);definition=defs.get(key);sheet.column_dimensions[letter].width=30;cell=sheet.cell(1,index);cell.data_type='s';cell.font=Font(name='Tahoma',size=12,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='12665C');cell.alignment=Alignment(horizontal='right',wrap_text=True)
  kind=TYPES[definition['kind']] if definition else 'فیلد اصلی';required=bool(definition and definition['required']) or key in ['code','_first_name','_last_name'];cell.comment=Comment(kind+'؛ '+('الزامی' if required else 'اختیاری'),'BEHNOVA')
  if key in spec['options']:
   list_column+=1;values=spec['options'][key];list_letter=get_column_letter(list_column)
   for row,value in enumerate(values,1):lists.cell(row,list_column,value).data_type='s'
   name=f'BN_LIST_{list_column}';book.defined_names.add(DefinedName(name,attr_text=f"'گزینه‌ها'!${list_letter}$1:${list_letter}${len(values)}"));validation=DataValidation(type='list',formula1='='+name,allow_blank=not required);validation.showErrorMessage=True;validation.errorTitle='مقدار نامعتبر';validation.error='یکی از گزینه‌های فهرست را انتخاب کنید.';sheet.add_data_validation(validation);validation.add(f'{letter}2:{letter}5001')
  if key in ['children','dependents']:
   validation=DataValidation(type='whole',operator='between',formula1=0,formula2=50,allow_blank=True);validation.showErrorMessage=True;sheet.add_data_validation(validation);validation.add(f'{letter}2:{letter}5001')
  if key in ['code','job_code','insurance_number'] or key.startswith('settlement_') or (definition and definition['kind'] in ['text','date','select']):
   sheet.column_dimensions[letter].number_format='@'
   for row in range(2,5002):sheet.cell(row,index).number_format='@'
 guide=book.create_sheet('راهنما');guide.sheet_view.rightToLeft=True
 notes=[('نمونه فایل ورودی — BEHNOVA','این فایل خالی از رکورد نمونه است و بر اساس فیلدهای فعال همین سیستم ساخته شده است.'),('نحوه تکمیل','برگه کارکنان را تکمیل کنید. نام و نام خانوادگی جدا هستند؛ کد پرسنلی و هر دو بخش نام لازم‌اند.'),('فیلدهای دلخواه','برای دریافت عنوان‌ها، ترتیب و گزینه‌های به‌روز، همیشه از دکمه «نمونه فایل ورودی» داخل برنامه فایل تازه بگیرید. فایل همراه بسته فقط ستون‌های پایه را دارد.'),('کدها','کد پرسنلی، کد شغل و شماره بیمه را متن وارد کنید تا صفرها حفظ شوند. برای فیلد شماره یا شناسه دلخواه، نوع متن را در برنامه انتخاب کنید؛ نوع عدد صفرهای ابتدایی را حذف می‌کند.'),('تاریخ','تاریخ‌ها را شمسی مثل ۱۴۰۳/۰۱/۰۱ بنویسید. فیلد تاریخ دلخواه مستقل از تاریخ استخدام است.'),('پیش‌نمایش','انتخاب فایل چیزی ثبت نمی‌کند. تغییرات و مقادیر پاک‌شونده را بررسی و سپس ثبت نهایی را تأیید کنید.'),('ویرایش','در ویرایش بر اساس کد پرسنلی، ستونِ موجود ولی خالی مقدار قبلی را پاک می‌کند. فیلدهای دلخواه، چهار تاریخ تسویه و هفت فیلد تکمیلی اگر اصلاً در فایل قدیمی نباشند، مقدار قبلی‌شان حفظ می‌شود. سایر ستون‌های اصلی رفتار جایگزینی کامل دارند.'),('فیلد اجباری','برای فرد جدید، فیلد اجباری باید تکمیل شود. در ویرایش نیز مقدار نهایی آن نباید خالی باشد.'),('سقف ورود','هر بار حداکثر ۵۰۰۰ ردیف واقعی و فایل حداکثر ۸ مگابایت. ردیف‌های خالی و قالب‌بندی شمرده نمی‌شوند.'),('بدون حذف','افرادی که در فایل نیستند حذف یا تغییر داده نمی‌شوند. کد پرسنلی را عوض نکنید؛ کد دیگر به معنی فرد دیگر است.'),('سرستون','نام ستون‌ها را عوض نکنید. برای تغییر نام فیلد از مدیریت فیلدهای دلخواه استفاده کنید. عنوان‌های قبلی فیلد فعال هم هنگام ورود شناخته می‌شوند.')]
 notes += [('پیگیری تسویه','چهار تاریخ تسویه مستقل و اختیاری‌اند. خالی یعنی ثبت نشده. ثبت پرداخت، امضا یا تحویل به مالی، تاریخ مرحله دیگر را پر نمی‌کند. در ورود مجدد خروجی، عبارت ثبت نشده برای این چهار تاریخ به معنی مقدار خالی است.')]
 notes += [('فیلد: '+d['label'],TYPES[d['kind']]+'؛ '+('الزامی' if d['required'] else 'اختیاری')+('؛ گزینه‌ها: '+'، '.join(d['options']) if d['kind']=='select' else '')) for d in spec['defs']]
 for row in notes:guide.append(row)
 for row in guide:
  for cell in row:cell.data_type='s';cell.font=Font(name='Tahoma',size=12);cell.alignment=Alignment(horizontal='right',vertical='top',wrap_text=True)
 guide.column_dimensions['A'].width=32;guide.column_dimensions['B'].width=110
 for index in range(1,guide.max_row+1):guide.row_dimensions[index].height=50
 book.active=0;output=io.BytesIO();book.save(output);return output.getvalue()
