"""Stream physical XLSX rows without expanding its claimed/formatted dimensions.

The application pins openpyxl 3.1.5. Its standard read-only iterator fills gaps up
through max_row/max_column, counting blank formatting as thousands of records.
Reuse that version's streaming cell parser (including styles/dates/formulas),
but consume the sparse physical rows directly. Regression tests cover the pinned
private interface, forged dimensions, distant formatting and typed cell values.
"""
from openpyxl.worksheet._reader import WorkSheetParser


def has_value(value):
    return value is not None and (not isinstance(value,str) or bool(value.strip()))


def sparse_rows(workbook):
    if 'شرکت' in workbook.sheetnames:
        from company_context import module
        try:current=module()
        except RuntimeError:current=None
        marker=workbook['شرکت']
        if current is not None and getattr(current,'_COMPANY_GUID',None) and marker['A1'].value=='شناسه شرکت' and marker['B1'].value!=current._COMPANY_GUID:
            raise ValueError('این فایل متعلق به شرکت دیگری است؛ نمونه فایل ورودی را از شرکت فعال دریافت کنید.')
    sheet=workbook.active
    with sheet._get_source() as source:
        parser=WorkSheetParser(source,sheet._shared_strings,
            data_only=workbook.data_only,epoch=workbook.epoch,
            date_formats=workbook._date_formats,
            timedelta_formats=workbook._timedelta_formats)
        for row_number,cells in parser.parse():
            values={cell['column']:cell['value'] for cell in cells if has_value(cell['value'])}
            if not values:continue
            if any(not 1<=column<=16384 for column in values):
                raise ValueError('ستون‌های فایل از محدوده استاندارد اکسل خارج‌اند.')
            yield row_number,values
