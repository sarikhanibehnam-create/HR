"""Bounded sparse XLSX parsing and deterministic, optimistic two-phase imports."""
import io,json,hashlib,zipfile
from datetime import date,datetime
import openpyxl,jdatetime
from excel_rows import sparse_rows,has_value

class ImportProblem(ValueError):
 def __init__(self,message,errors=None,status=400):super().__init__(message);self.errors=errors or [];self.status=status

def fingerprint(row,keys):
 if row is None:return None
 return hashlib.sha256(json.dumps([row['id'],row['version']]+[row[k] for k in keys],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def parse_excel(raw,import_columns,imported_name,validate,date_keys):
 if len(raw)>8*1024*1024:raise ImportProblem('حجم فایل بیش از ۸ مگابایت است.')
 with zipfile.ZipFile(io.BytesIO(raw)) as archive:
  if sum(item.file_size for item in archive.infolist())>40*1024*1024:raise ImportProblem('حجم بازشدهٔ فایل بیش از حد مجاز است.')
 book=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=True);iterator=None
 for title in ['کارکنان','پرسنل']:
  if title in book.sheetnames:book.active=book.sheetnames.index(title);break
 try:
  iterator=sparse_rows(book);_,header_values=next(iterator);header=[header_values.get(i) for i in range(1,max(header_values)+1)];columns,split=import_columns(header)
  parsed=[];seen=set();errors=[];count=0
  for line,values in iterator:
   data={key:values.get(index+1) for index,key in columns}
   if not any(has_value(value) for value in data.values()):continue
   count+=1
   if count>5000:raise ImportProblem('فایل بیش از ۵۰۰۰ ردیف دارای اطلاعات پرسنل دارد؛ هر بار حداکثر ۵۰۰۰ ردیف داده وارد کنید.')
   for key in date_keys:
    if isinstance(data.get(key),(date,datetime)):data[key]=data[key].strftime('%Y/%m/%d')
   try:
    imported_name(data,split);record=validate(data)
    if record['code'] in seen:raise ValueError('کد پرسنلی تکراری در فایل')
    seen.add(record['code']);parsed.append({'line':line,'value':record})
   except ValueError as error:errors.append(f'ردیف {line}: {error}')
  if errors:raise ImportProblem('هیچ ردیفی ذخیره نشد. خطاها را اصلاح کنید.',errors[:30])
  if not parsed:raise ImportProblem('فایل داده‌ای ندارد.')
  return parsed,{key for _,key in columns}
 finally:
  if iterator is not None:iterator.close()
  book.close()

def make_plan(c,parsed,present,mode,keys,fields,extra_keys):
 if mode not in ['new','upsert']:raise ImportProblem('نوع ورود نامعتبر است.')
 existing={r['code']:dict(r) for r in c.execute('SELECT * FROM employees')};duplicates=sorted({r['value']['code'] for r in parsed}&existing.keys())
 if duplicates and mode!='upsert':raise ImportProblem('کدهای موجود در سامانه: '+'، '.join(duplicates[:12])+'؛ برای ویرایش آن‌ها گزینه به‌روزرسانی را فعال کنید.',status=409)
 labels=dict(fields);items=[];records=[];baseline={};counts={'total':len(parsed),'added':0,'updated':0,'unchanged':0,'cleared_values':0}
 for entry in parsed:
  value=dict(entry['value']);old=existing.get(value['code']);baseline[value['code']]=fingerprint(old,keys)
  if old:
   for key in extra_keys-present:value[key]=old[key]
  changes=[{'field':key,'label':labels[key],'before':old[key] if old else '', 'after':value[key],'cleared':bool(old and old[key] not in ['',None] and value[key] in ['',None])} for key in keys if (old and old[key]!=value[key]) or (not old and value[key] not in ['',None])]
  status='new' if old is None else 'update' if changes else 'unchanged'
  counts[{'new':'added','update':'updated','unchanged':'unchanged'}[status]]+=1;counts['cleared_values']+=sum(change['cleared'] for change in changes)
  items.append({'line':entry['line'],'code':value['code'],'name':value['name'],'status':status,'changes':changes});records.append({'status':status,'value':value})
 return {'records':records,'baseline':baseline,'items':items,'counts':counts}

def page_of(plan,page=1):
 pages=max(1,(len(plan['items'])+49)//50)
 if type(page)!=int or page<1 or page>pages:raise ImportProblem('شماره صفحه پیش‌نمایش نامعتبر است.')
 items=json.loads(json.dumps(plan['items'][(page-1)*50:page*50],ensure_ascii=False))
 for item in items:
  for change in item['changes']:
   if change['field'] in plan.get('date_keys',['birth_date','hire_date','contract_end']):
    for side in ['before','after']:
     if change[side]:change[side]=jdatetime.date.fromgregorian(date=date.fromisoformat(change[side])).strftime('%Y/%m/%d')
 return {'counts':plan['counts'],'items':items,'page':page,'pages':pages}
