"""Bundled desktop server: database-local lock, verified reuse, explicit graceful stop.
Stopped installations can be copied to another local path or computer; copies are independent.
"""
import os,sys,time,json,socket,threading,logging,traceback,webbrowser,urllib.request,ssl,ipaddress
from pathlib import Path
from logging.handlers import RotatingFileHandler
from server_lifecycle import (DataLock,LocalControl,machine_id,data_id,read_json,write_json,
 control_info,control_request,remote_drive,ensure_https,browser_links,private_directory,validate_tls)
from portable_install import relocated,adopt_copy,portable_tls
from activation_ui import ensure_activation
BASE=Path(__file__).resolve().parent.parent
DATA=Path(os.environ.get('BEHNOVA_DATA_DIR',str(BASE/'data'))).resolve()
SETTINGS=DATA/'behnova-server.json'
TLS_DIR=Path(os.environ.get('BEHNOVA_TLS_DIR',str(BASE/'tls'))).resolve()
logger=logging.getLogger('behnova');logger.setLevel(logging.INFO)

def message(text,error=True):
 if os.name=='nt':
  import ctypes
  ctypes.windll.user32.MessageBoxW(None,str(text),'BEHNOVA',((0x10 if error else 0x40)|0x100000|0x10000))
 else:print(text,file=sys.stderr)
def open_browser(url):
 if os.environ.get('BEHNOVA_NO_BROWSER')!='1':webbrowser.open(url,new=2)
def https_opener():
 context=ssl.create_default_context()
 ca=TLS_DIR/'ca.crt';cert=TLS_DIR/'server.crt'
 if ca.exists():context.load_verify_locations(cafile=str(ca))
 elif cert.exists():context.load_verify_locations(cafile=str(cert))
 return urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=context))
def health(url,opener):
 try:
  with opener.open(url+'/api/health',timeout=1.2) as r:return json.load(r)
 except Exception as error:return {'_connection_error':str(error)}
def network_addresses():
 addresses=set()
 try:
  for item in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET):addresses.add(item[4][0])
 except OSError:pass
 try:
  with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.connect(('192.0.2.1',9));addresses.add(s.getsockname()[0])
 except OSError:pass
 return sorted(a for a in addresses if ipaddress.ip_address(a).is_private and not ipaddress.ip_address(a).is_loopback and not ipaddress.ip_address(a).is_unspecified and not ipaddress.ip_address(a).is_multicast)


def main():
 global TLS_DIR
 if '--demo' in sys.argv:message('اجرای نمایشی وجود ندارد. اطلاعات قبلی حذف نشده است.');return
 settings=read_json(SETTINGS);binding=settings.get('binding') or {}
 if remote_drive(BASE) or remote_drive(DATA):
  message('انتقال فایل از طریق شبکه مجاز است، اما اجرای برنامه و بانک از Z: یا مسیر اشتراکی شبکه ایمن نیست. کل پوشه را روی دیسک محلی همین سیستم، مثلاً C:\\BEHNOVA، کپی و START.cmd همان مسیر را اجرا کنید. هیچ اطلاعاتی حذف یا جابه‌جا نشد.')
  return
 ensure_activation(BASE)
 moving=relocated(settings,DATA)
 DATA.mkdir(parents=True,exist_ok=True)
 if os.name!='nt':os.chmod(DATA,0o700)
 shared='--shared' in sys.argv or (not moving and '--local' not in sys.argv and settings.get('mode')=='shared')
 lock=DataLock(DATA)
 if not lock.acquire():
  for _ in range(40):
   info=control_info(DATA)
   try:
    if info:
     current=control_request(info)
     if shared and not current.get('shared') and not current.get('stopping'):
      message('سرور همین پوشه در حالت محلی باز است. ابتدا STOP.cmd را اجرا کنید؛ سپس START-SHARED.cmd را بزنید. اطلاعات حذف نمی‌شود.');return
     if current.get('ready'):open_browser(current['url']);return
   except Exception:pass
   # Legacy versions: read-only verification, never kill a PID from a copied marker.
   legacy=read_json(DATA/'behnova-running.json')
   try:
    url=legacy.get('url','');parsed=__import__('urllib.parse',fromlist=['urlsplit']).urlsplit(url)
    if not info and parsed.hostname=='127.0.0.1':
     found=health(url,https_opener())
     if found.get('instance') and found.get('instance')==legacy.get('instance'):
      open_browser(url);message('نسخه قبلی همین برنامه هنوز باز است. برای نصب اصلاحیه، از تنظیمات پایان اجرا را بزنید و سپس دوباره اجرا کنید.',False);return
   except Exception:pass
   if lock.acquire():break
   time.sleep(.2)
  if lock.file is None:message('قفل واقعی این پوشه هنوز آزاد نشده است؛ وجود یک فایل قدیمی به‌تنهایی مانع اجرا نیست.\nممکن است سرور در حال راه‌اندازی یا توقف باشد. چند لحظه بعد امتحان کنید. اگر ادامه داشت، data/launcher.log و مسیر همین پوشه را به مسئول IT بدهید. پردازش دیگری بسته نشد.');return
 handler=None;control=None;sock=None;server=None
 try:
  private_directory(DATA)
  settings,safety=adopt_copy(DATA,settings)
  if safety:logger.info('Portable copy adopted; previous sessions revoked; safety copy: %s',safety)
  handler=RotatingFileHandler(DATA/'launcher.log',maxBytes=2*1024*1024,backupCount=2,encoding='utf-8');handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));logger.addHandler(handler)
  os.environ['BEHNOVA_DATA_DIR']=str(DATA);os.environ['BEHNOVA_DESKTOP']='1';os.environ['BEHNOVA_SHARED']='1' if shared else '0'
  os.environ.pop('BEHNOVA_DEMO',None);os.environ.pop('SEED_DEMO',None)
  addresses=network_addresses();created=False
  if shared:
   private_directory(TLS_DIR);TLS_DIR,created=portable_tls(TLS_DIR,addresses);os.environ['BEHNOVA_TLS_DIR']=str(TLS_DIR)
  os.environ['COOKIE_SECURE']='1' if shared else '0'
  opener=https_opener()
  os.environ['BEHNOVA_ALLOWED_HOSTS']=','.join(addresses+[socket.gethostname().lower(),socket.getfqdn().lower()])
  import uvicorn
  from app import app
  instance=os.urandom(16).hex();installation=settings.get('installation_id') or os.urandom(16).hex()
  app.state.instance_id=instance;app.state.installation_id=installation
  try:preferred=int(settings.get('port',18940))
  except (ValueError,TypeError):preferred=18940
  if not 18940<=preferred<19040:preferred=18940
  host='0.0.0.0' if shared else '127.0.0.1'
  for port in [preferred]+[p for p in range(18940,19040) if p!=preferred]:
   candidate=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
   if os.name=='nt' and hasattr(socket,'SO_EXCLUSIVEADDRUSE'):candidate.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
   elif os.name!='nt':candidate.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
   try:candidate.bind((host,port));candidate.listen(128);sock=candidate;break
   except OSError:candidate.close()
  if sock is None:raise RuntimeError('درگاه آزاد در بازه 18940 تا 19039 پیدا نشد؛ از درگاه 8765 استفاده نمی‌شود.')
  scheme='https' if shared else 'http';url=f'{scheme}://127.0.0.1:{port}';urls=[f'{scheme}://{a}:{port}' for a in addresses] if shared else []
  app.state.local_url=url;app.state.share_urls=urls
  config=uvicorn.Config(app,host=host,port=port,log_config=None,access_log=False,workers=1,lifespan='on',timeout_graceful_shutdown=20,ssl_certfile=str(TLS_DIR/'server.crt') if shared else None,ssl_keyfile=str(TLS_DIR/'server.key') if shared else None,ssl_version=ssl.PROTOCOL_TLS_SERVER,ssl_ciphers='ECDHE+AESGCM:ECDHE+CHACHA20')
  server=uvicorn.Server(config)
  def shutdown():
   if control:control.info['ready']=False;control.info['stopping']=True
   server.should_exit=True
  app.state.shutdown_callback=shutdown
  for name in ['uvicorn','uvicorn.error']:
   log=logging.getLogger(name);log.handlers=[handler];log.propagate=False;log.setLevel(logging.INFO)
  info={'ready':False,'instance':instance,'url':url,'shared':shared,'share_urls':urls,'installation_id':installation}
  control=LocalControl(DATA,info,app.state.shutdown_callback);control.start()
  binding={'host_id':machine_id(),'data_id':data_id(DATA),'local_url':url,'share_urls':urls,'server_name':socket.gethostname()}
  write_json(SETTINGS,{**settings,'port':port,'mode':'shared' if shared else 'local','installation_id':installation,'binding':binding})
  if shared:
   browser_links(BASE,urls)
   if (TLS_DIR/'ca.crt').exists():
    import shutil
    shutil.copyfile(TLS_DIR/'ca.crt',BASE/'BEHNOVA-Root-CA.crt')
  if created:message('گواهی اختصاصی HTTPS ساخته شد؛ اتصال شبکه رمزنگاری می‌شود.\nمسئول IT باید فقط گواهی عمومی BEHNOVA-Root-CA.crt را روی سرور و دستگاه کاربران نصب و قابل‌اعتماد کند. هشدار گواهی مرورگر را نادیده نگیرید.\nکلیدهای tls و پوشه data را به کاربران ندهید. آدرس و راهنما در CONNECT-TO-SERVER.html است.',False)
  def ready():
   failure=''
   for _ in range(150):
    if server.should_exit:return
    result=health(url,opener);failure=result.get('_connection_error','')
    if result.get('instance')==instance:
     control.info['ready']=True;logger.info('Server ready; shared=%s url=%s',shared,url);open_browser(url);return
    time.sleep(.2)
   logger.error('Startup timeout: %s',failure);server.should_exit=True;message('راه‌اندازی سرور تکمیل نشد. فایل data/launcher.log را بررسی کنید؛ اطلاعات قبلی حذف نشده است.')
  threading.Thread(target=ready,daemon=True).start();server.run(sockets=[sock])
  if not server.started:raise RuntimeError('سرور نتوانست راه‌اندازی را کامل کند؛ گزارش launcher.log را بررسی کنید.')
 except (Exception,SystemExit) as error:
  logger.error('Launcher failed:\n%s',traceback.format_exc())
  message('راه‌اندازی انجام نشد: '+str(error)+'\nمسیر باید محلی و قابل‌نوشتن باشد و ZIP کامل استخراج شده باشد. جزئیات در data/launcher.log است؛ بانک اطلاعاتی حذف یا بازنشانی نشد.')
 finally:
  if control:
   try:control.close()
   except Exception:logger.exception('Control cleanup failed')
  if sock:
   try:sock.close()
   except OSError:pass
  logger.info('Server stopped; releasing installation files')
  if handler:handler.flush();logger.removeHandler(handler);handler.close()
  logging.shutdown();lock.close()

if __name__=='__main__':
 try:main()
 except Exception as error:message('اجرای BEHNOVA انجام نشد: '+str(error)+'\nدسترسی پوشه، کامل استخراج‌شدن بسته و فایل‌های گواهی را بررسی کنید؛ اطلاعات حذف نشده است.')
