"""Pinned public verification key only. Signing key is NEVER part of the HR application."""
PUBLIC_KEY_B64 = 'PkkqNTghrsYLNIXy/3WnwhphBs7zoWVtsu4UI9XYd4A='
