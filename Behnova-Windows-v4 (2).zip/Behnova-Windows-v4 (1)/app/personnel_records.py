"""Scoped repeatable personnel records. Payloads/history encrypted; no seeded HR data."""
import json,re,io,sqlite3
from decimal import Decimal,InvalidOperation
from datetime import date
from fastapi import HTTPException,Request
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
import access_control as ac
import table_sort
from text_search import search_key
from company_context import current_app as A

def field(key,label,typ='text',required=False,choices=None):
 return dict(key=key,label=label,type=typ,required=required,**({'choices':choices} if choices else {}))
def choice(**kw):return [{'value':k,'label':v} for k,v in kw.items()]
YES=choice(unknown='بررسی نشده',yes='مشمول',no='غیرمشمول')
KINDS={
 'children':dict(label='فرزندان و پوشش',date_key='birth_date',fields=[field('name','نام و نام خانوادگی فرزند',required=True),field('birth_date','تاریخ تولد','date'),field('allowance','مشمولیت حق اولاد','select',True,YES),field('insurance','بیمه تکمیلی','select',True,choice(unknown='بررسی نشده',yes='تحت پوشش',no='خارج از پوشش')),field('coverage_from','شروع پوشش بیمه','date'),field('coverage_to','پایان پوشش بیمه','date')]),
 'merits':dict(label='تشویق، تنبیه و امتیاز',date_key='event_date',fields=[field('type','نوع','select',True,choice(reward='تشویق',discipline='تنبیه')),field('title','عنوان',required=True),field('reason','علت','textarea',True),field('event_date','تاریخ وقوع','date',True),field('points','امتیاز مثبت / منفی','decimal',True),field('override_reason','علت تغییر امتیاز الگو')]),
 'welfare':dict(label='رفاهی — ریال',date_key='event_date',fields=[field('category','نوع مزیت',required=True),field('reason','علت','textarea',True),field('amount','مبلغ — ریال','money',True),field('event_date','تاریخ','date',True)]),
 'training':dict(label='دوره‌های آموزشی',date_key='start_date',fields=[field('title','نام دوره',required=True),field('start_date','تاریخ شروع دوره','date',True),field('end_date','تاریخ پایان دوره','date'),field('hours','مدت دوره — ساعت','decimal',True),field('provider','برگزارکننده'),field('status','وضعیت','select',True,choice(completed='گذرانده',ongoing='در حال گذراندن',incomplete='ناتمام')),field('certificate','شماره گواهی / نتیجه')]),
 'education':dict(label='ارتقای تحصیلی',date_key='event_date',fields=[field('degree','مدرک جدید','select',True,[]),field('major','رشته تحصیلی جدید'),field('event_date','تاریخ اخذ / تأیید','date',True)]),
 'career':dict(label='ارتقای شغلی',date_key='event_date',fields=[field('target','فیلد سمت مورد تغییر','select',True,choice(position='سمت',org_position_title='عنوان سمت سازمانی',org_position='سمت سازمانی')),field('title','عنوان سمت جدید',required=True),field('event_date','تاریخ مؤثر','date',True)]),
 'vehicle':dict(label='خودرو پرسنلی',date_key='request_date',fields=[field('request_date','تاریخ درخواست','date',True),field('vehicle_type','نوع خودرو',required=True),field('status','وضعیت','select',True,choice(requested='درخواست شده',waiting='در انتظار',delivered='تحویل شده',cancelled='لغو شده')),field('delivery_date','تاریخ تحویل واقعی','date')]),
 'hardship':dict(label='مشاغل سخت و زیان‌آور',date_key='request_date',fields=[field('status','وضعیت درخواست','select',True,choice(unknown='اطلاعات ثبت نشده',not_requested='درخواست نداده',pending='درخواست داده — در بررسی',approved='درخواست تأیید شده',rejected='درخواست رد شده')),field('request_date','تاریخ درخواست','date'),field('result_date','تاریخ نتیجه','date')])
}
for spec in KINDS.values():spec['fields'].append(field('note','توضیحات','textarea'))
ACTIONS={'read':'مشاهده','create':'ثبت','edit':'ویرایش','delete':'حذف','export':'خروجی'}
for kind,spec in KINDS.items():
 for action,label in ACTIONS.items():ac.PERMISSIONS[f'records.{kind}.{action}']=label+' '+spec['label']
for kind in ['merits','education','career']:ac.PERMISSIONS[f'records.{kind}.approve']='تأیید '+KINDS[kind]['label']+(' و اعمال روی پرونده' if kind!='merits' else '')

def init_storage(c):
 c.execute('CREATE TABLE IF NOT EXISTS personnel_records(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,kind TEXT NOT NULL,event_date TEXT NOT NULL DEFAULT "",payload BLOB NOT NULL,version INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,approved_at TEXT NOT NULL DEFAULT "",approved_by INTEGER,created_by INTEGER,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)')
 c.execute('CREATE INDEX IF NOT EXISTS records_employee_kind ON personnel_records(employee_id,kind,deleted,event_date)')
 c.execute('CREATE TABLE IF NOT EXISTS personnel_record_history(id INTEGER PRIMARY KEY AUTOINCREMENT,record_id INTEGER NOT NULL,employee_id INTEGER NOT NULL,kind TEXT NOT NULL,user_id INTEGER,action TEXT NOT NULL,created_at TEXT NOT NULL,before_data BLOB,after_data BLOB)')
 c.execute('CREATE INDEX IF NOT EXISTS records_history ON personnel_record_history(record_id,id)')
 c.execute('CREATE TABLE IF NOT EXISTS personnel_point_templates(id INTEGER PRIMARY KEY AUTOINCREMENT,label TEXT NOT NULL UNIQUE,kind TEXT NOT NULL,points TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,version INTEGER NOT NULL DEFAULT 1)')

def enc(v):return A.CIPHER.encrypt(json.dumps(v,ensure_ascii=False).encode()) if v is not None else None
def dec(v):return json.loads(A.CIPHER.decrypt(v)) if v else None
def kind_spec(kind):
 if not isinstance(kind,str) or kind not in KINDS:raise HTTPException(400,'بخش سوابق نامعتبر است.')
 return KINDS[kind]
def require(u,kind,action):kind_spec(kind);ac.require(u,f'records.{kind}.{action}')
def scoped_employee(c,u,ident):
 row=c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone()
 if not row or not ac.within(u,dict(row)):raise HTTPException(404,'پرونده مجاز پیدا نشد.')
 return dict(row)
def get_record(c,u,ident,action='read'):
 row=c.execute('SELECT * FROM personnel_records WHERE id=?',(ident,)).fetchone()
 if not row:raise HTTPException(404,'سابقه پیدا نشد.')
 require(u,row['kind'],action);employee=scoped_employee(c,u,row['employee_id'])
 return dict(row),employee

def number(v,label,integer=False,signed=False):
 if isinstance(v,bool) or not isinstance(v,(str,int,float)):raise ValueError(label+' نامعتبر است.')
 text=str(v).strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789')).replace('٫','.')
 if not re.fullmatch(r'[+-]?\d+(?:\.\d{1,2})?',text):raise ValueError(label+' باید عدد معتبر، بدون جداکننده هزارگان باشد.')
 try:n=Decimal(text)
 except InvalidOperation:raise ValueError(label+' نامعتبر است.')
 maximum=Decimal('999999999999999') if integer else Decimal('100000')
 if abs(n)>maximum or integer and n!=n.to_integral_value() or not signed and n<0:raise ValueError(label+' خارج از محدوده مجاز است.')
 return str(int(n)) if integer or n==n.to_integral_value() else format(n.normalize(),'f')

def normalize(kind,p,c,employee,old=None):
 spec=kind_spec(kind)
 if not isinstance(p,dict):raise ValueError('اطلاعات سابقه نامعتبر است.')
 allowed={f['key'] for f in spec['fields']}|{'template_id'}
 if set(p)-allowed:raise ValueError('فیلد ناشناخته در سابقه ارسال شده است.')
 out={}
 for f in spec['fields']:
  key=f['key'];v=p.get(key,'')
  if f['type'] in ['money','decimal']:
   out[key]=number(v,f['label'],f['type']=='money',key=='points');continue
  if not isinstance(v,str):raise ValueError(f['label']+' باید متن باشد.')
  v=v.strip()
  if len(v)>(1000 if f['type']=='textarea' else 180):raise ValueError(f['label']+' بیش از حد طولانی است.')
  if f['required'] and not v:raise ValueError(f['label']+' الزامی است.')
  if f['type']=='date':v=A.parse_date(v)
  if kind=='education' and key=='degree':
   v=A.canonical_option('education',v,A.current_schema(c)['options']['education'])
   if not v:raise ValueError(f['label']+' الزامی است.')
  if f['type']=='select' and not (kind=='education' and key=='degree') and v not in {x['value'] for x in f.get('choices',[])}:raise ValueError(f['label']+' نامعتبر است.')
  out[key]=v
 today=A.tehran_today().isoformat()
 for f in spec['fields']:
  if f['type']=='date' and out[f['key']] and out[f['key']]>today and f['key'] not in ['coverage_to']:raise ValueError(f['label']+' نباید در آینده باشد.')
 def ordered(lo,hi):
  if out.get(lo) and out.get(hi) and out[hi]<out[lo]:raise ValueError('تاریخ پایان نباید قبل از شروع باشد.')
 if kind=='children':
  ordered('coverage_from','coverage_to')
  if (out['coverage_from'] or out['coverage_to']) and out['insurance']=='unknown':raise ValueError('برای ثبت تاریخ پوشش، وضعیت بیمه را مشخص کنید.')
  if out['birth_date'] and out['coverage_from'] and out['coverage_from']<out['birth_date']:raise ValueError('شروع پوشش نباید قبل از تولد باشد.')
 if kind=='welfare' and Decimal(out['amount'])<=0:raise ValueError('مبلغ باید بیشتر از صفر و به ریال باشد.')
 if kind=='training':
  ordered('start_date','end_date')
  if Decimal(out['hours'])<=0:raise ValueError('مدت دوره باید بیشتر از صفر باشد.')
  if out['status']=='completed' and not out['end_date']:raise ValueError('برای دوره گذرانده، تاریخ پایان را ثبت کنید.')
 if kind=='vehicle':
  ordered('request_date','delivery_date')
  if (out['status']=='delivered')!=bool(out['delivery_date']):raise ValueError('تاریخ تحویل واقعی فقط برای وضعیت تحویل‌شده، و در آن وضعیت الزامی است.')
 if kind=='hardship':
  requested=out['status'] in ['pending','approved','rejected'];result=out['status'] in ['approved','rejected']
  if not requested and (out['request_date'] or out['result_date']) or not result and out['result_date']:raise ValueError('تاریخ درخواست و نتیجه باید با وضعیت انتخابی سازگار باشد. تاریخ نامشخص را خالی بگذارید؛ حدس نزنید.')
  ordered('request_date','result_date')
 if kind=='merits':
  points=Decimal(out['points'])
  if not points or out['type']=='reward' and points<0 or out['type']=='discipline' and points>0:raise ValueError('امتیاز تشویق باید مثبت و امتیاز تنبیه منفی باشد.')
  tid=p.get('template_id')
  if tid not in [None,'',0]:
   if type(tid) is not int:raise ValueError('الگوی امتیاز نامعتبر است.')
   template=c.execute('SELECT * FROM personnel_point_templates WHERE id=? AND active=1',(tid,)).fetchone()
   if not template or template['kind']!=out['type']:raise ValueError('الگوی فعال و هم‌نوع انتخاب کنید.')
   if Decimal(template['points'])!=points and not out['override_reason']:raise ValueError('علت تغییر امتیاز پیش‌فرض را بنویسید.')
   out['template_id']=tid;out['template_label']=template['label'];out['template_points']=template['points']
 if kind=='education':out['previous']={k:employee[k] for k in ['education','major']}
 if kind=='career':out['previous']={out['target']:employee[out['target']]}
 return out

def history(c,u,row,action,before,after):
 c.execute('INSERT INTO personnel_record_history(record_id,employee_id,kind,user_id,action,created_at,before_data,after_data) VALUES(?,?,?,?,?,?,?,?)',(row['id'],row['employee_id'],row['kind'],u['id'],action,A.tehran_now().isoformat(timespec='seconds'),enc(before),enc(after)))

def public_record(row,employee):
 data=dict(row);data['payload']=dec(row['payload']);data.update(employee_code=employee['code'],employee_name=employee['name'],department=employee['department'],location=employee['location'],employee_version=employee['version'])
 for f in KINDS[row['kind']]['fields']:
  if f['type']=='date':
   v=data['payload'].get(f['key']);data['payload'][f['key']]=A.fa_date(date.fromisoformat(v)) if v else ''
 return data

def filtered(c,u,kind,p):
 require(u,kind,'read');spec=KINDS[kind]
 lower=A.parse_date(p.get('from',''));upper=A.parse_date(p.get('to',''))
 if lower and upper and lower>upper:raise ValueError('بازه تاریخ معکوس است.')
 ident=p.get('employee_id','');ident=int(ident) if str(ident).isdigit() else None
 if p.get('employee_id') and ident is None:raise ValueError('شناسه پرسنل نامعتبر است.')
 if ident is not None:scoped_employee(c,u,ident)
 q=str(p.get('q','')).strip()
 if len(q)>180:raise ValueError('جست‌وجو بیش از حد طولانی است.')
 q=search_key(q)
 result=[]
 for r in c.execute('SELECT * FROM personnel_records WHERE kind=? AND deleted=0 AND (? IS NULL OR employee_id=?) AND (?="" OR event_date>=?) AND (?="" OR (event_date<>"" AND event_date<=?)) ORDER BY event_date DESC,id DESC',(kind,ident,ident,lower,lower,upper,upper)):
  e=c.execute('SELECT * FROM employees WHERE id=?',(r['employee_id'],)).fetchone()
  if not e or not ac.within(u,dict(e)) or p.get('department') and p['department']!=e['department'] or p.get('location') and p['location']!=e['location']:continue
  item=public_record(dict(r),dict(e))
  for col in ['created_by','approved_by']:
   actor=c.execute('SELECT name FROM users WHERE id=?',(r[col],)).fetchone()
   item[col+'_name']=actor['name'] if actor else ('سیستم / حساب حذف‌شده' if r[col] else '')
  if p.get('status') and item['payload'].get('status')!=p['status']:continue
  if q and q not in search_key(' '.join([e['code'],e['name'],json.dumps(item['payload'],ensure_ascii=False)])):continue
  result.append(item)
 return table_sort.records(result,kind,p,spec)

def summary(rows,kind):
 total=dict(count=len(rows),amount='0',positive='0',negative='0',net='0',hours='0',pending=0)
 def sumkey(k,values=rows):return sum((Decimal(r['payload'].get(k,'0')) for r in values),Decimal(0))
 if kind=='welfare':total['amount']=str(sumkey('amount'))
 if kind=='training':total['hours']=str(sumkey('hours'))
 if kind=='merits':
  approved=[r for r in rows if r['approved_at']];numbers=[Decimal(r['payload']['points']) for r in approved];total.update(positive=str(sum((n for n in numbers if n>0),Decimal(0))),negative=str(sum((n for n in numbers if n<0),Decimal(0))),net=str(sum(numbers,Decimal(0))),pending=len(rows)-len(approved))
 return total

def register(module):
 app=module.app
 KINDS['education']['fields'][0]['choices']=[dict(value=v,label=v) for v in A.OPTIONS['education']]
 app=A.app
 @app.get('/api/records/catalog')
 async def catalog(request:Request):
  u=await A.require_user(request)
  with A.db() as c:templates=[dict(r) for r in c.execute('SELECT * FROM personnel_point_templates ORDER BY id')] if u['role']=='admin' or ac.can(u,'records.merits.read') else []
  import copy
  kinds=copy.deepcopy(KINDS);kinds['education']['fields'][0]['choices']=[dict(value=v,label=v) for v in A.current_schema()['options']['education']]
  return dict(kinds=kinds,templates=templates,currency='IRR',currency_label='ریال')
 @app.get('/api/records/employees')
 async def identities(request:Request):
  u=await A.require_user(request)
  if not any(ac.can(u,f'records.{k}.read') for k in KINDS):raise HTTPException(403,'اجازه مشاهده سوابق فعال نیست.')
  with A.db() as c:rows=[{k:r[k] for k in ['id','version','code','name','department','location']} for r in c.execute('SELECT * FROM employees ORDER BY name') if ac.within(u,dict(r))]
  return dict(rows=rows)
 @app.get('/api/records')
 async def listing(request:Request):
  u=await A.require_user(request);p=request.query_params;kind=p.get('kind','children')
  try:
   offset=int(p.get('offset',0));limit=int(p.get('limit',50))
   if offset<0 or not 1<=limit<=200:raise ValueError('صفحه‌بندی نامعتبر است.')
   with A.db() as c:rows=filtered(c,u,kind,p)
  except ValueError as e:raise HTTPException(400,str(e))
  return dict(rows=rows[offset:offset+limit],total=len(rows),summary=summary(rows,kind),offset=offset,limit=limit)
 @app.post('/api/records')
 async def create(request:Request):
  u=await A.require_user(request);p=await A.json_data(request);kind=p.get('kind');require(u,kind,'create')
  try:
   if type(p.get('employee_id')) is not int:raise ValueError('پرسنل را انتخاب کنید.')
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');employee=scoped_employee(c,u,p['employee_id']);value=normalize(kind,p.get('payload'),c,employee);now=A.tehran_now().isoformat(timespec='seconds')
    cur=c.execute('INSERT INTO personnel_records(employee_id,kind,event_date,payload,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(employee['id'],kind,value.get(KINDS[kind]['date_key'],''),enc(value),u['id'],now,now));row=dict(c.execute('SELECT * FROM personnel_records WHERE id=?',(cur.lastrowid,)).fetchone());history(c,u,row,'ثبت',None,value);A.audit(request,c,'ثبت '+KINDS[kind]['label'],str(row['id']))
  except ValueError as e:raise HTTPException(400,str(e))
  return dict(ok=True,id=row['id'],version=1)
 @app.put('/api/records/{ident}')
 async def edit(request:Request,ident:int):
  u=await A.require_user(request);p=await A.json_data(request)
  try:
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');row,e=get_record(c,u,ident,'edit')
    if row['deleted'] or type(p.get('version')) is not int or p['version']!=row['version']:raise HTTPException(409,'سابقه تغییر کرده؛ دوباره دریافت کنید.')
    if row['approved_at'] and row['kind'] in ['education','career']:raise HTTPException(409,'ارتقای اعمال‌شده قابل بازنویسی نیست؛ رویداد اصلاحی جدید ثبت کنید.')
    value=normalize(row['kind'],p.get('payload'),c,e,dec(row['payload']));c.execute('UPDATE personnel_records SET payload=?,event_date=?,version=version+1,approved_at="",approved_by=NULL,updated_at=? WHERE id=?',(enc(value),value.get(KINDS[row['kind']]['date_key'],''),A.tehran_now().isoformat(timespec='seconds'),ident));history(c,u,row,'ویرایش؛ تأیید قبلی لغو شد' if row['approved_at'] else 'ویرایش',dec(row['payload']),value);A.audit(request,c,'ویرایش '+KINDS[row['kind']]['label'],str(ident))
  except ValueError as e:raise HTTPException(400,str(e))
  return dict(ok=True)
 @app.delete('/api/records/{ident}')
 async def delete(request:Request,ident:int):
  u=await A.require_user(request);p=await A.json_data(request)
  with A.db() as c:
   c.execute('BEGIN IMMEDIATE');row,e=get_record(c,u,ident,'delete')
   if row['deleted'] or type(p.get('version')) is not int or p['version']!=row['version']:raise HTTPException(409,'سابقه تغییر کرده؛ دوباره دریافت کنید.')
   if row['approved_at'] and row['kind'] in ['education','career']:raise HTTPException(409,'ارتقای اعمال‌شده باید با رویداد اصلاحی جدید اصلاح شود.')
   if p.get('confirm') is not True:raise HTTPException(400,'تأیید صریح حذف لازم است.')
   c.execute('UPDATE personnel_records SET deleted=1,version=version+1,updated_at=? WHERE id=?',(A.tehran_now().isoformat(timespec='seconds'),ident));history(c,u,row,'حذف از فهرست',dec(row['payload']),None);A.audit(request,c,'حذف '+KINDS[row['kind']]['label'],str(ident))
  return dict(ok=True)
 @app.post('/api/records/{ident}/approve')
 async def approve(request:Request,ident:int):
  u=await A.require_user(request);p=await A.json_data(request)
  with A.db() as c:
   c.execute('BEGIN IMMEDIATE');row,e=get_record(c,u,ident)
   if row['kind'] not in ['merits','education','career']:raise HTTPException(400,'این بخش مرحله تأیید ندارد.')
   require(u,row['kind'],'approve')
   if row['deleted'] or row['approved_at'] or type(p.get('version')) is not int or row['version']!=p['version']:raise HTTPException(409,'سابقه قبلاً تأیید شده یا تغییر کرده است.')
   value=dec(row['payload'])
   if row['kind'] in ['education','career']:
    if type(p.get('employee_version')) is not int or p['employee_version']!=e['version'] or any(e[k]!=v for k,v in value['previous'].items()):raise HTTPException(409,'اطلاعات جاری پرونده تغییر کرده؛ سابقه پیش‌نویس را بازبینی و دوباره ذخیره کنید.')
    if c.execute('SELECT 1 FROM personnel_records WHERE employee_id=? AND kind=? AND approved_at<>"" AND deleted=0 AND event_date>?',(e['id'],row['kind'],row['event_date'])).fetchone():raise HTTPException(409,'رویداد قدیمی‌تر نباید ارتقای جدیدتر را بازنویسی کند.')
    changes={'education':value['degree'],'major':value['major']} if row['kind']=='education' else {value['target']:value['title']}
    c.execute('UPDATE employees SET '+','.join(k+'=?' for k in changes)+',version=version+1 WHERE id=?',list(changes.values())+[e['id']]);after=dict(c.execute('SELECT * FROM employees WHERE id=?',(e['id'],)).fetchone());A.workforce.capture(c,u['id'],'اعمال '+KINDS[row['kind']]['label'],e,after)
   now=A.tehran_now().isoformat(timespec='seconds');c.execute('UPDATE personnel_records SET approved_at=?,approved_by=?,updated_at=?,version=version+1 WHERE id=?',(now,u['id'],now,ident));history(c,u,row,'تأیید و اعمال' if row['kind']!='merits' else 'تأیید امتیاز',value,value);A.audit(request,c,'تأیید '+KINDS[row['kind']]['label'],str(ident))
  return dict(ok=True)
 @app.get('/api/records/{ident}/history')
 async def record_history(request:Request,ident:int):
  u=await A.require_user(request);ac.require(u,'audit.read')
  with A.db() as c:
   row,e=get_record(c,u,ident);rows=[]
   for h in c.execute('SELECT h.*,u.name AS actor FROM personnel_record_history h LEFT JOIN users u ON u.id=h.user_id WHERE record_id=? ORDER BY h.id DESC LIMIT 200',(ident,)):
    rows.append(dict(id=h['id'],action=h['action'],actor=h['actor'] or 'کاربر حذف‌شده',created_at=h['created_at'],before=dec(h['before_data']),after=dec(h['after_data'])))
  return dict(rows=rows)
 @app.post('/api/records-export')
 async def export(request:Request):
  u=await A.require_user(request);p=await A.json_data(request);kind=p.get('kind');require(u,kind,'export');ac.require(u,'export.excel')
  try:
   with A.db() as c:
    rows=filtered(c,u,kind,p)
    if not rows:raise HTTPException(400,'در محدوده انتخاب‌شده سابقه‌ای برای خروجی وجود ندارد.')
    A.audit(request,c,'خروجی '+KINDS[kind]['label'],str(len(rows)))
  except ValueError as e:raise HTTPException(400,str(e))
  w=Workbook();w.properties.creator='BEHNOVA';s=w.active;s.title='سوابق';s.sheet_view.rightToLeft=True;spec=KINDS[kind]
  s.append(['کد پرسنلی','نام و نام خانوادگی','واحد','محل']+[f['label'] for f in spec['fields']]+['وضعیت تأیید','تاریخ تأیید']+(['شناسه درخواست'] if kind=='vehicle' else ['شناسه سابقه']))
  for r in rows:
   vals=[r['employee_code'],r['employee_name'],r['department'],r['location']]
   for f in spec['fields']:
    v=r['payload'].get(f['key'],'')
    if f['type']=='select':v=next((o['label'] for o in f.get('choices',[]) if o['value']==v),v)
    if f['type'] in ['money','decimal'] and len(Decimal(v).as_tuple().digits)<=15:v=int(Decimal(v)) if Decimal(v)==Decimal(v).to_integral_value() else float(v)
    vals.append(v or ('ثبت نشده' if f['type']=='date' else ''))
   vals.extend(['تأیید شده' if r['approved_at'] else 'تأیید نشده' if kind in ['merits','education','career'] else 'نیاز ندارد',r['approved_at']]);
   vals.append(str(r['id']))
   s.append(vals)
  for row in s:
   for cell in row:
    if isinstance(cell.value,str):cell.data_type='s';cell.number_format='@'
    cell.alignment=Alignment(horizontal='right',wrap_text=True);cell.font=Font(name='Tahoma',size=11)
  for cell in s[1]:cell.fill=PatternFill('solid',fgColor='155F51');cell.font=Font(bold=True,color='FFFFFF')
  for col in s.columns:s.column_dimensions[col[0].column_letter].width=26
  s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
  info=w.create_sheet('شرح گزارش');info.sheet_view.rightToLeft=True
  totals=summary(rows,kind)
  for k,v in [('عنوان',spec['label']),('واحد مبلغ','ریال'),('تعداد سوابق',len(rows)),('جمع رفاهی — ریال',totals['amount']),('امتیاز مثبت تأییدشده',totals['positive']),('امتیاز منفی تأییدشده',totals['negative']),('خالص امتیاز تأییدشده',totals['net']),('مدت آموزش — ساعت',totals['hours']),('فیلترها',json.dumps({k:p.get(k,'') for k in ['from','to','q','employee_id','department','location','status']},ensure_ascii=False)),('تاریخ تهیه',A.fa_date(A.tehran_today()))]:
   info.append([k,v])
   if isinstance(v,str):info.cell(info.max_row,2).data_type='s'
  info.column_dimensions['A'].width=30;info.column_dimensions['B'].width=80;b=io.BytesIO();w.save(b);return A.excel_response(b,'BEHNOVA-Personnel-Records.xlsx')
 @app.post('/api/records-point-templates')
 async def save_template(request:Request):
  u=await A.require_admin(request);p=await A.json_data(request)
  try:
   label=p.get('label','');kind=p.get('kind');points=number(p.get('points'),'امتیاز',signed=True)
   if not isinstance(label,str) or not label.strip() or len(label)>120 or kind not in ['reward','discipline'] or Decimal(points)==0 or kind=='reward' and Decimal(points)<0 or kind=='discipline' and Decimal(points)>0:raise ValueError('عنوان، نوع و علامت امتیاز الگو را بررسی کنید.')
   if type(p.get('active',True)) is not bool:raise ValueError('وضعیت الگو نامعتبر است.')
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE')
    if p.get('id') is not None:
     if type(p['id']) is not int or type(p.get('version')) is not int:raise ValueError('نسخه الگو نامعتبر است.')
     cur=c.execute('UPDATE personnel_point_templates SET label=?,kind=?,points=?,active=?,version=version+1 WHERE id=? AND version=?',(label.strip(),kind,points,int(p.get('active',True)),p['id'],p['version']))
     if cur.rowcount!=1:raise HTTPException(409,'الگو تغییر کرده است؛ تازه‌سازی کنید.')
    else:c.execute('INSERT INTO personnel_point_templates(label,kind,points,active) VALUES(?,?,?,?)',(label.strip(),kind,points,int(p.get('active',True))))
    A.audit(request,c,'تنظیم الگوی امتیاز',label.strip())
  except (ValueError,sqlite3.IntegrityError) as e:raise HTTPException(400,'عنوان الگو تکراری است.' if isinstance(e,sqlite3.IntegrityError) else str(e))
  return dict(ok=True)
