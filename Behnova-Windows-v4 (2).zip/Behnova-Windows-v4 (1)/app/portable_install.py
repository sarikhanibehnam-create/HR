"""Portable local copies: preserve credentials/data/tenant GUIDs, revoke copied sessions.
Called ONLY after the launcher acquires this directory's real data lock.
No process killing, control-file deletion, password reset or remote-drive execution.
"""
from pathlib import Path
from contextlib import closing
from datetime import datetime,timezone,timedelta
import os,json,secrets,sqlite3,shutil,hashlib,socket,ipaddress
from server_lifecycle import machine_id,data_id,private_directory,write_json,validate_tls,ensure_https

def relocated(settings,data):
    b=settings.get('binding') or {}
    return bool(b and (b.get('host_id')!=machine_id() or b.get('data_id')!=data_id(data)))

def _databases(data):
    paths=[data/'hr.sqlite3'];registry=data/'companies.sqlite3'
    if registry.is_file():
        with closing(sqlite3.connect(registry.as_uri()+'?mode=ro&immutable=1',uri=True)) as c:
            for ident,guid in c.execute('SELECT id,guid FROM companies'):
                if ident==1:continue
                if len(guid)!=32 or any(ch not in '0123456789abcdef' for ch in guid):raise ValueError('شناسه مسیر شرکت معتبر نیست؛ انتقال خودکار متوقف شد.')
                db=data/'companies'/guid/'hr.sqlite3'
                if db.is_file():paths.append(db)
        paths.append(registry)
    return paths

def adopt_copy(data,settings):
    """Idempotent migration: settings published last; partial session revocation is safe to retry."""
    data=Path(data).resolve()
    if not relocated(settings,data):return settings,None
    if (data/'restore-in-progress.json').exists():raise ValueError('بازیابی ناتمام است؛ ابتدا وضعیت بازیابی باید بررسی شود.')
    for wal in data.rglob('*.sqlite3-wal'):
        if wal.stat().st_size:raise ValueError('کپی دارای WAL ناتمام است؛ پس از STOP کامل دوباره کپی کنید. فایل WAL را حذف نکنید.')
    databases=_databases(data)
    if not databases[0].is_file():raise ValueError('بانک نصب کپی‌شده پیدا نشد؛ کل پوشه را پس از STOP کامل کپی کنید. بانک یا حساب تازه ساخته نشد.')
    # No symlink escape and no stale snapshot from a live WAL copy.
    for p in data.rglob('*'):
        if p.is_symlink():raise ValueError('پوشه داده دارای پیوند فایل/پوشه است؛ انتقال خودکار انجام نشد.')
    for db in databases:
        wal=Path(str(db)+'-wal')
        if wal.exists() and wal.stat().st_size:raise ValueError('کپی دارای WAL ناتمام است. روی مبدأ STOP را کامل کنید و کل پوشه را دوباره کپی کنید؛ WAL یا SHM را حذف نکنید.')
        with closing(sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True)) as c:
            if c.execute('PRAGMA quick_check(1)').fetchone()[0]!='ok':raise ValueError('صحت بانک کپی‌شده تأیید نشد؛ اطلاعات تغییر نکرد.')
        if db.name=='hr.sqlite3':
            for name in ['security.key','session.key']:
                if not (db.parent/name).is_file():raise ValueError('کلیدهای نصب کپی‌شده کامل نیستند؛ کل پوشه را با کلیدها کپی کنید. کلید جدید ساخته نشد.')
    backup_root=data.parent/(data.name+'-portable-backups');private_directory(backup_root)
    backup=backup_root/(datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(4));private_directory(backup)
    ignored={'behnova.lock','behnova-control.json','behnova-running.json','launcher.log','launcher.log.1','launcher.log.2'}
    shutil.copytree(data,backup/'data',ignore=lambda folder,names:[n for n in names if n in ignored])
    write_json(backup/'PORTABLE-SAFETY.json',{'original_binding':settings.get('binding'),'destination_data_id':data_id(data),'note':'Private safety copy; contains databases and keys. Never share with clients.'})
    for db in databases:
        with closing(sqlite3.connect(db,timeout=20)) as c:
            with c:
                tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                for table in ['sessions','mfa_pending','import_previews','vehicle_import_previews','record_import_previews','unified_excel_previews','tickets','portals']:
                    if table in tables:c.execute('DELETE FROM '+table)
    new=dict(settings);new.update(installation_id=secrets.token_hex(16),mode='local',binding={'host_id':machine_id(),'data_id':data_id(data)},portable=True)
    new['last_portable_adoption']={'at':datetime.now(timezone.utc).isoformat(),'safety_folder':str(backup),'separate_copy':True}
    # START defaults to local on first relocated launch; START-SHARED explicitly opts in.
    write_json(data/'behnova-server.json',new)
    return new,str(backup)

def portable_tls(root,addresses):
    """Use current cert if valid; otherwise mint a host-specific leaf using OUR existing CA.
    The previous cert/key are never overwritten. External IT certs are never replaced.
    A staged directory is validated before atomic publication.
    """
    root=Path(root).resolve()
    if not (root/'server.crt').exists() and not (root/'server.key').exists():
        created=ensure_https(root,addresses);validate_tls(root,addresses);return root,created
    try:validate_tls(root,addresses);return root,False
    except Exception as original:
        from cryptography import x509
        from cryptography.hazmat.primitives import serialization,hashes
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID,ExtendedKeyUsageOID
        try:
            ca=x509.load_pem_x509_certificate((root/'ca.crt').read_bytes())
            key=serialization.load_pem_private_key((root/'ca.key').read_bytes(),password=None)
            leaf=x509.load_pem_x509_certificate((root/'server.crt').read_bytes())
            oldkey=serialization.load_pem_private_key((root/'server.key').read_bytes(),password=None)
            pub=lambda k:k.public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
            assert pub(ca.public_key())==pub(key.public_key()) and pub(leaf.public_key())==pub(oldkey.public_key())
            assert ca.extensions.get_extension_for_class(x509.BasicConstraints).value.ca
            assert any(a.value.startswith('BEHNOVA Private LAN ') for a in ca.subject.get_attributes_for_oid(NameOID.COMMON_NAME))
            leaf.verify_directly_issued_by(ca);ca.verify_directly_issued_by(ca)
            now=datetime.now(timezone.utc);assert ca.not_valid_before_utc<=now<ca.not_valid_after_utc-timedelta(days=1)
        except Exception:raise ValueError(str(original)+'؛ گواهی سازمانی/ناقص خودکار جایگزین نمی‌شود. اجرای محلی با START ممکن است؛ برای HTTPS با IT هماهنگ کنید.') from original
        ips=sorted(set(addresses)|{'127.0.0.1','::1'})
        identity=hashlib.sha256((machine_id()+'|'+','.join(ips)+'|'+ca.fingerprint(hashes.SHA256()).hex()).encode()).hexdigest()[:24]
        parent=root/'portable-hosts';private_directory(parent)
        target=parent/identity
        if target.exists():
            try:validate_tls(target,addresses);return target,False
            except Exception:target=parent/(identity+'-'+secrets.token_hex(4))
        stage=parent/('.stage-'+secrets.token_hex(12));private_directory(stage)
        try:
            newkey=rsa.generate_private_key(public_exponent=65537,key_size=2048)
            sans=[x509.DNSName('localhost')]
            for name in sorted({socket.gethostname().lower(),socket.getfqdn().lower()}):
                if name and name!='localhost':sans.append(x509.DNSName(name))
            sans += [x509.IPAddress(ipaddress.ip_address(a)) for a in ips]
            cert=(x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'BEHNOVA LAN Server')])).issuer_name(ca.subject).public_key(newkey.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(min(now+timedelta(days=365),ca.not_valid_after_utc)).add_extension(x509.SubjectAlternativeName(sans),False).add_extension(x509.BasicConstraints(ca=False,path_length=None),True).add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),False).add_extension(x509.KeyUsage(True,False,True,False,False,False,False,False,False),True).sign(key,hashes.SHA256()))
            for name,b in [('ca.crt',(root/'ca.crt').read_bytes()),('server.crt',cert.public_bytes(serialization.Encoding.PEM)),('server.key',newkey.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))]:
                with (stage/name).open('xb') as f:f.write(b)
                os.chmod(stage/name,0o600)
            validate_tls(stage,addresses);stage.rename(target)
            return target,False
        finally:
            if stage.exists():shutil.rmtree(stage)
