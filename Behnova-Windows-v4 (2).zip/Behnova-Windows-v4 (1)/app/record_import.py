"""Scoped two-phase XLSX entry for the seven non-vehicle repeatable record kinds."""
import io,json,time,secrets,hashlib,copy
from datetime import date
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName
from fastapi import Request,HTTPException
from import_workflow import ImportProblem,page_of
from security_core import token_hash
import access_control as ac
import personnel_records as pr
import vehicle_import as vi
from company_context import current_app as A
KINDS=tuple(k for k in pr.KINDS if k!='vehicle')
for kind in KINDS:
 for action,label in [('import_create','افزودن گروهی از Excel — '),('import_update','ویرایش گروهی از Excel — ')]:ac.PERMISSIONS['records.'+kind+'.'+action]=label+pr.KINDS[kind]['label']

def init_storage(c):
 c.execute('CREATE TABLE IF NOT EXISTS record_import_previews(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,session_id TEXT NOT NULL,expires REAL NOT NULL,payload BLOB NOT NULL)')
 c.execute('DELETE FROM record_import_previews WHERE expires<?',(time.time(),))
def importer(u,kind):
 if kind not in KINDS:raise HTTPException(400,'بخش ورود گروهی نامعتبر است.')
 pr.require(u,kind,'read')
 if not (ac.can(u,'records.'+kind+'.import_create') or ac.can(u,'records.'+kind+'.import_update')):raise HTTPException(403,'مجوز ورود گروهی این بخش فعال نیست.')
def fields(c,kind):
 fs=copy.deepcopy(pr.KINDS[kind]['fields'])
 if kind=='education':fs[0]['choices']=[dict(value=x,label=x) for x in A.current_schema(c)['options']['education']]
 if kind=='merits':fs.append(dict(key='template_id',label='شناسه الگوی امتیاز',type='text',required=False))
 return fs

def revision(c):
 data=[A.current_schema(c)['revision'],[list(r) for r in c.execute('SELECT * FROM personnel_point_templates ORDER BY id')]]
 return hashlib.sha256(json.dumps(data,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
def headers(c,kind):return [('code','کد پرسنلی'),('record_id','شناسه سابقه')]+[(f['key'],f['label']) for f in fields(c,kind)]
def template(c,kind):
 w=openpyxl.Workbook();w.properties.creator='BEHNOVA';s=w.active;s.title='سوابق';s.sheet_view.rightToLeft=True;s.append([v for k,v in headers(c,kind) if k!='record_id']);s.freeze_panes='A2';lists=w.create_sheet('گزینه‌ها');lists.sheet_state='hidden';fs=fields(c,kind);defs={f['key']:f for f in fs};lc=0
 for col,(key,label) in enumerate([(k,v) for k,v in headers(c,kind) if k!='record_id'],1):
  letter=openpyxl.utils.get_column_letter(col);s.column_dimensions[letter].width=30;cell=s.cell(1,col);cell.font=Font(name='Tahoma',bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='155F51');cell.alignment=Alignment(horizontal='right',wrap_text=True)
  for row in range(2,202):s.cell(row,col).number_format='@'
  f=defs.get(key,{})
  if f.get('choices'):
   lc+=1;ltr=openpyxl.utils.get_column_letter(lc)
   for row,ch in enumerate(f['choices'],1):lists.cell(row,lc,ch['label']).data_type='s'
   name='BN_RECORD_'+str(lc);w.defined_names.add(DefinedName(name,attr_text=f"'گزینه‌ها'!${ltr}$1:${ltr}${len(f['choices'])}"));dv=DataValidation(type='list',formula1='='+name,allow_blank=not f['required']);dv.showErrorMessage=True;dv.error='یکی از گزینه‌های فهرست را انتخاب کنید.';dv.errorStyle='stop';s.add_data_validation(dv);dv.add(f'{letter}2:{letter}5001')
 guide=w.create_sheet('راهنما');guide.sheet_view.rightToLeft=True
 notes=['BEHNOVA — نمونه فایل ورودی — '+pr.KINDS[kind]['label'],'این فایل هیچ رکورد نمونه‌ای ندارد؛ فقط برگه سوابق را تکمیل کنید.','کد پرسنلی موجود را به صورت متن وارد کنید؛ صفرهای ابتدایی باید حفظ شوند.','این نمونه فقط برای ثبت جدید است؛ شناسه سابقه را خود سیستم می‌سازد و لازم نیست چیزی برای آن تعریف کنید. برای اصلاح قبلی‌ها، خروجی Excel همان بخش را بگیرید و شناسه خودکار را بدون تغییر نگه دارید.','برای هر شخص می‌توانید چند ردیف مستقل وارد کنید. کد پرسنلی به‌تنهایی مجوز یا شناسه ویرایش سابقه نیست.','ستون حذف‌شده از فایل، مقدار قبلی را حفظ می‌کند؛ ستون موجود ولی خالی، مقدار آن را پاک می‌کند یا اگر الزامی باشد خطا می‌دهد.','تاریخ‌ها متن شمسی مثل ۱۴۰۳/۰۱/۰۱ باشند. وضعیت‌های فرایندی فقط از گزینه‌های تعیین‌شده هستند؛ ناشناخته را حدس نزنید.','حداکثر ۵۰۰۰ ردیف واقعی و ۸ مگابایت. هیچ ردیفی تا تأیید صریح پیش‌نمایش ثبت نمی‌شود؛ اعتبار پیش‌نمایش ۱۰ دقیقه و وابسته به همین نشست است.','ثبت جدیدِ دقیقاً یکسان با سابقه فعال یا تکراری در فایل پذیرفته نمی‌شود؛ برای اصلاح، شناسه قبلی را وارد کنید.','اطلاعات اشخاص خارج از فایل تغییر نمی‌کند. کل فایل یکجا ثبت می‌شود یا هیچ ردیفی ثبت نمی‌شود.']
 if kind in ['merits','education','career']:notes+=['این ورود گروهی هیچ سابقه‌ای را خودکار تأیید نمی‌کند و مدرک یا سمت جاری شخص را تغییر نمی‌دهد. مرحله تأیید و اعمال مستقل است.']
 if kind in ['education','career']:notes+=['ارتقای قبلاً تأیید و اعمال‌شده قابل بازنویسی نیست؛ برای اصلاح، رویداد جدید ثبت کنید.']
 if kind=='merits':notes+=['ویرایش امتیاز تأییدشده، تأیید قبلی آن را لغو می‌کند؛ این تغییر در پیش‌نمایش مشخص است. امتیاز تشویق مثبت و تنبیه منفی است.','شناسه الگوی امتیاز اختیاری است. امتیاز و نوع باید با الگوی فعال سازگار باشند؛ برای تغییر امتیاز، علت تغییر لازم است. ستون الگو اگر حذف شود، ارتباط قبلی حفظ می‌شود؛ خالی‌کردن صریح، ارتباط را حذف می‌کند.']
 if kind=='children':notes+=['هر ردیف مربوط به یک فرزند است؛ برای سه فرزند، کد پرسنلی والد را در سه ردیف تکرار کنید و مشخصات هر فرزند را جدا بنویسید.','حق اولاد و بیمه تکمیلی مستقل هستند. تعداد فرزندان و افراد تحت پوشش در پرونده عمومی خودکار تغییر نمی‌کند.']
 if kind=='welfare':notes+=['مبالغ مثبت، به ریال و بدون جداکننده هزارگان؛ تبدیل خودکار از تومان انجام نمی‌شود.']
 if kind=='training':notes+=['مدت به ساعت؛ برای وضعیت گذرانده، تاریخ پایان لازم است.']
 if kind=='hardship':notes+=['تاریخ تاریخی نامعلوم را خالی بگذارید؛ وضعیت درخواست، تشخیص قانونی استحقاق نیست.']
 for text in notes:guide.append([text])
 for f in fs:guide.append([f['label']+': '+('الزامی' if f['required'] else 'اختیاری')+('؛ '+' / '.join(ch['label'] for ch in f.get('choices',[])) if f.get('choices') else '')])
 guide.column_dimensions['A'].width=110
 for row in guide:
  guide.row_dimensions[row[0].row].height=48
  for cell in row:cell.data_type='s';cell.alignment=Alignment(horizontal='right',wrap_text=True);cell.font=Font(name='Tahoma',size=12)
 b=io.BytesIO();w.save(b);return b

def fingerprint(kind,value):
 return json.dumps({f['key']:value.get(f['key'],'') for f in pr.KINDS[kind]['fields']},sort_keys=True,ensure_ascii=False)
def existing(c,kind):
 result=set()
 for row in c.execute('SELECT employee_id,payload FROM personnel_records WHERE kind=? AND deleted=0',(kind,)):result.add((row['employee_id'],fingerprint(kind,pr.dec(row['payload']))))
 return result

def plan(c,u,kind,parsed,present,mode):
 if mode not in ['new','update','mixed']:raise ImportProblem('حالت ورود نامعتبر است.')
 fs=fields(c,kind);labels={f['key']:f['label'] for f in fs}|{'template_label':'عنوان الگوی امتیاز','template_points':'امتیاز الگو','approval':'تأیید قبلی امتیاز'};dates=[f['key'] for f in fs if f['type']=='date'];ids=set();new_keys=set();known=existing(c,kind);errors=[];unknown=[]
 result=dict(kind=kind,revision=revision(c),records=[],items=[],counts=dict(total=len(parsed),added=0,updated=0,unchanged=0,cleared_values=0),date_keys=dates)
 for entry in parsed:
  line=entry['line'];d=entry['value'];ident=d['record_id']
  try:
   if mode=='new' and ident or mode=='update' and not ident:raise ValueError('شناسه سابقه با حالت انتخاب‌شده سازگار نیست.')
   pr.require(u,kind,'import_update' if ident else 'import_create')
   employee=c.execute('SELECT * FROM employees WHERE code=?',(d['code'],)).fetchone()
   if not employee or not ac.within(u,dict(employee)):raise HTTPException(403,'کد پرسنلی پیدا نشد یا در محدوده مجاز نیست.')
   employee=dict(employee);old=None;base={}
   if ident:
    if ident in ids:raise ValueError('شناسه سابقه در فایل تکراری است.')
    ids.add(ident);row=c.execute('SELECT * FROM personnel_records WHERE id=?',(ident,)).fetchone()
    if not row or row['kind']!=kind or row['deleted'] or row['employee_id']!=employee['id']:raise HTTPException(403,'شناسه سابقه با پرسنل و بخش مجاز این ردیف تطبیق ندارد.')
    old=dict(row);base=pr.dec(old['payload'])
    if old['approved_at'] and kind in ['education','career']:raise ImportProblem('ارتقای اعمال‌شده قابل بازنویسی نیست؛ رویداد اصلاحی جدید ثبت کنید.',[f'ردیف {line}'],409)
   value={f['key']:base.get(f['key'],'') for f in fs}
   for f in fs:
    key=f['key']
    if key in present:value[key]=d.get(key,'')
    if f['type']=='date':
     if key in present and A.option_key(value[key])==A.option_key('ثبت نشده'):value[key]=''
     if key not in present and value[key]:value[key]=A.fa_date(date.fromisoformat(value[key]))
    elif f['type']=='select' and not (kind=='education' and key=='degree'):
     lookup={A.option_key(ch['label']):ch['value'] for ch in f['choices']}|{A.option_key(ch['value']):ch['value'] for ch in f['choices']}
     v=lookup.get(A.option_key(value[key]))
     if v is None:raise ValueError(f['label']+' نامعتبر یا خالی است؛ از گزینه‌های نمونه فایل ورودی استفاده کنید.')
     value[key]=v
   if kind=='merits':
    tid=value.get('template_id')
    if tid not in [None,'',0]:
     text=str(tid).translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
     if not text.isdigit() or len(text)>18:raise ValueError('شناسه الگوی امتیاز نامعتبر است.')
     value['template_id']=int(text)
   # Preserve an unchanged historical template snapshot, including inactive templates.
   unchanged_template=kind=='merits' and old and ('template_id' not in present or value.get('template_id')==base.get('template_id')) and all(value.get(k)==str(base.get(k,'')) for k in ['type','points','override_reason'])
   if unchanged_template:value.pop('template_id',None)
   value=pr.normalize(kind,value,c,employee,base if old else None)
   if unchanged_template:
    for key in ['template_id','template_label','template_points']:
     if key in base:value[key]=base[key]
   if old and kind in ['education','career'] and (kind=='education' or base.get('target')==value.get('target')) and 'previous' in base:value['previous']=base['previous']
   if not ident:
    key=(employee['id'],fingerprint(kind,value))
    if key in new_keys or key in known:raise ImportProblem('سابقه کاملاً یکسان موجود یا در فایل تکرار شده؛ برای ویرایش، شناسه سابقه لازم است.',[f'ردیف {line}'],409)
    new_keys.add(key)
   keys=set(value)|set(base);changes=[dict(field=k,label=labels.get(k,k),before=base.get(k,'') if old else '',after=value.get(k,''),cleared=bool(old and base.get(k) not in [None,'',0] and value.get(k,'') in [None,'',0])) for k in sorted(keys) if k!='previous' and ((old and base.get(k,'')!=value.get(k,'')) or (not old and value.get(k,'') not in [None,'']))]
   state='new' if not ident else 'update' if changes else 'unchanged'
   if state=='update' and old['approved_at'] and kind=='merits':changes.append(dict(field='approval',label='تأیید امتیاز',before='تأیید شده',after='در انتظار تأیید دوباره',cleared=False))
   result['counts'][{'new':'added','update':'updated','unchanged':'unchanged'}[state]]+=1;result['counts']['cleared_values']+=sum(x['cleared'] for x in changes)
   result['records'].append(dict(id=ident,employee_id=employee['id'],employee_version=employee['version'],code=employee['code'],version=old['version'] if old else None,before=base if old else None,value=value,status=state))
   result['items'].append(dict(line=line,code=employee['code'],name=employee['name'],record_id=ident,status=state,changes=changes))
  except ImportProblem:raise
  except ValueError as e:
   errors.append(f'ردیف {line}: {e}')
   if isinstance(e,A.choice_settings.UnknownChoice) and u['role']=='admin':
    v=A.choice_settings.unknown_payload(e)
    if v not in unknown and len(unknown)<100:unknown.append(v)
 if errors:
  e=ImportProblem('هیچ سابقه‌ای ذخیره نشد؛ خطاها را اصلاح کنید.',errors[:30]);e.unknown_choices=unknown;raise e
 return result

def owned(c,request,kind,token):
 if not isinstance(token,str) or not 20<=len(token)<=200:raise ImportProblem('پیش‌نمایش معتبر نیست.',status=404)
 row=c.execute('SELECT * FROM record_import_previews WHERE token_hash=? AND user_id=? AND session_id=?',(token_hash(token),request.session['uid'],token_hash(request.session['sid']))).fetchone()
 if not row:raise ImportProblem('پیش‌نمایش متعلق به این نشست نیست، لغو یا ثبت شده است.',status=404)
 if row['expires']<time.time():raise ImportProblem('اعتبار پیش‌نمایش تمام شده؛ فایل را دوباره بررسی کنید.',status=410)
 p=pr.dec(row['payload'])
 if p['kind']!=kind:raise ImportProblem('پیش‌نمایش مربوط به این بخش نیست.',status=404)
 return p

def register(module):
 app=module.app
 @app.get('/api/record-import/{kind}/template')
 async def download_template(request:Request,kind:str):
  u=await A.require_user(request);importer(u,kind)
  with A.db() as c:return A.excel_response(template(c,kind),'BEHNOVA-'+kind.title()+'-Input.xlsx')
 @app.post('/api/record-import/{kind}/preview')
 async def preview(request:Request,kind:str):
  u=await A.require_user(request);importer(u,kind);form=await request.form();file=form.get('file')
  if not file or not str(getattr(file,'filename','')).lower().endswith('.xlsx'):raise HTTPException(400,'فایل xlsx انتخاب کنید.')
  try:
   with A.db() as c:head=headers(c,kind);rev=revision(c)
   parsed,present=vi.parse(await file.read(),head,['سوابق']);token=secrets.token_urlsafe(32)
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request);importer(u,kind)
    if rev!=revision(c):raise ImportProblem('تنظیمات حین بررسی تغییر کرده؛ فایل را دوباره بررسی کنید.',status=409)
    p=plan(c,u,kind,parsed,present,form.get('mode','new'));c.execute('DELETE FROM record_import_previews WHERE expires<?',(time.time(),))
    prior=c.execute('SELECT token_hash FROM record_import_previews WHERE user_id=? ORDER BY expires DESC',(u['id'],)).fetchall()
    for r in prior[1:]:c.execute('DELETE FROM record_import_previews WHERE token_hash=?',(r[0],))
    if c.execute('SELECT COUNT(*) FROM record_import_previews').fetchone()[0]>=8:raise ImportProblem('پیش‌نمایش‌های فعال زیادند؛ قبلی‌ها را لغو کنید.',status=429)
    c.execute('INSERT INTO record_import_previews VALUES(?,?,?,?,?)',(token_hash(token),u['id'],token_hash(request.session['sid']),time.time()+600,pr.enc(p)))
   return dict(preview_token=token,expires_in=600,**page_of(p))
  except ImportProblem as e:return A.json_response(error=str(e),errors=e.errors,unknown_choices=getattr(e,'unknown_choices',[]),_status=e.status)
  except ValueError as e:raise HTTPException(400,str(e))
 @app.get('/api/record-import/{kind}/preview/{token}')
 async def preview_page(request:Request,kind:str,token:str,page:int=1):
  u=await A.require_user(request);importer(u,kind)
  try:
   with A.db() as c:return page_of(owned(c,request,kind,token),page)
  except ImportProblem as e:return A.json_response(error=str(e),_status=e.status)
 @app.delete('/api/record-import/{kind}/preview/{token}')
 async def cancel(request:Request,kind:str,token:str):
  u=await A.require_user(request);importer(u,kind)
  try:
   with A.db() as c:
    owned(c,request,kind,token);c.execute('DELETE FROM record_import_previews WHERE token_hash=?',(token_hash(token),))
  except ImportProblem as e:return A.json_response(error=str(e),_status=e.status)
  return dict(ok=True)
 @app.post('/api/record-import/{kind}/commit')
 async def commit(request:Request,kind:str):
  u=await A.require_user(request);importer(u,kind);body=await A.json_data(request)
  if body.get('confirm') is not True:raise HTTPException(400,'تأیید صریح پیش‌نمایش لازم است.')
  try:
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request);importer(u,kind);p=owned(c,request,kind,body.get('token'))
    if p['revision']!=revision(c):raise ImportProblem('گزینه‌ها، فیلدها یا الگوها پس از پیش‌نمایش تغییر کرده‌اند؛ فایل را دوباره بررسی کنید.',status=409)
    known=existing(c,kind)
    for item in p['records']:
     pr.require(u,kind,'import_update' if item['id'] else 'import_create');employee=pr.scoped_employee(c,u,item['employee_id'])
     if employee['code']!=item['code'] or employee['version']!=item['employee_version']:raise ImportProblem('اطلاعات پرسنل پس از پیش‌نمایش تغییر کرده؛ هیچ ردیفی ثبت نشد.',status=409)
     if item['id']:
      old=c.execute('SELECT * FROM personnel_records WHERE id=?',(item['id'],)).fetchone()
      if not old or old['kind']!=kind or old['deleted'] or old['employee_id']!=item['employee_id'] or old['version']!=item['version']:raise ImportProblem('سابقه پس از پیش‌نمایش تغییر کرده؛ فایل را دوباره بررسی کنید.',status=409)
      if old['approved_at'] and kind in ['education','career']:raise ImportProblem('ارتقای اعمال‌شده قابل بازنویسی نیست.',status=409)
     elif (item['employee_id'],fingerprint(kind,item['value'])) in known:raise ImportProblem('سابقه یکسان پس از پیش‌نمایش ایجاد شده؛ هیچ ردیفی ثبت نشد.',status=409)
    now=A.tehran_now().isoformat(timespec='seconds')
    for item in p['records']:
     if item['status']=='unchanged':continue
     event_date=item['value'].get(pr.KINDS[kind]['date_key'],'')
     if item['id']:
      ident=item['id'];c.execute('UPDATE personnel_records SET payload=?,event_date=?,version=version+1,approved_at="",approved_by=NULL,updated_at=? WHERE id=?',(pr.enc(item['value']),event_date,now,ident))
     else:
      cur=c.execute('INSERT INTO personnel_records(employee_id,kind,event_date,payload,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(item['employee_id'],kind,event_date,pr.enc(item['value']),u['id'],now,now));ident=cur.lastrowid
     row=dict(c.execute('SELECT * FROM personnel_records WHERE id=?',(ident,)).fetchone());pr.history(c,u,row,'ورود گروهی — '+pr.KINDS[kind]['label']+' — '+item['status'],item['before'],item['value'])
    c.execute('DELETE FROM record_import_previews WHERE token_hash=?',(token_hash(body['token']),));A.audit(request,c,'ثبت گروهی '+pr.KINDS[kind]['label']+' با تأیید پیش‌نمایش',json.dumps(p['counts']));return dict(ok=True,**p['counts'])
  except ImportProblem as e:return A.json_response(error=str(e),_status=e.status)
