"""Published release identity; never stored in tenant data or incremented at startup.
The manifest diagnoses copy/restart problems, not authenticity or a security guarantee.
"""
import hashlib
import json
from pathlib import Path

SERIAL = 6
CHANGES = [
    'فعال‌سازی یک‌باره و آفلاین مختص کامپیوتر میزبان، مستقل از رمز ادمین، اضافه شد.',
    'فقط مجوز امضاشده مالک برای شناسه همین دستگاه پذیرفته می‌شود؛ کلید خصوصی مالک داخل برنامه نیست.',
    'بدون مجوز، راه‌انداز و ورود مستقیم به سرور قبل از دسترسی به بانک متوقف می‌شوند.',
    'جابه‌جایی پوشه در همان سیستم مجاز است؛ کامپیوتر دیگر به مجوز جدید نیاز دارد.',
    'رمزهای کاربران، اطلاعات شرکت‌ها، کلیدهای داده، ظاهر اصلی و راهنمای Excel حفظ شدند.',
    'آماده‌سازی آفلاین Unicode-safe محیط اجرا و توقف ایمن نسخه قبل حفظ شدند.',
]

ROOT = Path(__file__).resolve().parent
# Capture Python source at process start, even when a manifest was not yet installed.
_BOOT = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
         for p in ROOT.iterdir() if p.is_file() and p.suffix in ('.py', '.pyw')}
MANDATORY = {'activation_security.py','activation_ui.py','license_public.py','templates/activation.html','portable_install.py', 'app.py', 'release_info.py', 'company_gateway.py',
             'templates/index.html', 'static/app.js', 'static/management.js',
             'static/companies.js', 'static/settings.js', 'static/settings.css', 'unified_excel.py', 'static/unified-excel.js', 'static/unified-excel.css'}


def status(root=None, boot=None):
    root = Path(root) if root else ROOT
    boot = _BOOT if boot is None else boot
    result = {'server_serial': SERIAL, 'changes': CHANGES, 'installed_serial': None,
              'integrity': 'unknown', 'restart_required': False,
              'issues': [], 'note': 'این بررسی برای تشخیص نقص کپی فایل‌هاست، نه تضمین امنیت یا اصالت بسته.'}
    try:
        manifest = json.loads((root / 'release-manifest.json').read_text('utf-8'))
        files = manifest['files']
        assert type(manifest['serial']) is int and manifest['serial'] >= 1
        assert isinstance(files, dict) and MANDATORY <= files.keys()
        assert all(isinstance(k, str) and not Path(k).is_absolute() and '..' not in Path(k).parts
                   and isinstance(v, str) and len(v) == 64 for k, v in files.items())
    except (OSError, ValueError, KeyError, TypeError, AssertionError):
        result['issues'] = ['فهرست کنترل فایل‌های انتشار وجود ندارد یا معتبر نیست؛ بسته کامل اصلاحیه را جایگزین کنید.']
        return result
    result['installed_serial'] = manifest['serial']
    if manifest['serial'] != SERIAL:
        result['issues'].append('شماره فایل‌های نصب با سرور در حال اجرا متفاوت است.')
    changed = []
    for name, expected in files.items():
        try:
            actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
        except OSError:
            actual = None
        if actual != expected:
            changed.append(name)
        if name in boot and actual != boot[name]:
            result['restart_required'] = True
    # New/changed installed Python cannot be assumed to be loaded by a live process.
    if any(name.endswith(('.py', '.pyw')) and name not in boot for name in files):
        result['restart_required'] = True
    if changed:
        result['issues'].append('فایل مفقود یا متفاوت: ' + '، '.join(changed[:8]) +
                                (' …' if len(changed) > 8 else ''))
    if result['restart_required']:
        result['issues'].append('فایل‌های اجرایی پس از شروع این سرور تغییر کرده‌اند؛ توقف کامل با STOP.cmd و اجرای مجدد لازم است.')
    result['integrity'] = 'ok' if not result['issues'] else 'mismatch'
    return result
