"""Authorized, server-side cross-tab summaries. Never trust client aggregate values."""
from datetime import date
import jdatetime
from collections import defaultdict
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter

METRICS={'count':'تعداد کارکنان','age':'میانگین سن','tenure':'میانگین سابقه همکاری','children':'مجموع فرزندان','dependents':'مجموع افراد تحت پوشش'}

def validate_spec(spec,fields):
    if not isinstance(spec,dict):raise ValueError('ساختار گزارش نامعتبر است.')
    groups=spec.get('groups');allowed=dict(fields)|{'age':'گروه سنی','tenure':'بازه سابقه همکاری','contract':'وضعیت قرارداد'}
    if not isinstance(groups,list) or not 1<=len(groups)<=3 or any(not isinstance(k,str) or k not in allowed for k in groups) or len(set(groups))!=len(groups):raise ValueError('یک تا سه گروه‌بندی متفاوت و معتبر انتخاب کنید.')
    if not isinstance(spec.get('metric'),str) or spec['metric'] not in METRICS:raise ValueError('شاخص گزارش نامعتبر است.')
    order=spec.get('group_order')
    if order is not None and (not isinstance(order,list) or len(order)>10000 or any(not isinstance(labels,list) or len(labels)!=len(groups) or any(not isinstance(label,str) or len(label)>2000 for label in labels) for labels in order) or len({tuple(labels) for labels in order})!=len(order)):raise ValueError('ترتیب گروه‌های گزارش نامعتبر است.')
    return {'groups':groups,'metric':spec['metric'],'title':str(spec.get('title','گزارش منابع انسانی'))[:200],'context':str(spec.get('context',''))[:2000],**({'group_order':order} if order is not None else {})}

def prepared(row,today):
    result=dict(row)
    for source,target in [('birth_date','age'),('hire_date','tenure')]:
        if target=='tenure' and 'employment_periods' in row:
            ps=row['employment_periods']
            known=ps if all(p.get('start_date') for p in ps) else []
            days=sum(max(0,((min(date.fromisoformat(p['end_date']),today) if p.get('end_date') else today)-date.fromisoformat(p['start_date'])).days) for p in known)
            result[target]=round(days/365.2425,1) if known else None
            continue
        result[target]=round((today-date.fromisoformat(row[source])).days/365.2425,1) if row.get(source) else None
    result['remaining_days']=(date.fromisoformat(row['contract_end'])-today).days if row.get('contract_end') else None
    return result

def group_label(row,key):
    n=row.get(key)
    if key in ['birth_date','hire_date','contract_end'] and n:return jdatetime.date.fromgregorian(date=date.fromisoformat(n)).strftime('%Y/%m/%d')
    if key.startswith('settlement_'):return str(n) if n else 'ثبت نشده'
    if key=='age':return 'ثبت‌نشده' if n is None else 'زیر ۳۰ سال' if n<30 else '۳۰ تا ۳۹ سال' if n<40 else '۴۰ تا ۴۹ سال' if n<50 else '۵۰ سال و بیشتر'
    if key=='tenure':return 'ثبت‌نشده' if n is None else 'کمتر از یک سال' if n<1 else '۱ تا ۴ سال' if n<5 else '۵ تا ۹ سال' if n<10 else '۱۰ سال و بیشتر'
    if key=='contract':
        d=row.get('remaining_days');return 'بدون تاریخ پایان' if d is None else 'منقضی‌شده' if d<0 else 'پایان تا ۳۰ روز' if d<=30 else 'بیش از ۳۰ روز'
    return 'ثبت‌نشده' if n is None or n=='' else str(n)

def aggregate(rows,groups,metric,today):
    data=[prepared(row,today) for row in rows];buckets=defaultdict(list)
    for row in data:buckets[tuple(group_label(row,k) for k in groups)].append(row)
    def value(values):
        if metric=='count':return len(values)
        nums=[r[metric] for r in values if r.get(metric) is not None and r.get(metric)!='']
        if metric in ['age','tenure']:return sum(nums)/len(nums) if nums else None
        return sum(int(n) for n in nums)
    result=[{'labels':labels,'count':len(values),'value':value(values)} for labels,values in buckets.items()]
    result.sort(key=lambda r:r['value'] if r['value'] is not None else -1,reverse=True)
    return result,value(data)

def add_report_sheet(book,rows,spec,fields,today,date_label):
    labels=dict(fields)|{'age':'گروه سنی','tenure':'بازه سابقه همکاری','contract':'وضعیت قرارداد'}
    groups=spec['groups'];metric=spec['metric'];results,total=aggregate(rows,groups,metric,today)
    if 'group_order' in spec:
        order={tuple(labels):i for i,labels in enumerate(spec['group_order'])};results.sort(key=lambda row:order.get(row['labels'],len(order)))
    sheet=book.create_sheet('خلاصه گزارش',0);sheet.sheet_view.rightToLeft=True
    headers=[labels[k] for k in groups]+['تعداد کارکنان']+(['سهم از کارکنان (درصد)'] if metric=='count' else [METRICS[metric]])
    sheet.append(headers)
    for row in results:
        v=row['count']/len(rows)*100 if metric=='count' and rows else row['value']
        sheet.append(list(row['labels'])+[row['count'],v])
    sheet.append(['میانگین کل' if metric in ['age','tenure'] else 'مجموع']+['']*(len(groups)-1)+[len(rows),100 if metric=='count' and rows else total])
    for row in sheet:
        for cell in row:
            cell.font=Font(name='Tahoma',size=12);cell.alignment=Alignment(horizontal='right')
            if isinstance(cell.value,str):cell.data_type='s'
            elif isinstance(cell.value,float):cell.number_format='0.0'
    for cell in sheet[1]:cell.font=Font(name='Tahoma',size=12,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='12665C')
    for col in range(1,len(headers)+1):sheet.column_dimensions[get_column_letter(col)].width=29
    sheet.freeze_panes='A2';sheet.auto_filter.ref=f'A1:{get_column_letter(len(headers))}{len(results)+1}'
    for cell in sheet[sheet.max_row]:cell.font=Font(name='Tahoma',size=12,bold=True);cell.fill=PatternFill('solid',fgColor='EAF4EE')
    info=book.create_sheet('شرح گزارش');info.sheet_view.rightToLeft=True
    for row in [('عنوان',spec['title']),('گروه‌بندی',' ← '.join(labels[k] for k in groups)),('شاخص',METRICS[metric]),('محدوده انتخاب‌شده',spec['context']),('تاریخ تهیه',date_label),('تعداد کارکنان',len(rows)),('توضیح','خلاصه در سرور از رکوردهای مجاز و انتخاب‌شده محاسبه شده؛ داده ناموجود از میانگین حذف می‌شود.')]:info.append(row)
    for row in info:
        for cell in row:
            cell.font=Font(name='Tahoma',size=12);cell.alignment=Alignment(horizontal='right',wrap_text=True)
            if isinstance(cell.value,str):cell.data_type='s'
    info.column_dimensions['A'].width=25;info.column_dimensions['B'].width=95
    book.active=0
