"""Offline-only authenticated restore, safety snapshot, integrity checks and crash rollback."""
from pathlib import Path
from contextlib import closing
import json,io,zipfile,hashlib,sqlite3,shutil,os,time,socket
from cryptography.fernet import Fernet
from werkzeug.security import check_password_hash
ALLOWED={'hr.sqlite3','security.key','session.key','behnova-server.json'}

def installation_data(data):
 data=Path(data)
 return data.parent.parent if data.parent.name=='companies' and (data.parent.parent/'companies.sqlite3').is_file() else data

def stopped_lock(data):
 from server_lifecycle import DataLock
 lock=DataLock(installation_data(data))
 if not lock.acquire():raise ValueError('سرور این نصب فعال یا در حال راه‌اندازی است؛ ابتدا STOP.cmd را اجرا کنید و منتظر پیام توقف کامل بمانید. بستن مرورگر کافی نیست.')
 return lock

def guard_stopped(data):
 # A copied PID or a port occupied by unrelated software is not proof of a live server.
 lock=stopped_lock(data);lock.close()


def recover_interrupted(data):
 data=Path(data);journal=data/'restore-in-progress.json'
 if not journal.exists():return
 info=json.loads(journal.read_text());safety=Path(info['safety']).resolve();root=data.parent/'backups'
 if root.resolve() not in safety.parents:raise RuntimeError('مسیر بازیابی ایمنی نامعتبر است؛ برنامه برای حفاظت از داده متوقف شد.')
 for name in ['hr.sqlite3','security.key','session.key']:
  if not (safety/name).is_file():raise RuntimeError('پشتیبان ایمنی بازیابی ناقص است؛ مسئول IT باید بررسی کند.')
 for name in ALLOWED:
  if (safety/name).exists():shutil.copy2(safety/name,data/name)
  elif name=='behnova-server.json':(data/name).unlink(missing_ok=True)
 for name in ['hr.sqlite3-wal','hr.sqlite3-shm']:(data/name).unlink(missing_ok=True)
 journal.unlink()

def restore_backup(raw,data,username,password):
 lock=stopped_lock(data)
 try:return _restore_backup(raw,data,username,password)
 finally:lock.close()

def _restore_backup(raw,data,username,password):
 data=Path(data)
 current=data/'hr.sqlite3'
 if not current.exists():raise ValueError('نصب موجود پیدا نشد؛ این ابزار فقط برای بازیابی نصب موجود است.')
 with closing(sqlite3.connect(current)) as c:
  c.row_factory=sqlite3.Row;u=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
  valid=bool(u and u['role']=='admin' and not ('disabled' in u.keys() and u['disabled']) and check_password_hash(u['password_hash'],password))
 if not valid and data.parent.name=='companies' and (data.parent.parent/'companies.sqlite3').is_file():
  with closing(sqlite3.connect(data.parent.parent/'hr.sqlite3')) as c:
   c.row_factory=sqlite3.Row;u=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone();valid=bool(u and u['role']=='admin' and not u['disabled'] and check_password_hash(u['password_hash'],password))
 if not valid:raise ValueError('حساب و رمز ادمین فعلی معتبر نیست.')
 if len(raw)>80*1024*1024:raise ValueError('فایل پشتیبان بیش از حد بزرگ است.')
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  names=z.namelist()
  if len(names)!=len(set(names)) or set(names)-ALLOWED-{'BACKUP-SHA256.json'} or not {'hr.sqlite3','security.key','session.key','BACKUP-SHA256.json'}<=set(names):raise ValueError('این فایل، پشتیبان کامل معتبر BEHNOVA نیست.')
  if sum(i.file_size for i in z.infolist())>128*1024*1024:raise ValueError('حجم بازشده پشتیبان بیش از حد مجاز است.')
  manifest=json.loads(z.read('BACKUP-SHA256.json'))
  if set(manifest)!=set(names)-{'BACKUP-SHA256.json'}:raise ValueError('فهرست صحت فایل ناقص است.')
  files={name:z.read(name) for name in names if name in ALLOWED}
  if any(hashlib.sha256(files[n]).hexdigest()!=h for n,h in manifest.items()):raise ValueError('صحت فایل پشتیبان تأیید نشد.')
 with closing(sqlite3.connect(current)) as c:
  current_guid=c.execute("SELECT value FROM app_meta WHERE key='company_instance_id'").fetchone()
 import tempfile
 with tempfile.TemporaryDirectory() as tmp:
  candidate=Path(tmp)/'company.sqlite3';candidate.write_bytes(files['hr.sqlite3'])
  with closing(sqlite3.connect(candidate)) as c:
   try:incoming_guid=c.execute("SELECT value FROM app_meta WHERE key='company_instance_id'").fetchone()
   except sqlite3.DatabaseError:incoming_guid=None
 if current_guid and incoming_guid and current_guid[0]!=incoming_guid[0]:raise ValueError('این پشتیبان متعلق به شرکت دیگری است؛ اطلاعات هیچ شرکتی تغییر نکرد.')
 if current_guid and not incoming_guid and data.parent.name=='companies':raise ValueError('پشتیبان قدیمی بدون شناسه شرکت فقط در نصب اصلی قابل بازیابی است.')
 cipher=Fernet(files['security.key'])
 if not 32<=len(files['session.key'].decode('utf-8').strip())<=4096:raise ValueError('کلید نشست پشتیبان معتبر نیست.')
 stage=data/'.restore-stage';stage.mkdir(exist_ok=True,mode=0o700)
 try:
  target=stage/'hr.sqlite3';target.write_bytes(files['hr.sqlite3'])
  with closing(sqlite3.connect(target)) as c:
   c.execute("PRAGMA journal_mode=DELETE")
   c.row_factory=sqlite3.Row
   if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('دیتابیس پشتیبان سالم نیست.')
   tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
   if not {'users','employees','audit'}<=tables:raise ValueError('ساختار پشتیبان معتبر نیست.')
   active=[r for r in c.execute("SELECT * FROM users WHERE role='admin'") if 'disabled' not in r.keys() or not r['disabled']]
   if not active:raise ValueError('پشتیبان باید حداقل یک ادمین فعال داشته باشد.')
   for u in c.execute("SELECT mfa_secret FROM users WHERE mfa_secret<>''"):cipher.decrypt(u[0].encode())
   if 'employee_history' in tables:
    for h in c.execute('SELECT before_data,after_data FROM employee_history'):
     for blob in h:
      if blob:cipher.decrypt(blob)
   if 'personnel_records' in tables:
    for r in c.execute('SELECT payload FROM personnel_records'):cipher.decrypt(r[0])
   if 'personnel_record_history' in tables:
    for r in c.execute('SELECT before_data,after_data FROM personnel_record_history'):
     for blob in r:
      if blob:cipher.decrypt(blob)
   for name in ['sessions','mfa_pending','import_previews','vehicle_import_previews','record_import_previews','unified_excel_previews']:
    if name in tables:c.execute('DELETE FROM '+name)
   c.execute('INSERT INTO audit(user_id,action,detail,created_at) VALUES(NULL,?,?,?)',('بازیابی آفلاین با تأیید ادمین','نشست‌ها و پیش‌نمایش‌های پشتیبان باطل شدند',time.strftime('%Y-%m-%dT%H:%M:%S')))
   c.commit()
  files['hr.sqlite3']=target.read_bytes()
  # Do not roll this machine's verified server ownership back to a copied backup.
  if (data/'behnova-server.json').exists():files['behnova-server.json']=(data/'behnova-server.json').read_bytes()
  safety=data.parent/'backups'/('before-restore-'+str(time.time_ns()));safety.mkdir(parents=True,mode=0o700)
  for name in ALLOWED-{'hr.sqlite3'}:
   if (data/name).exists():shutil.copy2(data/name,safety/name)
  with closing(sqlite3.connect(current)) as source,closing(sqlite3.connect(safety/'hr.sqlite3')) as destination:
   source.backup(destination);destination.execute('PRAGMA journal_mode=DELETE');destination.commit()
  journal=data/'restore-in-progress.json';journal.write_text(json.dumps({'safety':str(safety)}),encoding='utf-8')
  try:
   for name,content in files.items():
    p=stage/name;p.write_bytes(content);os.chmod(p,0o600);os.replace(p,data/name)
   for name in ['hr.sqlite3-wal','hr.sqlite3-shm']:(data/name).unlink(missing_ok=True)
   journal.unlink()
  except BaseException:recover_interrupted(data);raise
  return str(safety)
 finally:shutil.rmtree(stage,ignore_errors=True)
