"""Local one-use browser UI for a stopped Windows installation. No app import or universal password."""
from pathlib import Path
import os,secrets,time,webbrowser,json,urllib.parse,sqlite3,html
from http.server import HTTPServer,BaseHTTPRequestHandler
from restore_support import guard_stopped,restore_backup
BASE=Path(__file__).resolve().parent.parent
DATA=Path(os.environ.get('BEHNOVA_DATA_DIR',str(BASE/'data'))).resolve()
COMPANIES={1:('شرکت اول',DATA)}
if (DATA/'companies.sqlite3').exists():
 with sqlite3.connect(DATA/'companies.sqlite3') as c:
  for ident,name,guid in c.execute('SELECT id,name,guid FROM companies'):
   if ident==1:COMPANIES[ident]=(name,DATA)
   elif len(guid)==32 and all(ch in '0123456789abcdef' for ch in guid):COMPANIES[ident]=(name,DATA/'companies'/guid)
TOKEN=secrets.token_urlsafe(32);done=False;attempts=0
PAGE='''<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>BEHNOVA — بازیابی آفلاین</title><style>body{font:16px/2 Tahoma,sans-serif;background:#f3f7f5;color:#183b30;max-width:720px;margin:40px auto;padding:24px}form{background:white;padding:26px;border-radius:16px}label{display:block;margin:16px 0}input{display:block;width:95%;padding:12px;font:inherit;border:1px solid #bdcfc6;border-radius:8px}button{font:inherit;padding:12px 24px;background:#155f51;color:white;border:0;border-radius:8px}p{white-space:pre-wrap}</style><h1>BEHNOVA — بازیابی پشتیبان</h1><p>سرور باید کاملاً متوقف باشد. بازیابی، اطلاعات و حساب‌ها را به زمان پشتیبان برمی‌گرداند؛ تغییرات بعدی جایگزین می‌شوند. ابتدا یک پشتیبان ایمنی از وضع فعلی تهیه می‌شود. پس از بازیابی با حساب‌های نسخه پشتیبان وارد شوید.</p><form id="form"><label>نام کاربری ادمین فعلی<input name="username" autocomplete="username" required></label><label>رمز ادمین فعلی<input name="password" type="password" autocomplete="current-password" required></label><label>فایل BEHNOVA-Backup.zip<input type="file" name="backup" accept=".zip" required></label><label><input style="display:inline;width:auto" type="checkbox" required>توقف سرور و جایگزینی اطلاعات با پشتیبان را تأیید می‌کنم.</label><button>بررسی و بازیابی</button><p id="message"></p></form><script>document.querySelector('#form').onsubmit=async e=>{e.preventDefault();const f=e.target,b=f.querySelector('button');if(!confirm('اطلاعات فعلی با پشتیبان انتخابی جایگزین شود؟'))return;b.disabled=true;try{const res=await fetch(location.pathname,{method:'POST',headers:{'X-Restore-Token':location.pathname.slice(1),'X-Admin-Name':encodeURIComponent(f.username.value),'X-Admin-Password':encodeURIComponent(f.password.value)},body:f.backup.files[0]});f.password.value='';const d=await res.json();document.querySelector('#message').textContent=d.message;if(!res.ok)b.disabled=false}catch(err){document.querySelector('#message').textContent='ارتباط پایان یافت؛ برای بررسی نتیجه دوباره ابزار را اجرا نکنید مگر اینکه وضعیت پوشه داده بررسی شود.'}};</script></html>'''
PAGE=PAGE.replace('<label>نام کاربری ادمین فعلی', '<label>شرکت مقصد بازیابی<select name="company">'+''.join('<option value="'+str(i)+'">'+html.escape(n)+'</option>' for i,(n,_) in COMPANIES.items())+'</select></label><label>نام کاربری ادمین فعلی')
PAGE=PAGE.replace("'X-Restore-Token':location.pathname.slice(1)","'X-Company-Id':f.company.value,'X-Restore-Token':location.pathname.slice(1)")
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def send(self,code,body,kind):
  self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(body)
 def valid(self):return self.path=='/'+TOKEN and self.headers.get('Host')=='127.0.0.1:'+str(self.server.server_port)
 def do_GET(self):
  if not self.valid():return self.send(404,b'Not found','text/plain')
  self.send(200,PAGE.encode(),'text/html; charset=utf-8')
 def do_POST(self):
  global done,attempts
  if not self.valid() or not secrets.compare_digest(self.headers.get('X-Restore-Token',''),TOKEN):return self.send(403,b'{}','application/json')
  origin=self.headers.get('Origin','')
  if origin!='http://127.0.0.1:'+str(self.server.server_port):return self.send(403,b'{}','application/json')
  try:
   n=int(self.headers.get('Content-Length','0'))
   if not 0<n<=80*1024*1024:raise ValueError('اندازه فایل نامعتبر است.')
   self.connection.settimeout(60);raw=self.rfile.read(n)
   if len(raw)!=n:raise ValueError('فایل ناقص دریافت شد.')
   attempts+=1
   company=int(self.headers.get('X-Company-Id','1'))
   if company not in COMPANIES:raise ValueError('شرکت مقصد مجاز نیست.')
   safety=restore_backup(raw,COMPANIES[company][1],urllib.parse.unquote(self.headers.get('X-Admin-Name','')),urllib.parse.unquote(self.headers.get('X-Admin-Password','')))
   done=True;self.send(200,json.dumps({'message':'بازیابی انجام شد. این پنجره را ببندید و START.cmd را اجرا کنید. پشتیبان ایمنی: '+safety},ensure_ascii=False).encode(),'application/json; charset=utf-8')
  except Exception as e:self.send(400,json.dumps({'message':str(e)},ensure_ascii=False).encode(),'application/json; charset=utf-8')
if __name__=='__main__':
 try:
  guard_stopped(DATA)
  server=HTTPServer(('127.0.0.1',0),Handler)
  if server.server_port==8765:server.server_close();server=HTTPServer(('127.0.0.1',0),Handler)
  server.timeout=1;webbrowser.open('http://127.0.0.1:'+str(server.server_port)+'/'+TOKEN)
  until=time.time()+600
  while not done and attempts<5 and time.time()<until:server.handle_request()
  server.server_close()
 except Exception as e:
  if os.name=='nt':
   import ctypes
   ctypes.windll.user32.MessageBoxW(None,str(e),'BEHNOVA',0x10)
  else:raise
