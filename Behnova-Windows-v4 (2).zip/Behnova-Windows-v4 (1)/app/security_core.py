"""Standard cryptographic primitives; no custom encryption algorithm."""
import base64, hashlib, hmac, os, secrets, struct, time
from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken

def cipher_for(directory):
    path=Path(directory)/'security.key'
    if not path.exists():
        try:
            with path.open('xb') as f:f.write(Fernet.generate_key())
            os.chmod(path,0o600)
        except FileExistsError:pass
    return Fernet(path.read_bytes().strip())

def token_hash(value):return hashlib.sha256(str(value).encode('utf-8')).hexdigest()
def new_totp_secret():return base64.b32encode(secrets.token_bytes(20)).decode().rstrip('=')
def totp_at(secret,counter):
    key=base64.b32decode(secret+'='*((8-len(secret)%8)%8))
    digest=hmac.new(key,struct.pack('>Q',counter),hashlib.sha1).digest();offset=digest[-1]&15
    value=(struct.unpack('>I',digest[offset:offset+4])[0]&0x7fffffff)%1000000
    return f'{value:06d}'
def totp_counter(secret,code,last=-1,now=None):
    code=str(code).strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹','0123456789'))
    if len(code)!=6 or not code.isdigit():return None
    current=int((time.time() if now is None else now)//30)
    for delta in [0,-1,1]:
        step=current+delta
        if step>last and hmac.compare_digest(totp_at(secret,step),code):return step
    return None

def recovery_hash(code):return token_hash(str(code).upper().replace('-','').replace(' ',''))
def recovery_codes():
    raw=[secrets.token_hex(8).upper() for _ in range(10)]
    return [x[:8]+'-'+x[8:] for x in raw],[recovery_hash(x) for x in raw]
