"""Local, per-installation lifecycle controls. No global mutex or process-name killing.
A real OS file lock guards the database. Stale/copied JSON files do not hold locks.
The shutdown capability is random per run, local-only, and never included in backups.
"""
import os,socket,secrets,hashlib,json,time,threading,urllib.request,urllib.parse,ssl,html
from pathlib import Path
from http.server import HTTPServer,BaseHTTPRequestHandler

def machine_id():
 value=''
 if os.name=='nt':
  try:
   import winreg
   with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\Microsoft\Cryptography') as k:value=winreg.QueryValueEx(k,'MachineGuid')[0]
  except OSError:pass
 else:
  try:value=Path('/etc/machine-id').read_text().strip()
  except OSError:pass
 return hashlib.sha256((str(value)+'|'+socket.gethostname().lower()).encode()).hexdigest()

def data_id(data):return hashlib.sha256(os.path.normcase(str(Path(data).resolve())).encode()).hexdigest()
def read_json(path):
 try:
  value=json.loads(Path(path).read_text(encoding='utf-8'));return value if isinstance(value,dict) else {}
 except (OSError,ValueError):return {}
def write_json(path,value):
 path=Path(path);temp=path.with_name(path.name+'.'+secrets.token_hex(6)+'.tmp')
 try:
  with temp.open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
  os.chmod(temp,0o600);os.replace(temp,path)
 finally:temp.unlink(missing_ok=True)

def private_directory(path):
 """Restrict new runtime capabilities/keys to this operator, SYSTEM and Windows admins."""
 path=Path(path);path.mkdir(parents=True,exist_ok=True)
 if os.name!='nt':os.chmod(path,0o700);return
 import ctypes,subprocess,re
 from ctypes import wintypes
 result=subprocess.run(['whoami','/user','/fo','csv','/nh'],capture_output=True,timeout=10,creationflags=0x08000000)
 match=re.search(rb'S-1-[0-9]+(?:-[0-9]+)+',result.stdout)
 if result.returncode or not match:raise OSError('هویت حساب ویندوز برای حفاظت از پوشه مشخص نشد.')
 sid=match.group().decode('ascii');adv=ctypes.WinDLL('advapi32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 adv.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,ctypes.POINTER(ctypes.c_void_p),ctypes.POINTER(wintypes.DWORD)]
 adv.GetSecurityDescriptorDacl.argtypes=[ctypes.c_void_p,ctypes.POINTER(wintypes.BOOL),ctypes.POINTER(ctypes.c_void_p),ctypes.POINTER(wintypes.BOOL)]
 adv.SetNamedSecurityInfoW.argtypes=[wintypes.LPWSTR,ctypes.c_int,wintypes.DWORD,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p];adv.SetNamedSecurityInfoW.restype=wintypes.DWORD
 kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
 sd=ctypes.c_void_p();acl=ctypes.c_void_p();present=wintypes.BOOL();defaulted=wintypes.BOOL()
 value='D:P(A;OICI;FA;;;'+sid+')(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)'
 if not adv.ConvertStringSecurityDescriptorToSecurityDescriptorW(value,1,ctypes.byref(sd),None):raise ctypes.WinError(ctypes.get_last_error())
 try:
  if not adv.GetSecurityDescriptorDacl(sd,ctypes.byref(present),ctypes.byref(acl),ctypes.byref(defaulted)):raise ctypes.WinError(ctypes.get_last_error())
  error=adv.SetNamedSecurityInfoW(str(path),1,0x80000004,None,None,acl,None)
  if error:raise OSError(error,'تنظیم دسترسی امن پوشه ممکن نشد؛ مسئول IT باید دسترسی NTFS حساب اجرای سرور را بررسی کند.')
 finally:kernel.LocalFree(sd)

def remote_drive(path):
 if os.name!='nt':return str(path).startswith(('\\\\','//'))
 import ctypes
 p=str(Path(path).resolve())
 if p.startswith('\\\\'):return True
 return ctypes.windll.kernel32.GetDriveTypeW(str(Path(p).anchor))==4

class DataLock:
 def __init__(self,data):self.path=Path(data)/'behnova.lock';self.file=None
 def acquire(self):
  f=self.path.open('a+b');f.seek(0,2)
  if f.tell()==0:f.write(b'0');f.flush()
  f.seek(0)
  try:
   if os.name=='nt':
    import msvcrt
    msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
   else:
    import fcntl
    fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
  except OSError:f.close();return False
  self.file=f;return True
 def close(self):
  if self.file:self.file.close();self.file=None

def control_info(data):
 d=read_json(Path(data)/'behnova-control.json')
 if d.get('host_id')!=machine_id() or d.get('data_id')!=data_id(data):return None
 try:
  url=urllib.parse.urlsplit(d['control_url']);assert url.scheme=='http' and url.hostname=='127.0.0.1' and url.port and not url.username and not url.password and url.path in ['','/'] and not url.query and not url.fragment
  assert isinstance(d['token'],str) and len(d['token'])>=40 and isinstance(d['instance'],str) and type(d['pid']) is int and d['pid']>0
 except (KeyError,ValueError,AssertionError):return None
 return d

def control_request(info,action='status'):
 url=info['control_url']+'/'+action
 request=urllib.request.Request(url,headers={'X-Behnova-Control':info['token'],'X-Behnova-Instance':info['instance']},method='POST' if action=='stop' else 'GET',data=b'' if action=='stop' else None)
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 with opener.open(request,timeout=2) as response:d=json.load(response)
 if any(d.get(k)!=info.get(k) for k in ['instance','pid','host_id','data_id']):raise ValueError('پاسخ توقف متعلق به این نسخه نیست.')
 return d

class LocalControl:
 def __init__(self,data,info,shutdown):
  self.data=Path(data);self.info={**info,'host_id':machine_id(),'data_id':data_id(data),'pid':os.getpid(),'token':secrets.token_urlsafe(48)};self.shutdown=shutdown;outer=self
  class Handler(BaseHTTPRequestHandler):
   def setup(self):
    super().setup();self.connection.settimeout(3)
   def log_message(self,*args):pass
   def handle_action(self):
    self.connection.settimeout(3)
    valid=self.headers.get('Host')=='127.0.0.1:'+str(self.server.server_port) and not self.headers.get('Origin') and secrets.compare_digest(self.headers.get('X-Behnova-Control',''),outer.info['token']) and secrets.compare_digest(self.headers.get('X-Behnova-Instance',''),outer.info['instance'])
    if not valid:return self.reply(403,{'error':'not authorized'})
    if self.command=='GET' and self.path=='/status':return self.reply(200,outer.public())
    if self.command=='POST' and self.path=='/stop' and self.headers.get('Content-Length','0')=='0':
     self.reply(200,{**outer.public(),'stopping':True});threading.Timer(.05,outer.shutdown).start();return
    self.reply(404,{'error':'not found'})
   do_GET=do_POST=handle_action
   def reply(self,status,value):
    body=json.dumps(value).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
  self.server=HTTPServer(('127.0.0.1',0),Handler)
  if self.server.server_port==8765:self.server.server_close();self.server=HTTPServer(('127.0.0.1',0),Handler)
  self.info['control_url']='http://127.0.0.1:'+str(self.server.server_port)
  self.thread=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':.1},daemon=True)
 def public(self):return {k:v for k,v in self.info.items() if k not in ['token','control_url']}
 def start(self):
  self.thread.start();write_json(self.data/'behnova-control.json',self.info)
  write_json(self.data/'behnova-running.json',self.public())
 def close(self):
  self.server.shutdown();self.server.server_close();self.thread.join(timeout=3)
  for name in ['behnova-control.json','behnova-running.json']:
   file=self.data/name
   if read_json(file).get('instance')==self.info['instance']:file.unlink(missing_ok=True)

def process_exited(pid):
 if os.name=='nt':
  import ctypes
  from ctypes import wintypes
  k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k.OpenProcess.restype=wintypes.HANDLE;k.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k.CloseHandle.argtypes=[wintypes.HANDLE]
  h=k.OpenProcess(0x100000|0x1000,False,pid)
  if not h:return ctypes.get_last_error()==87 # Invalid PID, not access denied.
  try:return k.WaitForSingleObject(h,0)==0
  finally:k.CloseHandle(h)
 try:
  stat=Path('/proc')/str(pid)/'stat'
  if stat.exists() and stat.read_text().rsplit(')',1)[1].strip().startswith('Z'):return True
  os.kill(pid,0);return False
 except ProcessLookupError:return True
 except PermissionError:return False

def stop_server(data,timeout=45):
 data=Path(data)
 if not data.exists():return 'این پوشه هنوز سروری ندارد؛ چیزی متوقف یا حذف نشد.'
 info=control_info(data)
 if not info:
  probe=DataLock(data)
  if probe.acquire():probe.close();return 'سرور فعالی برای این پوشه پیدا نشد. هیچ پردازشی بسته و هیچ اطلاعاتی حذف نشد.'
  raise ValueError('این پوشه در استفاده است، اما کنترل امن این نسخه پیدا نشد. برای نسخه قدیمی از «پایان اجرای برنامه» در تنظیمات استفاده کنید؛ پردازش دیگری خودکار بسته نشد.')
 try:control_request(info,'status')
 except Exception:
  probe=DataLock(data)
  if probe.acquire():probe.close();return 'سروری پاسخ نداد و قفل داده آزاد است؛ هیچ پردازشی بسته نشد. اگر ویندوز هنوز پوشه را درگیر می‌داند، سایر پنجره‌ها، ابزار بازیابی، آنتی‌ویروس و مجوزهای پوشه را بررسی کنید.'
  raise ValueError('قفل واقعی این پوشه فعال است اما کنترل امن پاسخ نمی‌دهد؛ کمی صبر کنید یا گزارش launcher.log را بررسی کنید. هیچ پردازشی به‌اجبار بسته نشد.')
 control_request(info,'stop');deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  if process_exited(info['pid']):
   probe=DataLock(data)
   if probe.acquire():probe.close();return 'سرور همین نسخه کاملاً متوقف شد. پردازش برنامه پایان یافت و فایل‌های آن برای جابه‌جایی آزاد شدند. پوشه data شامل اطلاعات شماست؛ آن را بدون پشتیبان حذف نکنید.'
  time.sleep(.15)
 raise ValueError('درخواست توقف ارسال شد، اما خروج کامل هنوز تأیید نشده است. ممکن است عملیاتی در حال پایان باشد. فعلاً پوشه را حذف نکنید؛ برنامه یا پردازش دیگری به‌اجبار بسته نشد.')

def ensure_https(tls,addresses):
 """Generate a unique private LAN CA only when no IT-provided keypair exists.
 No trust-store changes, certificate validation disabling, or public-port exposure.
 """
 tls=Path(tls);cert=tls/'server.crt';key=tls/'server.key';ca=tls/'ca.crt'
 if cert.exists() or key.exists():
  if not cert.is_file() or not key.is_file():raise ValueError('گواهی و کلید HTTPS باید هر دو موجود باشند؛ فایل موجود بازنویسی نشد.')
  return False
 from cryptography import x509
 from cryptography.x509.oid import NameOID,ExtendedKeyUsageOID
 from cryptography.hazmat.primitives import hashes,serialization
 from cryptography.hazmat.primitives.asymmetric import rsa
 from datetime import datetime,timedelta,timezone
 import ipaddress
 private_directory(tls);now=datetime.now(timezone.utc)
 if ca.exists() or (tls/'ca.key').exists():raise ValueError('فایل‌های گواهی ناقص‌اند؛ برای حفظ کلید موجود، گواهی جدید خودکار ساخته نشد.')
 rootkey=rsa.generate_private_key(public_exponent=65537,key_size=3072);subject=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'BEHNOVA Private LAN '+secrets.token_hex(4))])
 root=(x509.CertificateBuilder().subject_name(subject).issuer_name(subject).public_key(rootkey.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=1825)).add_extension(x509.SubjectKeyIdentifier.from_public_key(rootkey.public_key()),critical=False).add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(rootkey.public_key()),critical=False).add_extension(x509.BasicConstraints(ca=True,path_length=0),critical=True).add_extension(x509.KeyUsage(False,False,False,False,False,True,True,False,False),critical=True).sign(rootkey,hashes.SHA256()))
 leafkey=rsa.generate_private_key(public_exponent=65537,key_size=2048);sans=[x509.DNSName('localhost')]
 for name in sorted({socket.gethostname().lower(),socket.getfqdn().lower()}):
  if name and name!='localhost':sans.append(x509.DNSName(name))
 for address in sorted(set(addresses)|{'127.0.0.1','::1'}):sans.append(x509.IPAddress(ipaddress.ip_address(address)))
 leaf=(x509.CertificateBuilder().subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'BEHNOVA LAN Server')])).issuer_name(root.subject).public_key(leafkey.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5)).not_valid_after(now+timedelta(days=365)).add_extension(x509.SubjectKeyIdentifier.from_public_key(leafkey.public_key()),critical=False).add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(rootkey.public_key()),critical=False).add_extension(x509.KeyUsage(True,False,True,False,False,False,False,False,False),critical=True).add_extension(x509.BasicConstraints(ca=False,path_length=None),critical=True).add_extension(x509.SubjectAlternativeName(sans),critical=False).add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),critical=False).sign(rootkey,hashes.SHA256()))
 def pem(path,value,private=False):
  with path.open('xb') as f:f.write(value)
  os.chmod(path,0o600 if private else 0o644)
 pem(tls/'ca.key',rootkey.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()),True)
 pem(ca,root.public_bytes(serialization.Encoding.PEM));pem(key,leafkey.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()),True);pem(cert,leaf.public_bytes(serialization.Encoding.PEM));return True

def validate_tls(tls,addresses):
 from cryptography import x509
 from datetime import datetime,timezone
 import ipaddress
 tls=Path(tls);context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
 try:
  context.load_cert_chain(str(tls/'server.crt'),str(tls/'server.key'))
  leaf=x509.load_pem_x509_certificate((tls/'server.crt').read_bytes())
  now=datetime.now(timezone.utc)
  if not leaf.not_valid_before_utc<=now<leaf.not_valid_after_utc:raise ValueError('گواهی HTTPS هنوز معتبر نیست یا منقضی شده است؛ ساعت سیستم و گواهی را بررسی کنید.')
  san=leaf.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
  covered=set(san.get_values_for_type(x509.IPAddress));missing=[a for a in set(addresses)|{'127.0.0.1'} if ipaddress.ip_address(a) not in covered]
  if missing:raise ValueError('گواهی HTTPS آدرس‌های فعلی سرور را پوشش نمی‌دهد: '+', '.join(sorted(missing))+'؛ برای IP ثابت و صدور گواهی جدید با IT هماهنگ کنید. گواهی موجود بازنویسی نشد.')
 except (OSError,ssl.SSLError,x509.ExtensionNotFound) as e:raise ValueError('گواهی یا کلید HTTPS قابل استفاده نیست: '+str(e)) from e

def browser_links(base,urls):
 """A copyable public client page; contains no runtime, DB, password or private key."""
 base=Path(base);items=''.join('<p><a href="'+html.escape(url,quote=True)+'" dir="ltr">'+html.escape(url)+'</a></p>' for url in urls)
 page='<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BEHNOVA — اتصال به سرور</title><style>body{font:16px/2 Tahoma;max-width:760px;margin:40px auto;padding:24px;background:#f3f7f5;color:#204b39}a{display:block;overflow-wrap:anywhere;padding:14px;background:white;border:1px solid #c8dfd0;border-radius:10px}</style><h1>ورود به BEHNOVA</h1><p>یکی از آدرس‌های سرور مرکزی را باز کنید. اطلاعات همه کاربران روی همان سرور است؛ روی کامپیوتر کاربران START.cmd اجرا نکنید و پوشه data یا runtime را کپی نکنید.</p>'+items+'<p>برای گواهی داخلی، مسئول IT باید فقط گواهی عمومی BEHNOVA-Root-CA.crt را روی دستگاه‌ها قابل‌اعتماد کند. هشدار گواهی را نادیده نگیرید. اگر سرور خاموش است یا در شبکه دیگری هستید، این لینک‌ها کار نمی‌کنند.</p><p>برای بیرون از شبکه شرکت از VPN و تنظیمات امن IT استفاده کنید؛ برنامه را مستقیم روی اینترنت عمومی باز نکنید.</p></html>'
 (base/'CONNECT-TO-SERVER.html').write_text(page,encoding='utf-8')
