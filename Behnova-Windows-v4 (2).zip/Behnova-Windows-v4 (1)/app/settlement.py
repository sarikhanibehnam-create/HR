"""Independent settlement dates and authorized, source-record-based XLSX reports."""
import io
from text_search import search_key
from datetime import date
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
STAGES=[('ready','settlement_ready_date','تسویه آماده شده','تاریخ آماده شدن تسویه'),('signed','settlement_signed_date','امضا شده','تاریخ امضای تسویه'),('finance','settlement_finance_date','تحویل واحد مالی شده','تاریخ تحویل تسویه به مالی'),('paid','settlement_paid_date','پرداخت شده','تاریخ پرداخت تسویه')]
FIELDS=[(key,label) for _,key,_,label in STAGES]
KEYS={key for key,_ in FIELDS}
MISSING='ثبت نشده'

def last_stage(row):
 return next((ident for ident,key,_,_ in reversed(STAGES) if row.get(key)), 'none')

def stage_label(row):
 last=last_stage(row)
 return next((label for ident,_,label,_ in STAGES if ident==last),MISSING)

def validate_filters(payload,parse_date):
 if not isinstance(payload,dict):raise ValueError('فیلتر تسویه نامعتبر است.')
 flags=payload.get('stages',{})
 if not isinstance(flags,dict) or any(key not in KEYS or value not in ['','registered','missing'] for key,value in flags.items()):raise ValueError('وضعیت مرحله تسویه نامعتبر است.')
 latest=payload.get('latest','');stage=payload.get('date_stage','')
 if latest not in ['', 'none']+[s[0] for s in STAGES] or stage not in ['']+[s[1] for s in STAGES]:raise ValueError('مرحله انتخاب‌شده نامعتبر است.')
 lower=parse_date(payload.get('from'));upper=parse_date(payload.get('to'))
 if (lower or upper) and not stage:raise ValueError('برای بازه تاریخ، مرحله موردنظر را انتخاب کنید.')
 if lower and upper and lower>upper:raise ValueError('تاریخ شروع نباید پس از تاریخ پایان باشد.')
 search=payload.get('search','')
 if not isinstance(search,str) or len(search)>180:raise ValueError('متن جست‌وجو نامعتبر است.')
 return {'stages':flags,'latest':latest,'date_stage':stage,'from':lower,'to':upper,'search':search.strip()}

def matches(row,filters):
 for key,flag in filters['stages'].items():
  if flag=='registered' and not row.get(key):return False
  if flag=='missing' and row.get(key):return False
 if filters['latest'] and last_stage(row)!=filters['latest']:return False
 key=filters['date_stage'];lower=filters['from'];upper=filters['to']
 if lower or upper:
  value=row.get(key,'')
  if not value or lower and value<lower or upper and value>upper:return False
 search=search_key(filters['search'])
 return not search or any(search in search_key(row.get(k,'')) for k in ['code','name','department','location'])

def workbook_bytes(rows,fa_date,today,context,field_labels=None):
 book=openpyxl.Workbook();book.properties.creator='BEHNOVA';book.properties.title='BEHNOVA — گزارش پیگیری تسویه'
 sheet=book.active;sheet.title='پیگیری تسویه';sheet.sheet_view.rightToLeft=True
 sheet.append(['کد پرسنلی','نام و نام خانوادگی','واحد سازمانی','محل فعالیت']+[(field_labels or {}).get(key,label) for key,label in FIELDS]+['آخرین مرحله ثبت شده'])
 for row in rows:
  sheet.append([row.get(k,'') for k in ['code','name','department','location']]+[fa_date(date.fromisoformat(row[key])) if row.get(key) else MISSING for key,_ in FIELDS]+[stage_label(row)])
 for row in sheet:
  for cell in row:
   cell.font=Font(name='Tahoma',size=11);cell.alignment=Alignment(horizontal='right',vertical='center',wrap_text=True)
   if isinstance(cell.value,str):cell.data_type='s';cell.number_format='@'
   if cell.value==MISSING:cell.fill=PatternFill('solid',fgColor='FFF2DE')
 for cell in sheet[1]:cell.font=Font(name='Tahoma',size=11,bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='155F51')
 for i in range(1,10):sheet.column_dimensions[get_column_letter(i)].width=30 if i!=2 else 38
 sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions;sheet.print_title_rows='1:1';sheet.sheet_properties.pageSetUpPr.fitToPage=True;sheet.page_setup.orientation='landscape';sheet.page_setup.paperSize=sheet.PAPERSIZE_A4;sheet.page_setup.fitToWidth=1;sheet.page_setup.fitToHeight=0
 summary=book.create_sheet('خلاصه و راهنما');summary.sheet_view.rightToLeft=True
 for values in [('محصول','BEHNOVA'),('گزارش','پیگیری تسویه'),('تاریخ تهیه',fa_date(today)),('تعداد افراد',len(rows)),('محدوده',context),('معنای ثبت نشده','برای این مرحله تاریخی ثبت نشده است؛ این عبارت اثبات انجام‌نشدن کار نیست.'),('مراحل مستقل','ثبت یک مرحله به معنی ثبت یا انجام مراحل قبلی نیست.'),('آخرین مرحله','بر اساس ترتیب آماده‌سازی، امضا، مالی، پرداخت؛ نه بزرگ‌ترین تاریخ و نه تأیید مراحل قبلی.')]:summary.append(values)
 for _,key,label,_ in STAGES:summary.append((label+' — تاریخ ثبت شده',sum(bool(r.get(key)) for r in rows)));summary.append((label+' — ثبت نشده',sum(not r.get(key) for r in rows)))
 for row in summary:
  for cell in row:
   cell.font=Font(name='Tahoma',size=11);cell.alignment=Alignment(horizontal='right',wrap_text=True)
   if isinstance(cell.value,str):cell.data_type='s'
 summary.column_dimensions['A'].width=38;summary.column_dimensions['B'].width=105
 output=io.BytesIO();book.save(output);return output.getvalue()
