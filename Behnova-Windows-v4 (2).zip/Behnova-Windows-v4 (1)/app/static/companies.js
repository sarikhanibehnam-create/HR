'use strict';
// Company state is intentionally tab-local; every API request carries its own scope.
globalThis.BehnovaCompany=globalThis.BehnovaCompany||{id:0,epoch:0,pendingWrites:0,companies:[],canManage:false};
const companyState=globalThis.BehnovaCompany;
function renderCompanyContext(){
 const select=$('#companyPicker');if(!select)return;
 select.innerHTML=(companyState.companies||[]).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');select.value=String(companyState.id);$('#companyPickerWrap').hidden=!user||!companyState.companies?.length;
 globalThis.BehnovaSettings?.refreshAccess();
 const active=companyState.companies?.find(c=>c.id===companyState.id);document.body.dataset.companyId=String(companyState.id||'');
 document.querySelectorAll('.company-name-print').forEach(e=>e.textContent=user&&active?'شرکت: '+active.name:'');
 $('#companyManagement').hidden=!user||!companyState.canManage;
 $('#companyLoginGuide').textContent=user?'این حساب فقط برای شرکت فعال ساخته می‌شود. نام ورود بدون ابهام: '+companyState.id+'/نام‌کاربری':'';
 $('#companyList').innerHTML=user&&companyState.canManage?(companyState.companies||[]).map(c=>`<div class="company-row"><div><b>${esc(c.name)}</b><small>شماره شرکت ${fmt(c.id)}${c.id===companyState.id?' · شرکت فعال':''}</small></div><div><button class="btn small white" type="button" data-company-enter="${c.id}" ${c.id===companyState.id?'disabled':''}>ورود به پنل</button><button class="btn small white" type="button" data-company-rename="${c.id}">ویرایش نام</button></div></div>`).join(''):'';
 document.querySelectorAll('[data-company-enter]').forEach(b=>b.addEventListener('click',()=>switchCompany(Number(b.dataset.companyEnter))));
 document.querySelectorAll('[data-company-rename]').forEach(b=>b.addEventListener('click',async()=>{const c=companyState.companies.find(c=>c.id===Number(b.dataset.companyRename));const name=prompt('نام شرکت',c.name);if(name===null||name.trim()===c.name)return;try{await api('/api/companies/'+c.id,{method:'PUT',body:{name}});toast('نام شرکت ذخیره شد.')}catch(e){toast(e.message,true)}}));
}
globalThis.installCompanyContext=function(data){companyState.id=data.active_id;companyState.companies=data.companies;companyState.canManage=data.can_manage;renderCompanyContext()};
for(const brand of document.querySelectorAll('.report-brand,.records-print-header')){const span=document.createElement('span');span.className='company-name-print';brand.append(span)}
let companySwitching=false;
async function switchCompany(id){
 if(companySwitching||id===companyState.id){renderCompanyContext();return}
 if(companyState.pendingWrites){renderCompanyContext();toast('عملیات ثبت در حال انجام است؛ پس از پایان آن شرکت را تغییر دهید.',true);return}
 const pending=!!document.querySelector('dialog[open] form,form[data-company-dirty="true"]');
 if(pending&&!confirm('فرم یا پیش‌نمایش باز دارید. با تغییر شرکت، موارد ذخیره‌نشده و پیش‌نمایش‌ها کنار گذاشته می‌شوند. ادامه می‌دهید؟')){renderCompanyContext();return}
 companySwitching=true;$('#companyPicker').disabled=true;
 try{
  const d=await api('/api/companies/switch',{method:'POST',body:{company_id:id}});
  companyState.epoch++;csrf=d.csrf;user=null;clearPrivateData();document.querySelectorAll('form').forEach(f=>{f.reset();delete f.dataset.companyDirty});document.querySelectorAll('input[type=file]').forEach(i=>i.value='');$('#appView').hidden=true;
  // A full reload also discards charts, print buffers, modal contents and delayed callbacks.
  location.reload();
 }catch(e){toast(e.message,true);companySwitching=false;$('#companyPicker').disabled=false;renderCompanyContext()}
}
$('#companyPicker').addEventListener('change',e=>switchCompany(Number(e.target.value)));
$('#companyForm').addEventListener('submit',async e=>{e.preventDefault();const button=e.target.querySelector('[type=submit]');button.disabled=true;$('#companyError').textContent='';try{await api('/api/companies',{method:'POST',body:{name:e.target.elements.name.value}});e.target.reset();delete e.target.dataset.companyDirty;toast('شرکت تعریف شد؛ از فهرست بالا یا «ورود به پنل» وارد آن شوید.')}catch(error){$('#companyError').textContent=error.message}finally{button.disabled=false}});
document.addEventListener('input',e=>{const f=e.target.closest('form');if(f&&f.id!=='loginForm')f.dataset.companyDirty='true'});
document.addEventListener('submit',e=>{if(e.target.tagName==='FORM')delete e.target.dataset.companyDirty});
// Direct template links must use the tab's company header too, not another tab's last choice.
document.addEventListener('click',async e=>{const link=e.target.closest('a[href^="/api/"]');if(!link||!user||e.defaultPrevented)return;e.preventDefault();const epoch=companyState.epoch;try{const res=await api(link.getAttribute('href')),blob=await res.blob();if(epoch!==companyState.epoch||!user)return;const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(res.headers.get('Content-Disposition')?.match(/filename="([^"]+)"/)||[])[1]||'BEHNOVA-Template.xlsx';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}catch(err){toast(err.message,true)}});
const previousCompanyEnter=enter;enter=async function(){await previousCompanyEnter();renderCompanyContext()};
const previousCompanyClear=clearPrivateData;clearPrivateData=function(){previousCompanyClear();if(!user){companyState.epoch++;companyState.id=0;companyState.companies=[];companyState.canManage=false;globalThis.BehnovaCompanyBootstrap=null}renderCompanyContext();$('#companyForm').reset();$('#companyError').textContent=''};
if(globalThis.BehnovaCompanyBootstrap)globalThis.installCompanyContext(globalThis.BehnovaCompanyBootstrap);
