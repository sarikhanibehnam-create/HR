/* Accessible checkbox filters: OR within a filter, AND between filters. */
(()=>{
 const instances=new Map();const safe=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function closeAll(except){instances.forEach(w=>{if(w!==except){w.panel.hidden=true;w.button.setAttribute('aria-expanded','false')}})}
 function install(select,placeholder){
  if(instances.has(select.id))return instances.get(select.id);
  if(select.parentElement.tagName==='LABEL'){const old=select.parentElement,field=document.createElement('div');field.className='filter-field';while(old.firstChild)field.append(old.firstChild);old.replaceWith(field)}
  select.multiple=true;select.classList.add('native-multi');select.tabIndex=-1;select.setAttribute('aria-hidden','true');
  const caption=select.parentElement.firstChild.textContent.trim();const wrap=document.createElement('div');wrap.className='multi-select';wrap.dataset.for=select.id;
  wrap.innerHTML=`<button type="button" class="multi-trigger" aria-expanded="false" aria-controls="${select.id}-choices"><span></span><span aria-hidden="true">⌄</span></button><div class="multi-popover" id="${select.id}-choices" hidden><input class="multi-search" type="search" placeholder="جست‌وجوی گزینه‌ها…" aria-label="جست‌وجو در گزینه‌ها"><div class="multi-actions"><button type="button" data-all>انتخاب همه</button><button type="button" data-clear>پاک کردن</button></div><div class="multi-options" role="group" aria-label="${safe(placeholder)}"></div><div class="multi-hint">چند گزینه را هم‌زمان علامت بزنید.</div></div>`;
  select.after(wrap);const button=wrap.querySelector('.multi-trigger'),panel=wrap.querySelector('.multi-popover'),search=wrap.querySelector('.multi-search'),choices=wrap.querySelector('.multi-options');
  const widget={button,panel,refresh};instances.set(select.id,widget);
  function values(){return [...select.options].filter(o=>o.value)}
  function update(){const selected=values().filter(o=>o.selected);button.firstElementChild.textContent=selected.length===0?placeholder:selected.length===1?selected[0].textContent:new Intl.NumberFormat('fa-IR').format(selected.length)+' گزینه انتخاب‌شده';button.setAttribute('aria-label',caption+'؛ '+button.firstElementChild.textContent);button.title=selected.map(o=>o.textContent).join('، ')||placeholder;button.classList.toggle('has-selection',selected.length>0)}
  function refresh(){choices.innerHTML=values().map(o=>`<label class="multi-option"><input type="checkbox" value="${safe(o.value)}" ${o.selected?'checked':''}><span>${safe(o.textContent)}</span></label>`).join('');search.value='';update()}
  choices.addEventListener('change',e=>{if(e.target.type!=='checkbox')return;const option=values().find(o=>o.value===e.target.value);if(option)option.selected=e.target.checked;update();select.dispatchEvent(new Event('change',{bubbles:true}))});
  button.addEventListener('click',()=>{const opening=panel.hidden;closeAll(widget);panel.hidden=!opening;button.setAttribute('aria-expanded',String(opening));if(opening)search.focus()});
  search.addEventListener('input',()=>{const q=search.value.trim().toLocaleLowerCase('fa');choices.querySelectorAll('.multi-option').forEach(label=>label.hidden=!label.textContent.toLocaleLowerCase('fa').includes(q))});
  wrap.querySelector('[data-all]').addEventListener('click',()=>{choices.querySelectorAll('.multi-option:not([hidden]) input').forEach(c=>{c.checked=true;const o=values().find(o=>o.value===c.value);if(o)o.selected=true});update();select.dispatchEvent(new Event('change',{bubbles:true}))});
  wrap.querySelector('[data-clear]').addEventListener('click',()=>{values().forEach(o=>o.selected=false);choices.querySelectorAll('input').forEach(c=>c.checked=false);update();select.dispatchEvent(new Event('change',{bubbles:true}))});
  select.addEventListener('change',()=>{choices.querySelectorAll('input').forEach(c=>c.checked=!!values().find(o=>o.value===c.value)?.selected);update()});refresh();return widget;
 }
 document.addEventListener('click',e=>{if(!e.target.closest('.multi-select'))closeAll()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){const open=[...instances.values()].find(w=>!w.panel.hidden);closeAll();open?.button.focus()}});
 window.FilterMulti={install,refresh:id=>instances.get(id)?.refresh(),close:()=>closeAll()};
})();