'use strict';
// Release numbers are publication constants, not installation/start counters.
(()=>{
 const UI_RELEASE=6,htmlRelease=Number(document.querySelector('meta[name="behnova-release"]')?.content||0);
 const tabs=[...document.querySelectorAll('[data-settings-tab]')];
 let active='companies',requestId=0,checking=false;
 function allowed(){return {companies:!!user&&!!globalThis.BehnovaCompany?.canManage,users:user?.role==='admin',structure:hasPermission('catalog.manage'),fields:hasPermission('fields.manage'),security:!!user,server:user?.role==='admin'}}
 function select(key,focus=false){const access=allowed();if(!access[key])return;active=key;for(const tab of tabs){const current=tab.dataset.settingsTab===key;tab.setAttribute('aria-selected',String(current));tab.tabIndex=current?0:-1;document.querySelector('[data-settings-group="'+tab.dataset.settingsTab+'"]').hidden=!current}if(focus)document.querySelector('[data-settings-tab="'+key+'"]').focus()}
 function refreshAccess(){const access=allowed();for(const tab of tabs){const key=tab.dataset.settingsTab;tab.hidden=!access[key];if(!access[key])document.querySelector('[data-settings-group="'+key+'"]').hidden=true}if(!access[active])active=tabs.find(t=>access[t.dataset.settingsTab])?.dataset.settingsTab;if(active)select(active);$('#serverBackupPanel').hidden=!access.server}
 tabs.forEach(tab=>{tab.addEventListener('click',()=>select(tab.dataset.settingsTab));tab.addEventListener('keydown',e=>{const visible=tabs.filter(t=>!t.hidden);let i=visible.indexOf(tab);if(e.key==='ArrowLeft')i++;else if(e.key==='ArrowRight')i--;else if(e.key==='Home')i=0;else if(e.key==='End')i=visible.length-1;else return;e.preventDefault();select(visible[(i+visible.length)%visible.length].dataset.settingsTab,true)})});
 function showStatus(kind,text){$('#releaseSummaryState').textContent=text;$('#releaseSummaryState').dataset.state=kind;$('#releaseWarning').hidden=kind!=='warning';$('#releaseWarning').textContent=kind==='warning'?text:''}
 async function checkRelease(){
  if(!user||checking)return;
  checking=true;const id=++requestId;$('#checkRelease').disabled=true;
  showStatus('pending','در حال بررسی همخوانی…');
  try{
   const data=await api('/api/release');if(id!==requestId||!user)return;
   const server=data.server_serial,installed=data.installed_serial;
   
   if(Array.isArray(data.changes)){$('#releaseChanges').replaceChildren(...data.changes.map(text=>{const li=document.createElement('li');li.textContent=String(text);return li}))}
   if(UI_RELEASE!==htmlRelease||server!==UI_RELEASE||installed!==UI_RELEASE||data.integrity!=='ok'||data.restart_required){
    const issues=Array.isArray(data.issues)?data.issues.join(' '):'';
    showStatus('warning','فایل‌های برنامه همخوان نیستند؛ جایگزینی کامل فایل‌ها، توقف و اجرای مجدد سرور و تازه‌سازی مرورگر با Ctrl+F5 را بررسی کنید.'+(issues?' '+issues:''));
   }else showStatus('ok','همخوان — رابط، سرور و فایل‌های نصب بررسی شدند.');
  }catch(error){
   if(id!==requestId||!user)return;
   
   showStatus('warning',error.status===404?'امکان بررسی نسخه در این سرور وجود ندارد؛ ممکن است سرور قدیمی یا فایل‌ها ناقص باشند. همخوانی تأیید نشد؛ بسته را کامل جایگزین، سرور را متوقف و دوباره اجرا و مرورگر را تازه‌سازی کنید.':'همخوانی تأیید نشد؛ ارتباط با سرور یا پاسخ بررسی نسخه مشکل دارد. '+error.message);
  }finally{if(id===requestId){checking=false;$('#checkRelease').disabled=false}}
 }
 $('#checkRelease').addEventListener('click',checkRelease);
 const beforeLoad=loadSettings;loadSettings=async function(){await beforeLoad();refreshAccess();await checkRelease()};
 const beforeEnter=enter;enter=async function(){await beforeEnter();refreshAccess();await checkRelease()};
 const beforeClear=clearPrivateData;clearPrivateData=function(){beforeClear();requestId++;checking=false;$('#checkRelease').disabled=false;active='companies';refreshAccess();showStatus('pending','همخوانی هنوز بررسی نشده')};
 globalThis.BehnovaSettings={refreshAccess,select,checkRelease,uiRelease:UI_RELEASE};
 refreshAccess();if(user)checkRelease();
 // Detect disk replacement while the Settings page remains open; never claim cached success.
 setInterval(()=>{if(user&&page==='settings'&&!document.hidden)checkRelease()},30000);
 document.addEventListener('visibilitychange',()=>{if(user&&page==='settings'&&!document.hidden)checkRelease()});
})();