'use strict';
// Presentation only: never rewrite saved text, codes or identity matching.
window.TableSort=(()=>{
 const states=new Map(),callbacks=new Map(),alphabet='اآبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی';
 const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const fold=v=>String(v??'').normalize('NFKC').toLowerCase().replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/آ/g,'ا').replace(/[۰-۹٠-٩]/g,d=>String(d.charCodeAt(0)-(d>='۰'&&d<='۹'?0x06f0:0x0660))).replace(/[\p{M}\s\u061c\u0640\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]/gu,'');
 // Fixed Persian natural alphabet shared with the offline Python sorter.
 function natural(v){return (fold(v).match(/\d+|\D+/g)||[]).map(p=>/^\d+$/.test(p)?[0,p.replace(/^0+(?=\d)/,'')]:[1,[...p].map(c=>alphabet.includes(c)?100+alphabet.indexOf(c):1000+c.codePointAt(0))])}
 function decimal(value){const text=fold(value),m=text.match(/^([+-]?)(\d+)(?:\.(\d+))?$/);if(!m)return null;const integer=m[2].replace(/^0+(?=\d)/,''),fraction=(m[3]||'').replace(/0+$/,'');return {decimal:true,negative:m[1]==='-'&&(integer!=='0'||!!fraction),integer,fraction}}
 function compare(a,b){
  if(a?.decimal&&b?.decimal){if(a.negative!==b.negative)return a.negative?-1:1;let c=a.integer.length-b.integer.length;if(!c&&a.integer!==b.integer)c=a.integer<b.integer?-1:1;const n=Math.max(a.fraction.length,b.fraction.length),x=a.fraction.padEnd(n,'0'),y=b.fraction.padEnd(n,'0');if(!c&&x!==y)c=x<y?-1:1;return a.negative?-c:c}
  if(typeof a==='number'&&typeof b==='number')return a-b;
  const x=natural(a),y=natural(b);
  for(let i=0;i<Math.min(x.length,y.length);i++){
   if(x[i][0]!==y[i][0])return x[i][0]-y[i][0];
   if(x[i][0]===0){const p=x[i][1],q=y[i][1];if(p.length!==q.length)return p.length-q.length;if(p!==q)return p<q?-1:1}
   else{const p=x[i][1],q=y[i][1];for(let j=0;j<Math.min(p.length,q.length);j++)if(p[j]!==q[j])return p[j]-q[j];if(p.length!==q.length)return p.length-q.length}
  }return x.length-y.length;
 }
 const missing=v=>v===null||v===undefined||v===''||(typeof v==='number'&&!Number.isFinite(v));
 function sort(scope,rows,get=(r,k)=>r[k]){const s=states.get(scope);if(!s)return [...rows];return rows.map((row,index)=>({row,index})).sort((a,b)=>{const av=get(a.row,s.key),bv=get(b.row,s.key),am=missing(av),bm=missing(bv);if(am||bm)return am===bm?(Number(a.row.id)-Number(b.row.id)||a.index-b.index):am?1:-1;return (s.dir==='desc'?-1:1)*compare(av,bv)||(Number(a.row.id)-Number(b.row.id)||a.index-b.index)}).map(v=>v.row)}
 function header(scope,key,label){const s=states.get(scope),active=s?.key===key,direction=active?s.dir==='desc'?'descending':'ascending':'none';return `<th aria-sort="${direction}"><button type="button" class="table-sort-button" data-sort-scope="${escape(scope)}" data-sort-key="${escape(key)}" title="مرتب‌سازی صعودی / نزولی">${escape(label)}<span class="table-sort-arrow" aria-hidden="true">${active?(s.dir==='desc'?' ↓':' ↑'):' ↕'}</span></button></th>`}
 function set(scope,key,dir='asc'){states.set(scope,{key,dir:dir==='desc'?'desc':'asc'})}
 document.addEventListener('click',async e=>{const button=e.target.closest('[data-sort-scope]');if(!button)return;const scope=button.dataset.sortScope,key=button.dataset.sortKey,old=states.get(scope);set(scope,key,old?.key===key&&old.dir==='asc'?'desc':'asc');try{await callbacks.get(scope)?.()}catch(error){if(typeof toast==='function')toast(error.message,true)}});
 function dateValue(value){const text=fold(value),m=text.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);return m?Number(m[1])*10000+Number(m[2])*100+Number(m[3]):text||null}
 return {header,sort,compare,fold,dateValue,decimal,get:scope=>states.get(scope),set,clear:scope=>scope?states.delete(scope):states.clear(),register:(scope,fn)=>callbacks.set(scope,fn)};
})();
