"""Operator-only local stop. Does not run or import the application/database."""
import os,sys,traceback
from pathlib import Path
from server_lifecycle import stop_server
BASE=Path(__file__).resolve().parent.parent
DATA=Path(os.environ.get('BEHNOVA_DATA_DIR',str(BASE/'data'))).resolve()
def show(text,error=False):
 if os.name=='nt':
  import ctypes
  ctypes.windll.user32.MessageBoxW(None,text,'BEHNOVA — توقف سرور',(0x10 if error else 0x40)|0x100000|0x10000)
 else:print(text)
if __name__=='__main__':
 try:show(stop_server(DATA))
 except Exception as e:show('توقف کامل تأیید نشد: '+str(e)+'\nهیچ پردازشی به‌اجبار بسته و هیچ اطلاعاتی حذف نشد. فعلاً پوشه را حذف نکنید.',True);sys.exit(1)
