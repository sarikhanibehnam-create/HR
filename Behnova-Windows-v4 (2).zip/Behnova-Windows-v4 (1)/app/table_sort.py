"""Read-only deterministic Persian/natural ordering; no locale/dependency install needed."""
import re
from functools import cmp_to_key
from decimal import Decimal,InvalidOperation
from text_search import search_key
ALPHABET='اآبپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی'
def natural(value):
 text=search_key(value).replace('آ','ا')
 return tuple((0,int(p)) if p.isdigit() else (1,tuple(100+ALPHABET.index(c) if c in ALPHABET else 1000+ord(c) for c in p)) for p in re.findall(r'\d+|\D+',text))
def decimal(value):
 try:
  n=Decimal(str(value));return n if n.is_finite() else None
 except (ValueError,InvalidOperation):return None
def date_key(value):
 text=search_key(value);m=re.fullmatch(r'(\d{4})[-/](\d{1,2})[-/](\d{1,2})',text)
 return tuple(map(int,m.groups())) if m else natural(text)
def ordered(rows,get,descending=False):
 def compare(a,b):
  x,y=get(a),get(b);xm=x is None or x=='';ym=y is None or y==''
  if xm or ym:return (1 if xm else -1) if xm!=ym else 0
  value=(x>y)-(x<y);return -value if descending else value
 # Stable, deterministic tie-break, independent of the direction and pagination.
 return sorted(sorted(rows,key=lambda r:r.get('id',0)),key=cmp_to_key(compare))
def records(rows,kind,p,spec):
 key=p.get('sort','');direction=p.get('direction','asc')
 if not key:return rows
 fields={f['key']:f for f in spec['fields']}
 if key not in {'employee_name','employee_code','approval','id'}|set(fields) or direction not in ['asc','desc']:raise ValueError('مرتب‌سازی سوابق نامعتبر است.')
 def get(row):
  if key=='id':return row['id']
  if key=='approval':return natural('تأیید شده' if row['approved_at'] else 'در انتظار تأیید') if kind in ['merits','education','career'] else None
  if key in ['employee_name','employee_code']:return natural(row[key]) if row.get(key) else None
  field=fields[key];value=row['payload'].get(key)
  if value is None or value=='':return None
  if field['type'] in ['money','decimal']:return decimal(value)
  if field['type']=='date':return date_key(value)
  if field['type']=='select':value=next((c['label'] for c in field.get('choices',[]) if c['value']==value),value)
  return natural(value)
 return ordered(rows,get,direction=='desc')
