"""Read-only search folding, never for persisted values, identifiers or access rules."""
import unicodedata
_TRANSLATION=str.maketrans({'ي':'ی','ى':'ی','ك':'ک',**dict(zip('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))})
_IGNORED={'\u061c','\u0640','\ufeff'}|{chr(n) for lo,hi in [(0x200b,0x200f),(0x202a,0x202e),(0x2060,0x206f)] for n in range(lo,hi+1)}
def search_key(value):
 text=unicodedata.normalize('NFKC',str(value) if value is not None else '').lower().translate(_TRANSLATION)
 return ''.join(ch for ch in text if not ch.isspace() and ch not in _IGNORED and not unicodedata.category(ch).startswith('M'))
