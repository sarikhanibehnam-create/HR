"""Single company-scoped workbook; atomic nine-section import with encrypted previews.
Preview executes the exact write plan inside a rolled-back SAVEPOINT, allowing records
for employees first introduced in this workbook. Commit rechecks whole-data revision,
schema, session, permissions, scope and revalidates every row in ONE transaction.
"""
import base64,hashlib,io,json,secrets,time,zipfile
from datetime import date,datetime
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.comments import Comment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName
from fastapi import Request,HTTPException
from company_context import current_app as A
from excel_rows import sparse_rows,has_value
from import_workflow import ImportProblem,parse_excel,make_plan,page_of
from security_core import token_hash
import access_control as ac
import workforce,personnel_records as pr,record_import as ri,vehicle_import as vi,choice_settings

SHEETS={'employees':'کارکنان','children':'فرزندان','merits':'امتیازها','welfare':'رفاهی','training':'آموزش','education':'ارتقای تحصیلی','career':'ارتقای شغلی','vehicle':'خودرو','hardship':'سخت و زیان‌آور'}
REFERENCES={'راهنما','نمونه‌ها','گزینه‌ها','شرکت','شرح گزارش','وضعیت همکاری'}
ALIASES={'پرسنل':'employees','درخواست خودرو':'vehicle',**{v:k for k,v in SHEETS.items()}}
EXAMPLES={
 'employees':{'code':'000001','name':'آرمان نمونه','_first_name':'آرمان','_last_name':'نمونه','department':'واحد نمونه','location':'محل نمونه','hire_date':'1402/01/01'},
 'children':{'code':'000001','name':'فرزند نمونه','birth_date':'1398/02/01','allowance':'yes','insurance':'no'},
 'merits':{'code':'000001','type':'reward','title':'پیشنهاد بهبود فرایند','reason':'کاهش دوباره‌کاری — صرفاً مثال آموزشی','event_date':'1403/01/15','points':'5'},
 'welfare':{'code':'000001','category':'هدیه مناسبتی','reason':'صرفاً مثال آموزشی','amount':'2500000','event_date':'1403/01/15'},
 'training':{'code':'000001','title':'آموزش ایمنی','start_date':'1403/01/01','end_date':'1403/01/02','hours':'8','status':'completed'},
 'education':{'code':'000001','degree':'کارشناسی','major':'مدیریت','event_date':'1403/02/01'},
 'career':{'code':'000001','target':'org_position','title':'کارشناس ارشد','event_date':'1403/02/01'},
 'vehicle':{'code':'000001','request_date':'1403/02/01','vehicle_type':'خودروی نمونه','status':'waiting'},
 'hardship':{'code':'000001','status':'pending','request_date':'1403/02/01'},
}

def init_storage(c):
 c.execute('CREATE TABLE IF NOT EXISTS unified_excel_previews(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,session_id TEXT NOT NULL,expires REAL NOT NULL,payload BLOB NOT NULL)')
 c.execute('DELETE FROM unified_excel_previews WHERE expires<?',(time.time(),))

def can_import(u,k):
 if k=='employees':return ac.can(u,'import.create') or ac.can(u,'import.update')
 return ac.can(u,'records.'+k+'.read') and (ac.can(u,'records.'+k+'.import_create') or ac.can(u,'records.'+k+'.import_update'))
def require_import(u):
 if not any(can_import(u,k) for k in SHEETS):raise HTTPException(403,'هیچ مجوز ورود Excel برای این حساب فعال نیست.')
def export_allowed(u,k):
 return ac.can(u,'export.excel') and (ac.can(u,'employees.read') if k=='employees' else ac.can(u,'records.'+k+'.read') and ac.can(u,'records.'+k+'.export'))
def columns(c,k,ids=True):
 if k=='employees':return [('code','کد پرسنلی')]+([('name','نام و نام خانوادگی')] if ids else [('_first_name','نام'),('_last_name','نام خانوادگی')])+[(key,label) for key,label in A.current_schema(c)['fields'] if key not in ['code','name']]
 cols=vi.HEADERS if k=='vehicle' else ri.headers(c,k)
 return list(cols) if ids else [(a,b) for a,b in cols if a!='record_id']
def fs(c,k):return [] if k=='employees' else pr.KINDS[k]['fields'] if k=='vehicle' else ri.fields(c,k)
def display(c,k,key,v):
 if v is None:return ''
 dates=A.current_schema(c)['dates'] if k=='employees' else [f['key'] for f in fs(c,k) if f['type']=='date']
 if key in dates and v:return str(v) if '/' in str(v) else A.fa_date(date.fromisoformat(str(v)))
 field=next((f for f in fs(c,k) if f['key']==key),{})
 return next((x['label'] for x in field.get('choices',[]) if str(x['value'])==str(v)),v)
def example_values(c,k):
 value=dict(EXAMPLES[k])
 if k=='employees':
  schema=A.current_schema(c)
  value.update(gender='مرد',birth_date='1370/01/01',major='مدیریت',position='کارشناس نمونه',manager='مدیر نمونه',cost_center='001',children='1',dependents='1',job_code='00010',job='شغل نمونه',org_position_title='عنوان سمت نمونه',org_position='سمت نمونه',insurance_number='0012345678',education_history='شرح سوابق تحصیلی نمونه',field_of_study_title='عنوان رشته نمونه')
  for key,opts in schema['options'].items():
   if opts and value.get(key) not in opts:value[key]=opts[0]
  for f in schema['defs']:
   if f['kind']=='select':value[f['key']]=f['options'][0]
   elif f['kind']=='number':value[f['key']]='1'
   elif f['kind']=='date':value[f['key']]='1403/01/01'
   else:value[f['key']]='متن نمونه'
 elif k=='education':
  opts=A.current_schema(c)['options']['education']
  if opts and value['degree'] not in opts:value['degree']=opts[0]
 return value

def header_comment(c,k,key,label,definition=None):
 """Examples live on headers, never in importable data rows; use current tenant schema."""
 definition=definition or {};schema=A.current_schema(c) if k=='employees' else None
 custom=next((f for f in schema['defs'] if f['key']==key),{}) if schema else {}
 date_keys=schema['dates'] if schema else [f['key'] for f in fs(c,k) if f['type']=='date']
 opts=[str(v['label']) for v in definition.get('choices',[])]
 ex=example_values(c,k).get(key,'')
 if not ex:
  if key in date_keys:ex='1403/01/15'
  elif key in ['children','dependents']:ex='1'
  elif custom.get('kind')=='number':ex='12.5'
  else:ex={'note':'توضیح نمونه درباره همین سابقه','provider':'مرکز آموزش نمونه','certificate':'CERT-001','override_reason':'علت مستند تغییر امتیاز نسبت به الگو'}.get(key,'متن نمونه')
 if opts:
  ex=str(display(c,k,key,ex))
  if ex not in opts:ex=opts[0]
 else:ex=str(display(c,k,key,ex))
 required=bool(definition.get('required') or key in ['code','name','_first_name','_last_name'] and k=='employees' or key=='code')
 lines=[label,'وضعیت: '+('الزامی' if required else 'اختیاری')]
 if key=='record_id':
  lines += ['مثال برای سابقه جدید: خالی','برای ویرایش، شناسه واقعی همین ردیف را از خروجی جامع نگه دارید؛ شناسه را حدس نزنید یا از ردیف دیگری کپی نکنید.']
 elif key=='template_id':
  row=c.execute('SELECT id FROM personnel_point_templates WHERE active=1 ORDER BY id LIMIT 1').fetchone()
  lines += ['مثال: '+(str(row[0])+' — شناسه یک الگوی فعال فعلی' if row else 'خالی — الگویی لازم نیست'),'فقط شناسه الگوی واقعی سازمان را وارد کنید؛ امتیاز و نوع باید با الگو سازگار باشند. تغییر امتیاز نسبت به الگو علت می‌خواهد.']
 else:lines += ['مثال: '+ex]
 if opts:lines += ['گزینه‌های مجاز فعلی: '+' / '.join(opts),'از فهرست کشویی همین ستون انتخاب کنید؛ مقدار ناشناخته خودکار ساخته یا تطبیق داده نمی‌شود.']
 if key=='code':lines += ['نوع: Text؛ مثال 000123. صفرهای اول را حفظ کنید.','در شیت کارکنان، کد موجود برای ویرایش همان شخص است؛ در سوابق، کد شخص را دقیقاً تکرار کنید. تغییر کد، تغییر شناسه شخص است.']
 elif key in ['job_code','insurance_number','cost_center']:lines += ['به صورت متن وارد کنید؛ صفرهای اول و املای شناسه را حفظ کنید.']
 if key in date_keys:
  lines += ['تاریخ شمسی به صورت متن سال/ماه/روز؛ مانند 1403/01/15. از فرمول و تاریخ خودکار Excel استفاده نکنید.']
  if not required:lines += ['اگر تاریخ مشخص نیست، خالی بگذارید؛ تاریخ را حدس نزنید.']
 if k=='employees' and key in A.SETTLEMENT_KEYS:lines += ['این مرحله تسویه مستقل است؛ مقدار سایر مراحل یا وضعیت همکاری را خودکار تغییر نمی‌دهد.']
 if k=='merits':
  if key=='type':lines += ['تشویق برای امتیاز مثبت و تنبیه برای امتیاز منفی است.']
  elif key=='title':lines += ['عنوان، نام کوتاه رویداد است؛ علت و توضیح رویداد در ستون علت نوشته می‌شود.']
  elif key=='reason':lines += ['علت، توضیح دلیل تشویق یا تنبیه است؛ با عنوان کوتاه رویداد تفاوت دارد.']
  elif key=='points':lines += ['مثال تشویق: 5؛ مثال تنبیه: -2. عدد صفر مجاز نیست.','اعداد فقط آموزشی‌اند، نه امتیاز ثابت یا مقررات سازمان. تأیید امتیاز مرحله جداگانه است.']
 if k=='welfare' and key=='amount':lines += ['مبلغ مثبت، عدد صحیح به ریال و بدون جداکننده هزارگان؛ مثلاً 2500000. تبدیل خودکار تومان انجام نمی‌شود.']
 if k=='training' and key=='hours':lines += ['مدت مثبت به ساعت؛ مثال 8 یا 1.5، بدون جداکننده هزارگان.']
 if k=='training' and key in ['status','end_date']:lines += ['برای وضعیت گذرانده، تاریخ پایان الزامی است و نباید قبل از تاریخ شروع باشد.']
 if k=='children' and key in ['allowance','insurance']:lines += ['حق اولاد و بیمه تکمیلی مستقل‌اند؛ ثبت این سابقه شمارنده‌های عمومی پرونده را خودکار تغییر نمی‌دهد.']
 if k=='vehicle' and key in ['status','delivery_date']:lines += ['تاریخ تحویل واقعی فقط در وضعیت تحویل شده ثبت می‌شود و در همان وضعیت الزامی است.']
 if k=='hardship' and key in ['status','request_date','result_date']:lines += ['وضعیت و تاریخ‌ها باید سازگار باشند؛ تاریخ تاریخی نامعلوم را حدس نزنید.']
 if k in ['education','career']:lines += ['ثبت سابقه خودکار تأیید یا روی پرونده اعمال نمی‌شود؛ ارتقای اعمال‌شده فقط بدون تغییر قابل ورود مجدد است.']
 if custom:lines += ['نوع فیلد دلخواه: '+{'text':'متن','number':'عدد','date':'تاریخ شمسی','select':'فهرست گزینه‌ها'}[custom['kind']]]
 if k=='employees' and key in ['children','dependents']:lines += ['عدد صحیح از صفر تا 50.']
 if key not in ['record_id','code'] and not required:lines += ['در ویرایش: حذف ستون، مقدار قبلی را نگه می‌دارد؛ خانه خالی در ستون موجود ممکن است مقدار را پاک کند.']
 lines += ['این مثال فقط راهنمای ستون است و خودکار وارد بانک نمی‌شود.']
 comment=Comment('\n'.join(lines),'BEHNOVA');comment.width=420;comment.height=min(520,max(210,30*len(lines)))
 return comment

def state(c):
 h=hashlib.sha256()
 for name in ['employees','personnel_records','personnel_point_templates','master_items','employment_periods','custom_fields','choice_entries','choice_aliases']:
  h.update(name.encode())
  for row in c.execute('SELECT * FROM '+name+' ORDER BY rowid'):
   h.update(json.dumps(list(row),ensure_ascii=False,default=lambda b:b.hex(),separators=(',',':')).encode())
 h.update(ri.revision(c).encode());return h.hexdigest()

def workbook(c,u,export=False):
 w=openpyxl.Workbook();w.properties.creator='BEHNOVA';guide=w.active;guide.title='راهنما'
 notes=['BEHNOVA — یک فایل برای ورود همه بخش‌ها','هر شیت اصلی فقط مربوط به همان بخش است. شیت‌های خالی تغییری ایجاد نمی‌کنند.','مثال و راهنمای هر فیلد در کامنت سرستون همان ستون است؛ روی نشانه قرمز سرستون مکث کنید یا در Excel گزینه نمایش Note/Comment را بزنید. مثال‌ها خودکار وارد بانک نمی‌شوند.','کد پرسنلی Text است؛ صفرهای اول را حفظ کنید. کارکنان جدید و سوابق آنها می‌توانند در همین یک ورود ثبت شوند.','برای ویرایش بعدی، خروجی جامع برنامه را دریافت و شناسه‌های خودکار را بدون تغییر نگه دارید. ردیف سابقه جدید شناسه خالی دارد.','نمونه فایل ثبت جدید شناسه ندارد. پس از ثبت، فایل اولیه بی‌شناسه را با ردیف‌های قبلی دوباره وارد نکنید؛ از خروجی جامع استفاده کنید.','کد پرسنلی = شناسه شخص؛ شناسه سابقه = شناسه یک رویداد از چند رویداد همان شخص.','نبود یک ردیف به معنی حذف آن نیست. ستون حذف‌شده مقدار قبلی را حفظ می‌کند؛ خانه خالی در ستون موجود می‌تواند مقدار را پاک کند.','تمام شیت‌ها یکجا پیش‌نمایش می‌شوند و با تأیید صریح، همگی ثبت می‌شوند یا هیچ‌کدام. سقف کل فایل ۵۰۰۰ ردیف واقعی و ۸ مگابایت است.','پیش‌نمایش ۱۰ دقیقه و وابسته به حساب، نشست و شرکت فعال است. تغییر داده‌ها یا تنظیمات نیازمند پیش‌نمایش دوباره است.','ارتقای تحصیلی/شغلی و امتیاز خودکار تأیید یا اعمال نمی‌شوند. ردیف اعمال‌شده فقط بدون تغییر قابل ورود مجدد است.','امتیازدهی: «نوع» تشویق یا تنبیه است؛ «عنوان» نام کوتاه رویداد و «علت» توضیح آن است. تشویق مثبت و تنبیه منفی؛ اعداد مثال مقررات ثابت نیستند.','مبالغ رفاهی ریال است. تاریخ‌ها متن شمسی مثل ۱۴۰۳/۰۱/۰۱ و مدت دوره ساعت است.','فقط بخش‌های مجاز حساب شما در فایل قرار می‌گیرند. ورود و خروجی فقط متعلق به شرکت فعال است.']
 for text in notes:guide.append([text])
 guide.column_dimensions['A'].width=110
 for row in guide:
  guide.row_dimensions[row[0].row].height=44;row[0].alignment=Alignment(wrap_text=True,vertical='center',horizontal='right')
 lists=w.create_sheet('گزینه‌ها');lists.sheet_state='hidden';list_col=0
 employees={row['id']:dict(row) for row in c.execute('SELECT * FROM employees') if ac.within(u,dict(row))}
 for k,title in SHEETS.items():
  if not (export_allowed(u,k) if export else can_import(u,k)):continue
  cols=columns(c,k,ids=export)
  if k=='employees' and not ac.can(u,'settlement.read'):cols=[(key,label) for key,label in cols if key not in A.SETTLEMENT_KEYS]
  s=w.create_sheet(title);s.append([label for _,label in cols]);s.freeze_panes='A2';s.auto_filter.ref=f'A1:{openpyxl.utils.get_column_letter(len(cols))}1'
  defs={f['key']:f for f in fs(c,k)}
  if k=='employees':
   schema=A.current_schema(c)
   defs.update({key:{'choices':[{'label':v} for v in values]} for key,values in schema['options'].items()})
   for f in schema['defs']:defs[f['key']]={'required':f['required'],'choices':[{'label':v} for v in f['options']] if f['kind']=='select' else []}
  for i,(key,label) in enumerate(cols,1):
   s.column_dimensions[openpyxl.utils.get_column_letter(i)].width=27;s.column_dimensions[openpyxl.utils.get_column_letter(i)].number_format='@'
   s.cell(1,i).comment=header_comment(c,k,key,label,defs.get(key,{}))
   for r in range(2,2 if export else 202):s.cell(r,i).number_format='@'
   opts=defs.get(key,{}).get('choices',[])
   if opts:
    list_col+=1;letter=openpyxl.utils.get_column_letter(list_col)
    for j,ch in enumerate(opts,1):lists.cell(j,list_col,str(ch['label'])).data_type='s'
    name='BN_UNIFIED_'+str(list_col);w.defined_names.add(DefinedName(name,attr_text=f"'گزینه‌ها'!${letter}$1:${letter}${len(opts)}"));dv=DataValidation(type='list',formula1='='+name,allow_blank=True);dv.showErrorMessage=True;dv.error='از گزینه‌های مجاز فهرست استفاده کنید.';s.add_data_validation(dv);dv.add(f'{openpyxl.utils.get_column_letter(i)}2:{openpyxl.utils.get_column_letter(i)}5001')
  if export:
   if k=='employees':
    for employee in sorted(employees.values(),key=lambda e:e['code']):
     value=dict(employee)
     s.append([display(c,k,key,value.get(key,'')) for key,_ in cols])
   else:
    for row in c.execute('SELECT * FROM personnel_records WHERE kind=? AND deleted=0 ORDER BY id',(k,)):
     if row['employee_id'] not in employees:continue
     value=pr.dec(row['payload']);value.update(code=employees[row['employee_id']]['code'],record_id=str(row['id']));s.append([display(c,k,key,value.get(key,'')) for key,_ in cols])
  for row in s:
   for cell in row:
    if cell.value is not None:cell.value=str(cell.value);cell.data_type='s';cell.number_format='@'
 for s in w:
  s.sheet_view.rightToLeft=True
  if s.max_row:
   for cell in s[1]:cell.font=Font(name='Tahoma',bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='155F51');cell.alignment=Alignment(horizontal='right',wrap_text=True)
 w.active=0;b=io.BytesIO();w.save(b);return b

def read_parts(raw):
 if len(raw)>8*1024*1024:raise ImportProblem('حجم فایل بیش از ۸ مگابایت است.')
 try:
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   if len(z.infolist())>500 or sum(i.file_size for i in z.infolist())>40*1024*1024:raise ImportProblem('حجم بازشده فایل بیش از حد مجاز است.')
  book=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=False)
 except ImportProblem:raise
 except Exception:raise ImportProblem('فایل معتبر xlsx انتخاب کنید.')
 result={};total=0
 try:
  for name in book.sheetnames:
   if name in REFERENCES:continue
   book.active=book.sheetnames.index(name);iterator=sparse_rows(book)
   try:_,head=next(iterator)
   except StopIteration:continue
   finally:pass
   if max(head)>200:raise ImportProblem('تعداد ستون‌های شیت بیش از حد مجاز است.')
   k=ALIASES.get(name);labels={A.option_key(str(v)) for v in head.values()}
   if not k and name in ['سوابق','Sheet1']:
    anchors={'children':'نام و نام خانوادگی فرزند','merits':'امتیاز مثبت / منفی','welfare':'مبلغ — ریال','training':'مدت دوره — ساعت','education':'مدرک جدید','career':'عنوان سمت جدید','vehicle':'نوع خودرو','hardship':'وضعیت درخواست'}
    matches=[kind for kind,label in anchors.items() if A.option_key(label) in labels]
    if len(matches)==1:k=matches[0]
    elif A.option_key('نام و نام خانوادگی') in labels or {A.option_key('نام'),A.option_key('نام خانوادگی')}<=labels:k='employees'
   rows=[]
   try:
    for line,values in iterator:
     if not any(has_value(v) for v in values.values()):continue
     if not k:raise ImportProblem('نام شیت دارای داده شناخته نشد: '+name)
     if line>20000:raise ImportProblem('ردیف دارای داده بیش از محدوده ۲۰۰۰۰ سطر است؛ فاصله‌های خالی زیاد را حذف کنید.',[name+'، ردیف '+str(line)])
     if any(i not in head for i in values):raise ImportProblem('داده در ستون بدون عنوان وجود دارد.',[name+'، ردیف '+str(line)])
     total+=1
     if total>5000:raise ImportProblem('کل فایل بیش از ۵۰۰۰ ردیف داده دارد.')
     if max(values)>200:raise ImportProblem('ستون خارج از محدوده قالب در شیت '+name)
     for v in values.values():
      if isinstance(v,str) and v.startswith('='):raise ImportProblem('فرمول در داده ورودی مجاز نیست.',[name+'، ردیف '+str(line)])
      if isinstance(v,(date,datetime)):raise ImportProblem('تاریخ را به صورت متن شمسی وارد کنید.',[name+'، ردیف '+str(line)])
     codecol=next((i for i,v in head.items() if A.option_key(str(v))==A.option_key('کد پرسنلی')),None)
     if codecol and has_value(values.get(codecol)) and not isinstance(values[codecol],str):raise ImportProblem('کد پرسنلی باید Text باشد تا صفر اول حفظ شود.',[name+'، ردیف '+str(line)])
     rows.append((line,values))
   finally:iterator.close()
   if not rows:continue
   if k in result:raise ImportProblem('بخش '+SHEETS[k]+' در دو شیت تکرار شده است.')
   if max(head)>200:raise ImportProblem('تعداد ستون‌های شیت بیش از حد مجاز است.')
   w=openpyxl.Workbook();s=w.active;s.title=SHEETS[k]
   for i,v in head.items():s.cell(1,i,v)
   for line,values in rows:
    for i,v in values.items():s.cell(line,i,v)
   b=io.BytesIO();w.save(b);result[k]=base64.b64encode(b.getvalue()).decode()
  if not result:raise ImportProblem('هیچ ردیف داده‌ای در شیت‌های اصلی وجود ندارد؛ مثال‌های کامنتِ سرستون فقط راهنما هستند.')
  return result
 finally:book.close()

def approved_unchanged(c,u,k,parsed,present):
 """Allow round-tripping applied promotions but never rewriting an applied event."""
 normal=[];unchanged=[]
 for entry in parsed:
  ident=entry['value']['record_id'];row=c.execute('SELECT * FROM personnel_records WHERE id=?',(ident,)).fetchone() if ident else None
  if not row or not row['approved_at']:normal.append(entry);continue
  old,employee=pr.get_record(c,u,ident,'read')
  if old['kind']!=k or employee['code']!=entry['value']['code']:raise HTTPException(403,'شناسه ارتقا به شخص یا بخش مجاز تعلق ندارد.')
  pr.require(u,k,'import_update');value=pr.dec(old['payload'])
  for f in fs(c,k):
   key=f['key']
   if key not in present:continue
   incoming=entry['value'].get(key,'');expected=display(c,k,key,value.get(key,''))
   if f['type']=='date':equal=A.parse_date(incoming)==str(value.get(key,'') or '')
   else:equal=str(incoming)==str(expected) or str(incoming)==str(value.get(key,'') or '')
   if not equal:raise ImportProblem('ارتقای اعمال‌شده قابل تغییر نیست؛ رویداد اصلاحی جدید ثبت کنید.',[SHEETS[k]+'، ردیف '+str(entry['line'])],409)
  unchanged.append(dict(line=entry['line'],code=employee['code'],name=employee['name'],record_id=ident,status='unchanged',changes=[]))
 return normal,unchanged

def execute(c,u,parts):
 groups=[];schema=A.current_schema(c);section_errors=[];unknown=[];statuses=[]
 for k in parts:
  if not can_import(u,k):raise HTTPException(403,'مجوز ورود بخش '+SHEETS[k]+' فعال نیست؛ هیچ شیتی ثبت نشد.')
 if 'employees' in parts:
  if not can_import(u,'employees'):raise HTTPException(403,'مجوز ورود کارکنان فعال نیست.')
  raw=base64.b64decode(parts['employees'])
  def validate(data):
   old=c.execute('SELECT * FROM employees WHERE code=?',(str(data.get('code') or '').strip(),)).fetchone()
   if old and not ac.within(u,dict(old)):raise HTTPException(403,'پرونده خارج از محدوده مجاز است.')
   merged=dict(old) if old else {};merged.update(data)
   try:return A.employee_values(merged,schema,importing=True)
   except choice_settings.UnknownChoice as error:
    item=choice_settings.unknown_payload(error)
    if item not in unknown and len(unknown)<100:unknown.append(item)
    raise
  def employee_columns(h):
   cols,split=A.import_columns(h,schema);known={i for i,k in cols}
   for i,v in enumerate(h):
    if has_value(v) and i not in known:raise ImportProblem('ستون ناشناخته در کارکنان: '+str(v))
   return cols,split
  try:parsed,present=parse_excel(raw,employee_columns,A.imported_name,validate,schema['dates'])
  except ImportProblem as error:
   error.args=('کارکنان — '+str(error),);error.unknown_choices=unknown;raise
  p=make_plan(c,parsed,present,'upsert',schema['keys'],schema['fields'],set(schema['keys'])-{'name'});p['date_keys']=schema['dates']
  for item in p['records']:
   v=item['value'];old=c.execute('SELECT * FROM employees WHERE code=?',(v['code'],)).fetchone();old=dict(old) if old else None
   workforce.check_employee_values(u,old,v,creating=item['status']=='new',importing=True)
   for definition in schema['defs']:A.value_for(v[definition['key']],definition,A.parse_date,A.option_key)
   if item['status']=='new':c.execute(f"INSERT INTO employees(id,{','.join(schema['keys'])}) VALUES(?,{','.join('?' for _ in schema['keys'])})",[workforce.reserve_id(c)]+[v[key] for key in schema['keys']])
   elif item['status']=='update':c.execute(f"UPDATE employees SET {','.join(key+'=?' for key in schema['keys'])},version=version+1 WHERE code=?",[v[key] for key in schema['keys']]+[v['code']])
   if item['status']!='unchanged':workforce.capture(c,u['id'],'ورود جامع Excel — '+item['status'],old,dict(c.execute('SELECT * FROM employees WHERE code=?',(v['code'],)).fetchone()))
  groups.append(('employees',p))
 for k in SHEETS:
  if k=='employees' or k not in parts:continue
  if not can_import(u,k):raise HTTPException(403,'مجوز ورود بخش '+SHEETS[k]+' فعال نیست؛ هیچ شیتی ثبت نشد.')
  try:
   parsed,present=vi.parse(base64.b64decode(parts[k]),columns(c,k),[SHEETS[k]])
   extra=[]
   if k in ['education','career']:parsed,extra=approved_unchanged(c,u,k,parsed,present)
   p=vi.plan(c,u,parsed,present,'mixed') if k=='vehicle' else ri.plan(c,u,k,parsed,present,'mixed')
   # Duplicate IDs remain forbidden, including applied rows which were prefiltered.
   allids=[e['value']['record_id'] for e in parsed if e['value']['record_id']]+[e['record_id'] for e in extra]
   if len(allids)!=len(set(allids)):raise ImportProblem('شناسه سابقه تکراری در '+SHEETS[k])
   p['items']+=extra;p['counts']['total']+=len(extra);p['counts']['unchanged']+=len(extra)
   now=A.tehran_now().isoformat(timespec='seconds')
   for item in p['records']:
    if item['status']=='unchanged':continue
    event=item['value'].get(pr.KINDS[k]['date_key'],'')
    if item['id']:
     ident=item['id'];c.execute('UPDATE personnel_records SET payload=?,event_date=?,version=version+1,approved_at="",approved_by=NULL,updated_at=? WHERE id=?',(pr.enc(item['value']),event,now,ident))
    else:
     ident=c.execute('INSERT INTO personnel_records(employee_id,kind,event_date,payload,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(item['employee_id'],k,event,pr.enc(item['value']),u['id'],now,now)).lastrowid
    row=dict(c.execute('SELECT * FROM personnel_records WHERE id=?',(ident,)).fetchone());pr.history(c,u,row,'ورود جامع Excel — '+item['status'],item['before'],item['value'])
   groups.append((k,p))
  except ImportProblem as error:
   section_errors += [SHEETS[k]+' — '+str(error)]+[SHEETS[k]+' — '+str(v) for v in error.errors];statuses.append(error.status)
   for item in getattr(error,'unknown_choices',[]):
    if item not in unknown and len(unknown)<100:unknown.append(item)
 if section_errors:
  error=ImportProblem('خطا در شیت‌های ورودی؛ هیچ شیتی ثبت نشد.',section_errors[:60],400 if 400 in statuses else statuses[0]);error.unknown_choices=unknown;raise error
 A.sync_catalog(c)
 result={'items':[],'counts':dict(total=0,added=0,updated=0,unchanged=0,cleared_values=0),'sections':[],'date_keys':sorted(set(schema['dates'])|{f['key'] for k in pr.KINDS for f in fs(c,k) if f['type']=='date'})}
 for k,p in groups:
  result['sections'].append(dict(key=k,label=SHEETS[k],**p['counts']))
  for key in result['counts']:result['counts'][key]+=p['counts'][key]
  result['items'] += [dict(item,section=SHEETS[k]) for item in p['items']]
 return result

def owned(c,request,token):
 if not isinstance(token,str) or not 20<=len(token)<=100:raise ImportProblem('پیش‌نمایش معتبر نیست.',status=409)
 row=c.execute('SELECT * FROM unified_excel_previews WHERE token_hash=? AND user_id=? AND session_id=? AND expires>?',(token_hash(token),request.session['uid'],token_hash(request.session['sid']),time.time())).fetchone()
 if not row:raise ImportProblem('پیش‌نمایش منقضی، ثبت یا لغو شده یا متعلق به این نشست و شرکت نیست.',status=409)
 return pr.dec(row['payload'])

def register(module):
 app=module.app
 @app.get('/api/excel/template')
 async def template(request:Request):
  u=await A.require_user(request);require_import(u)
  with A.db() as c:return A.excel_response(workbook(c,u),'BEHNOVA-Unified-Input.xlsx')
 @app.get('/api/excel/export')
 async def export(request:Request):
  u=await A.require_user(request)
  if not any(export_allowed(u,k) for k in SHEETS):raise HTTPException(403,'مجوز خروجی جامع فعال نیست.')
  with A.db() as c:
   A.audit(request,c,'خروجی جامع Excel برای ویرایش');return A.excel_response(workbook(c,u,True),'BEHNOVA-Unified-Edit.xlsx')
 @app.post('/api/excel/preview')
 async def preview(request:Request):
  u=await A.require_user(request);require_import(u);form=await request.form();file=form.get('file')
  if not file or not str(getattr(file,'filename','')).lower().endswith('.xlsx'):raise HTTPException(400,'فایل xlsx انتخاب کنید.')
  try:
   parts=read_parts(await file.read());token=secrets.token_urlsafe(32)
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request);require_import(u);baseline=state(c)
    c.execute('SAVEPOINT unified_preview')
    try:plan=execute(c,u,parts)
    finally:c.execute('ROLLBACK TO unified_preview');c.execute('RELEASE unified_preview')
    c.execute('DELETE FROM unified_excel_previews WHERE expires<? OR (user_id=? AND session_id=?)',(time.time(),u['id'],token_hash(request.session['sid'])))
    if c.execute('SELECT COUNT(*) FROM unified_excel_previews').fetchone()[0]>=8:raise ImportProblem('پیش‌نمایش‌های فعال زیادند؛ چند دقیقه دیگر تلاش کنید.',status=429)
    payload=dict(parts=parts,baseline=baseline,plan=plan)
    c.execute('INSERT INTO unified_excel_previews VALUES(?,?,?,?,?)',(token_hash(token),u['id'],token_hash(request.session['sid']),time.time()+600,pr.enc(payload)))
   return dict(preview_token=token,expires_in=600,sections=plan['sections'],**page_of(plan))
  except ImportProblem as e:return A.json_response(error=str(e),errors=e.errors,unknown_choices=getattr(e,'unknown_choices',[]) if u['role']=='admin' else [],_status=e.status)
  except ValueError as e:raise HTTPException(400,str(e))
 @app.get('/api/excel/preview/{token}')
 async def page(request:Request,token:str,page:int=1):
  await A.require_user(request)
  try:
   with A.db() as c:p=owned(c,request,token)['plan']
   return dict(sections=p['sections'],**page_of(p,page))
  except ImportProblem as e:return A.json_response(error=str(e),_status=e.status)
 @app.delete('/api/excel/preview/{token}')
 async def cancel(request:Request,token:str):
  await A.require_user(request)
  try:
   with A.db() as c:owned(c,request,token);c.execute('DELETE FROM unified_excel_previews WHERE token_hash=?',(token_hash(token),))
   return dict(ok=True)
  except ImportProblem as e:return A.json_response(error=str(e),_status=e.status)
 @app.post('/api/excel/commit')
 async def commit(request:Request):
  await A.require_user(request);body=await A.json_data(request)
  if body.get('confirm') is not True:raise HTTPException(400,'تأیید صریح همه شیت‌ها لازم است.')
  try:
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request);require_import(u);p=owned(c,request,body.get('token'))
    if p['baseline']!=state(c):raise ImportProblem('داده‌ها یا تنظیمات پس از پیش‌نمایش تغییر کرده؛ هیچ شیتی ثبت نشد. فایل را دوباره بررسی کنید.',status=409)
    plan=execute(c,u,p['parts']);A.audit(request,c,'ثبت یکپارچه تمام شیت‌های Excel با تأیید',json.dumps(plan['counts']));c.execute('DELETE FROM unified_excel_previews WHERE token_hash=?',(token_hash(body['token']),))
   return dict(ok=True,sections=plan['sections'],**plan['counts'])
  except ImportProblem as e:return A.json_response(error=str(e),errors=e.errors,_status=e.status)
  except ValueError as e:raise HTTPException(400,str(e))
