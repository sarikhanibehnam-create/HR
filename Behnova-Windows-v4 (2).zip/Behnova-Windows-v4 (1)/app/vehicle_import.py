"""Two-phase, session-bound XLSX import for repeatable vehicle requests only."""
import io,json,time,secrets,hashlib,zipfile,re
from datetime import date,datetime
import openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from fastapi import Request,HTTPException
from excel_rows import sparse_rows,has_value
from import_workflow import ImportProblem,page_of
from security_core import token_hash
import access_control as ac
import personnel_records as pr
from company_context import current_app as A
HEADERS=[('code','کد پرسنلی'),('record_id','شناسه درخواست'),('request_date','تاریخ درخواست'),('vehicle_type','نوع خودرو'),('status','وضعیت'),('delivery_date','تاریخ تحویل واقعی'),('note','توضیحات')]
LABELS=dict(HEADERS)
for action,label in [('import_create','افزودن گروهی درخواست خودرو از Excel'),('import_update','به‌روزرسانی گروهی درخواست خودرو از Excel')]:ac.PERMISSIONS['records.vehicle.'+action]=label

def init_storage(c):
 c.execute('CREATE TABLE IF NOT EXISTS vehicle_import_previews(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,session_id TEXT NOT NULL,expires REAL NOT NULL,payload BLOB NOT NULL)')
 c.execute('DELETE FROM vehicle_import_previews WHERE expires<?',(time.time(),))
def importer(u):
 pr.require(u,'vehicle','read')
 if not (ac.can(u,'records.vehicle.import_create') or ac.can(u,'records.vehicle.import_update')):raise HTTPException(403,'مجوز ورود گروهی خودرو فعال نیست.')

def template():
 w=openpyxl.Workbook();w.properties.creator='BEHNOVA';s=w.active;s.title='درخواست خودرو';s.sheet_view.rightToLeft=True;s.append([label for key,label in HEADERS if key!='record_id'])
 for cell in s[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='155F51')
 for col in range(1,7):
  s.column_dimensions[openpyxl.utils.get_column_letter(col)].width=27
  for row in range(2,202):s.cell(row,col).number_format='@'
 dv=DataValidation(type='list',formula1='"درخواست شده,در انتظار,تحویل شده,لغو شده"',allow_blank=True);dv.errorTitle='وضعیت نامعتبر';dv.error='یکی از وضعیت‌های فهرست را انتخاب کنید.';dv.showErrorMessage=True;dv.errorStyle='stop';s.add_data_validation(dv);dv.add('D2:D5001');s.freeze_panes='A2'
 guide=w.create_sheet('راهنما');guide.sheet_view.rightToLeft=True
 for text in ['BEHNOVA — ورود گروهی خودرو','هیچ پرسنل یا درخواست نمونه‌ای در این فایل نیست.','این نمونه برای ثبت جدید است: کد پرسنلی متنی، تاریخ درخواست و نوع خودرو لازم است؛ شناسه درخواست را سیستم خودکار می‌سازد.','برای ویرایش، خروجی Excel خودرو را بگیرید، اطلاعات را اصلاح و شناسه خودکار درخواست را بدون تغییر نگه دارید.','حالت ثبت جدید، ویرایش یا ترکیبی را قبل از پیش‌نمایش انتخاب کنید.','ستون موجود ولی خالی، مقدار همان فیلد را پاک می‌کند؛ ستون حذف‌شده از فایل مقدار قبلی را حفظ می‌کند.','برای تغییر فقط نوع خودرو یا تاریخ تحویل، ستون‌های دیگر را از فایل حذف کنید یا با مقدار فعلی پر کنید.','اگر ستون وضعیت در فایل نباشد و تاریخ تحویل واقعی وارد شود، پیشنهاد تغییر وضعیت به تحویل شده در پیش‌نمایش نشان داده می‌شود.','تاریخ‌ها متن شمسی سال/ماه/روز باشند؛ کدها متن بمانند تا صفرهای ابتدایی از بین نروند.','هر شخص می‌تواند چند درخواست داشته باشد؛ ویرایش فقط با شناسه همان درخواست انجام می‌شود.','حداکثر ۵۰۰۰ ردیف واقعی و فایل ۸ مگابایت. قبل از تأیید هیچ درخواست خودرو ثبت نمی‌شود.','اعتبار پیش‌نمایش ۱۰ دقیقه و وابسته به حساب و نشست است. تغییر مرتبط یا دسترسی پس از پیش‌نمایش، ثبت را متوقف می‌کند.']:guide.append([text])
 guide.column_dimensions['A'].width=120
 for row in guide:
  for cell in row:cell.alignment=Alignment(horizontal='right',wrap_text=True);cell.font=Font(name='Tahoma',size=12)
 b=io.BytesIO();w.save(b);return b

def parse(raw,headers=None,sheetnames=None):
 headers=HEADERS if headers is None else headers;labels=dict(headers)
 if len(raw)>8*1024*1024:raise ImportProblem('حجم فایل بیش از ۸ مگابایت است.')
 try:
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   if sum(i.file_size for i in z.infolist())>40*1024*1024:raise ImportProblem('حجم بازشده فایل بیش از حد مجاز است.')
  book=openpyxl.load_workbook(io.BytesIO(raw),read_only=True,data_only=False)
 except ImportProblem:raise
 except Exception:raise ImportProblem('فایل معتبر xlsx انتخاب کنید.')
 iterator=None
 try:
  for name in (sheetnames or ['درخواست خودرو','سوابق']):
   if name in book.sheetnames:book.active=book.sheetnames.index(name);break
  iterator=sparse_rows(book);_,head=next(iterator)
  aliases={A.option_key(label):key for key,label in headers}
  aliases.update({A.option_key(k):k for k,_ in headers})
  for alias,key in [('شناسه درخواست خودرو','record_id'),('شناسه سابقه','record_id'),('تاریخ تحویل','delivery_date'),('کد کارمند','code')]:
   if key in labels:aliases[A.option_key(alias)]=key
  ignored={A.option_key(v) for v in ['نام و نام خانوادگی','واحد','محل','وضعیت تأیید','تاریخ تأیید']}
  columns={};seen=set()
  for col,v in head.items():
   key=aliases.get(A.option_key(str(v or '')))
   if key:
    if key in seen:raise ImportProblem('ستون تکراری: '+labels[key])
    seen.add(key);columns[col]=key
   elif has_value(v) and A.option_key(str(v)) not in ignored:raise ImportProblem('ستون ناشناخته: '+str(v)[:100])
  if 'code' not in seen:raise ImportProblem('ستون کد پرسنلی لازم است.')
  result=[]
  for line,values in iterator:
   d={key:values.get(col) for col,key in columns.items()}
   if not any(has_value(v) for v in d.values()):continue
   if len(result)>=5000:raise ImportProblem('حداکثر ۵۰۰۰ ردیف واقعی در هر فایل مجاز است.')
   for k,v in list(d.items()):
    if isinstance(v,str) and v.startswith('='):raise ImportProblem('فرمول در فایل ورودی مجاز نیست.',[f'ردیف {line}: {labels[k]}'])
    if v is None:d[k]=''
    elif isinstance(v,(date,datetime)):
     if v.year>=1500:raise ImportProblem('تاریخ را به‌صورت متن شمسی وارد کنید.',[f'ردیف {line}: {labels[k]}'])
     d[k]=v.strftime('%Y/%m/%d')
    elif not isinstance(v,(str,int,float)) or isinstance(v,bool):raise ImportProblem('مقدار نامعتبر در فایل.',[f'ردیف {line}: {labels[k]}'])
    elif k=='code' and not isinstance(v,str):raise ImportProblem('کد پرسنلی باید متن باشد؛ ستون را در Excel به Text تبدیل کنید.',[f'ردیف {line}'])
    else:d[k]=str(int(v)) if isinstance(v,float) and v.is_integer() else str(v).strip()
   if not d['code'] or len(d['code'])>180:raise ImportProblem('کد پرسنلی معتبر لازم است.',[f'ردیف {line}'])
   ident=d.get('record_id','').translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
   if ident and (not re.fullmatch(r'[1-9][0-9]{0,17}',ident)):raise ImportProblem('شناسه باید عدد صحیح مثبت باشد.',[f'ردیف {line}'])
   d['record_id']=int(ident) if ident else None;result.append(dict(line=line,value=d))
  if not result:raise ImportProblem('فایل ردیف اطلاعات ندارد.')
  return result,seen
 except StopIteration:raise ImportProblem('فایل خالی است.')
 except ImportProblem:raise
 except Exception:raise ImportProblem('فایل اکسل قابل خواندن نیست؛ از نمونه فایل ورودی استفاده کنید.')
 finally:
  if iterator is not None:iterator.close()
  book.close()

def duplicate(c,employee_id,value,exclude=None):
 for r in c.execute('SELECT id,payload FROM personnel_records WHERE employee_id=? AND kind="vehicle" AND deleted=0 AND event_date=?',(employee_id,value['request_date'])):
  if r['id']!=exclude and pr.dec(r['payload'])['vehicle_type']==value['vehicle_type']:return True
 return False

def plan(c,u,parsed,present,mode):
 if mode not in ['new','update','mixed']:raise ImportProblem('حالت ورود نامعتبر است.')
 result=dict(records=[],items=[],counts=dict(total=len(parsed),added=0,updated=0,unchanged=0,cleared_values=0),date_keys=['request_date','delivery_date'])
 ids=set();new_keys=set();errors=[]
 status_choices=pr.KINDS['vehicle']['fields'][2]['choices'];statuses={A.option_key(o['label']):o['value'] for o in status_choices}|{A.option_key(o['value']):o['value'] for o in status_choices}
 statuses[A.option_key('تحویل گرفته شده')]='delivered'
 for entry in parsed:
  line=entry['line'];d=entry['value'];ident=d['record_id']
  try:
   if mode=='new' and ident or mode=='update' and not ident:raise ValueError('شناسه درخواست با حالت انتخاب‌شده سازگار نیست.')
   pr.require(u,'vehicle','import_update' if ident else 'import_create')
   employee=c.execute('SELECT * FROM employees WHERE code=?',(d['code'],)).fetchone()
   if not employee or not ac.within(u,dict(employee)):raise HTTPException(403,'کد پرسنلی پیدا نشد یا در محدوده مجاز نیست.')
   employee=dict(employee);old=None
   if ident:
    if ident in ids:raise ValueError('شناسه درخواست در فایل تکراری است.')
    ids.add(ident);r=c.execute('SELECT * FROM personnel_records WHERE id=?',(ident,)).fetchone()
    if not r or r['kind']!='vehicle' or r['deleted'] or r['employee_id']!=employee['id']:raise HTTPException(403,'شناسه درخواست با پرسنل مجاز این ردیف تطبیق ندارد.')
    old=dict(r);base=pr.dec(old['payload'])
   else:base=dict(request_date='',vehicle_type='',status='requested',delivery_date='',note='')
   value=dict(base)
   for key in base:
    if key in present:value[key]=d.get(key,'')
   for key in ['request_date','delivery_date']:
    if key in present and A.option_key(value[key])==A.option_key('ثبت نشده'):value[key]=''
   if 'status' in present:
    value['status']=statuses.get(A.option_key(value['status']))
    if not value['status']:raise ValueError('وضعیت خودرو نامعتبر یا خالی است.')
   elif value['delivery_date'] and 'delivery_date' in present:value['status']='delivered'
   for key in ['request_date','delivery_date']:
    if key not in present and value.get(key):value[key]=A.fa_date(date.fromisoformat(value[key]))
   value=pr.normalize('vehicle',value,c,employee)
   if not ident:
    key=(employee['id'],value['request_date'],value['vehicle_type'])
    if key in new_keys or duplicate(c,employee['id'],value):raise ImportProblem('درخواست مشابه موجود یا در فایل تکرار شده است؛ برای ویرایش شناسه درخواست را وارد کنید.',[f'ردیف {line}'],409)
    new_keys.add(key)
   changes=[dict(field=k,label=LABELS[k],before=base.get(k,'') if old else '',after=v,cleared=bool(old and base.get(k) and not v)) for k,v in value.items() if (old and base.get(k)!=v) or (not old and v)]
   state='new' if not ident else 'update' if changes else 'unchanged'
   result['counts'][{'new':'added','update':'updated','unchanged':'unchanged'}[state]]+=1;result['counts']['cleared_values']+=sum(x['cleared'] for x in changes)
   result['records'].append(dict(id=ident,employee_id=employee['id'],employee_version=employee['version'],code=employee['code'],version=old['version'] if old else None,before=base if old else None,value=value,status=state))
   result['items'].append(dict(line=line,code=employee['code'],name=employee['name'],record_id=ident,status=state,changes=changes))
  except ImportProblem:raise
  except ValueError as error:errors.append(f'ردیف {line}: {error}')
 if errors:raise ImportProblem('هیچ درخواست خودرویی ذخیره نشد؛ خطاها را اصلاح کنید.',errors[:30])
 return result

def owned(c,request,token):
 if not isinstance(token,str) or not 20<=len(token)<=200:raise ImportProblem('پیش‌نمایش معتبر نیست.',status=404)
 row=c.execute('SELECT * FROM vehicle_import_previews WHERE token_hash=? AND user_id=? AND session_id=?',(token_hash(token),request.session['uid'],token_hash(request.session['sid']))).fetchone()
 if not row:raise ImportProblem('پیش‌نمایش متعلق به این نشست نیست، لغو یا ثبت شده است.',status=404)
 if row['expires']<time.time():raise ImportProblem('اعتبار پیش‌نمایش تمام شده؛ فایل را دوباره بررسی کنید.',status=410)
 return pr.dec(row['payload'])

def register(module):
 app=module.app
 @app.get('/api/vehicle-import/template')
 async def download_template(request:Request):
  u=await A.require_user(request);importer(u);return A.excel_response(template(),'BEHNOVA-Vehicle-Input.xlsx')
 @app.post('/api/vehicle-import/preview')
 async def preview(request:Request):
  u=await A.require_user(request);importer(u);form=await request.form();file=form.get('file')
  if not file or not str(getattr(file,'filename','')).lower().endswith('.xlsx'):raise HTTPException(400,'فایل xlsx انتخاب کنید.')
  try:
   parsed,present=parse(await file.read());token=secrets.token_urlsafe(32)
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request);importer(u);p=plan(c,u,parsed,present,form.get('mode','new'));c.execute('DELETE FROM vehicle_import_previews WHERE expires<?',(time.time(),))
    prior=c.execute('SELECT token_hash FROM vehicle_import_previews WHERE user_id=? ORDER BY expires DESC',(u['id'],)).fetchall()
    for r in prior[1:]:c.execute('DELETE FROM vehicle_import_previews WHERE token_hash=?',(r[0],))
    if c.execute('SELECT COUNT(*) FROM vehicle_import_previews').fetchone()[0]>=8:raise ImportProblem('پیش‌نمایش‌های فعال زیادند؛ قبلی‌ها را لغو کنید.',status=429)
    c.execute('INSERT INTO vehicle_import_previews VALUES(?,?,?,?,?)',(token_hash(token),u['id'],token_hash(request.session['sid']),time.time()+600,pr.enc(p)))
   return dict(preview_token=token,expires_in=600,**page_of(p))
  except ImportProblem as e:return A.json_response(error=str(e),errors=e.errors,_status=e.status)
  except ValueError as e:raise HTTPException(400,str(e))
 @app.get('/api/vehicle-import/preview/{token}')
 async def preview_page(request:Request,token:str,page:int=1):
  u=await A.require_user(request);importer(u)
  try:
   with A.db() as c:return page_of(owned(c,request,token),page)
  except ImportProblem as e:return A.json_response(error=str(e),_status=e.status)
 @app.delete('/api/vehicle-import/preview/{token}')
 async def cancel(request:Request,token:str):
  u=await A.require_user(request);importer(u)
  with A.db() as c:c.execute('DELETE FROM vehicle_import_previews WHERE token_hash=? AND user_id=? AND session_id=?',(token_hash(token),u['id'],token_hash(request.session['sid'])))
  return dict(ok=True)
 @app.post('/api/vehicle-import/commit')
 async def commit(request:Request):
  u=await A.require_user(request);importer(u);body=await A.json_data(request)
  if body.get('confirm') is not True:raise HTTPException(400,'تأیید صریح پیش‌نمایش لازم است.')
  try:
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');u=A.transaction_user(c,request);importer(u);p=owned(c,request,body.get('token'))
    for item in p['records']:
     pr.require(u,'vehicle','import_update' if item['id'] else 'import_create');employee=pr.scoped_employee(c,u,item['employee_id'])
     if employee['code']!=item['code'] or employee['version']!=item['employee_version']:raise ImportProblem('اطلاعات پرسنل پس از پیش‌نمایش تغییر کرده؛ هیچ ردیفی ثبت نشد.',status=409)
     if item['id']:
      old=c.execute('SELECT * FROM personnel_records WHERE id=?',(item['id'],)).fetchone()
      if not old or old['kind']!='vehicle' or old['deleted'] or old['employee_id']!=item['employee_id'] or old['version']!=item['version']:raise ImportProblem('درخواست پس از پیش‌نمایش تغییر کرده؛ فایل را دوباره بررسی کنید.',status=409)
     elif duplicate(c,item['employee_id'],item['value']):raise ImportProblem('درخواست مشابه پس از پیش‌نمایش ایجاد شده؛ هیچ ردیفی ثبت نشد.',status=409)
    now=A.tehran_now().isoformat(timespec='seconds')
    for item in p['records']:
     if item['status']=='unchanged':continue
     if item['id']:
      ident=item['id'];c.execute('UPDATE personnel_records SET payload=?,event_date=?,version=version+1,updated_at=? WHERE id=?',(pr.enc(item['value']),item['value']['request_date'],now,ident))
     else:
      cur=c.execute('INSERT INTO personnel_records(employee_id,kind,event_date,payload,created_by,created_at,updated_at) VALUES(?,"vehicle",?,?,?,?,?)',(item['employee_id'],item['value']['request_date'],pr.enc(item['value']),u['id'],now,now));ident=cur.lastrowid
     r=dict(c.execute('SELECT * FROM personnel_records WHERE id=?',(ident,)).fetchone());pr.history(c,u,r,'ورود گروهی خودرو — '+item['status'],item['before'],item['value'])
    c.execute('DELETE FROM vehicle_import_previews WHERE token_hash=?',(token_hash(body['token']),));A.audit(request,c,'ثبت گروهی خودرو با تأیید پیش‌نمایش',json.dumps(p['counts']));return dict(ok=True,**p['counts'])
  except ImportProblem as e:return A.json_response(error=str(e),_status=e.status)
