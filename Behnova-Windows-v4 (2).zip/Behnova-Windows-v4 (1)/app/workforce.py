"""Employment periods, scoped record history, report settings and safe administrator backups."""
import json,io,secrets,hashlib,zipfile,sqlite3,time
from datetime import date
from pathlib import Path
from fastapi import Request,Depends,HTTPException
import access_control as ac
from company_context import current_app as A

def init_storage(c):
 for name,definition in [('permissions',"TEXT NOT NULL DEFAULT ''"),('departments_json',"TEXT NOT NULL DEFAULT '[]'"),('locations_json',"TEXT NOT NULL DEFAULT '[]'"),('disabled','INTEGER NOT NULL DEFAULT 0')]:
  if name not in {r['name'] for r in c.execute('PRAGMA table_info(users)')}:c.execute(f'ALTER TABLE users ADD COLUMN {name} {definition}')
 c.execute("CREATE TABLE IF NOT EXISTS employment_periods(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER NOT NULL REFERENCES employees(id) ON DELETE CASCADE,start_date TEXT NOT NULL DEFAULT '',end_date TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL DEFAULT '',note TEXT NOT NULL DEFAULT '')")
 c.execute('CREATE INDEX IF NOT EXISTS period_employee ON employment_periods(employee_id)')
 c.execute('CREATE TABLE IF NOT EXISTS employee_history(id INTEGER PRIMARY KEY AUTOINCREMENT,employee_id INTEGER NOT NULL,user_id INTEGER,action TEXT NOT NULL,created_at TEXT NOT NULL,before_data BLOB,after_data BLOB)')
 c.execute('CREATE INDEX IF NOT EXISTS history_employee ON employee_history(employee_id,id)')
 c.execute('CREATE TABLE IF NOT EXISTS report_presets(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,name TEXT NOT NULL,spec TEXT NOT NULL,UNIQUE(user_id,name))')
 for row in c.execute('SELECT * FROM employees').fetchall():
  r=dict(row)
  if not c.execute('SELECT 1 FROM employment_periods WHERE employee_id=?',(r['id'],)).fetchone():c.execute('INSERT INTO employment_periods(employee_id,start_date) VALUES(?,?)',(r['id'],r.get('hire_date') or ''))
  if not c.execute('SELECT 1 FROM employee_history WHERE employee_id=?',(r['id'],)).fetchone():capture(c,None,'مبنای اولیه؛ سابقه پیش از فعال‌سازی موجود نیست',None,r)

def reserve_id(c):
 return 1+max(c.execute('SELECT COALESCE(MAX(id),0) FROM employees').fetchone()[0],c.execute('SELECT COALESCE(MAX(employee_id),0) FROM employee_history').fetchone()[0])

def capture(c,user_id,action,before,after):
 row=after or before
 def pack(v):return A.CIPHER.encrypt(json.dumps(v,ensure_ascii=False).encode()) if v is not None else None
 c.execute('INSERT INTO employee_history(employee_id,user_id,action,created_at,before_data,after_data) VALUES(?,?,?,?,?,?)',(row['id'],user_id,action,A.tehran_now().isoformat(timespec='seconds'),pack(before),pack(after)))
 if after and not c.execute('SELECT 1 FROM employment_periods WHERE employee_id=?',(row['id'],)).fetchone():c.execute('INSERT INTO employment_periods(employee_id,start_date) VALUES(?,?)',(row['id'],row.get('hire_date') or ''))
 elif before and after and after.get('hire_date') and before.get('hire_date')!=after.get('hire_date'):
  first=c.execute('SELECT * FROM employment_periods WHERE employee_id=? ORDER BY id LIMIT 1',(row['id'],)).fetchone()
  if first:
   start=after.get('hire_date') or ''
   if first['end_date'] and start and start>=first['end_date']:raise ValueError('تاریخ استخدام باید پیش از اتمام دوره اول همکاری باشد.')
   c.execute('UPDATE employment_periods SET start_date=? WHERE id=?',(start,first['id']))

def active_at(periods,day,historical=True):
 return any((bool(p['start_date']) and p['start_date']<=day or not historical and not p['start_date']) and (not p['end_date'] or day<p['end_date']) for p in periods)

def enrich(rows,c=None):
 if c is None:
  with A.db() as con:return enrich(rows,con)
 periods={}
 for p in c.execute('SELECT * FROM employment_periods ORDER BY id'):periods.setdefault(p['employee_id'],[]).append(dict(p)|{'start_fa':A.fa_date(date.fromisoformat(p['start_date'])) if p['start_date'] else '', 'end_fa':A.fa_date(date.fromisoformat(p['end_date'])) if p['end_date'] else ''})
 today=A.tehran_today().isoformat()
 for row in rows:
  ps=periods.get(row['id'],[]);row['employment_periods']=ps;row['employment_status']='active' if active_at(ps,today,False) else 'ended'
  row['settlement_eligible']=row['employment_status']=='ended' and any(p['end_date'] and p['end_date']<=today for p in ps)
  row['employment_state_label']='در حال همکاری' if row['employment_status']=='active' else 'اتمام همکاری'
  row['employment_start_unknown']=bool(ps and not ps[0]['start_date']);row['employment_end_date']=ps[-1]['end_date'] if ps else ''
 return rows

BASES={'none':'بدون محدودیت زمانی','hire_date':'شروع دوره همکاری','employment_end':'اتمام همکاری','active_at_end':'در حال همکاری در پایان بازه','contract_end':'پایان قرارداد','birth_date':'تاریخ تولد'}

def validate_range(p):
 if not isinstance(p,dict):raise ValueError('ساختار بازه گزارش نامعتبر است.')
 basis=p.get('basis','none');valid=set(BASES)|A.SETTLEMENT_KEYS
 if basis not in valid:raise ValueError('مبنای تاریخ گزارش نامعتبر است.')
 lower=A.parse_date(p.get('from'));upper=A.parse_date(p.get('to'))
 if lower and upper and lower>upper:raise ValueError('شروع بازه نباید بعد از پایان آن باشد.')
 if (lower or upper) and basis=='none':raise ValueError('مبنای تاریخ گزارش را انتخاب کنید.')
 if basis=='active_at_end' and not upper:raise ValueError('برای تعداد در حال همکاری، تاریخ پایان بازه لازم است.')
 return {'basis':basis,'from':lower,'to':upper}

def range_match(row,f):
 if f['basis']=='active_at_end':return active_at(row.get('employment_periods',[]),f['to'],True)
 if not f['from'] and not f['to']:return True
 key=f['basis']
 if key in ['hire_date','employment_end']:values=[p['start_date' if key=='hire_date' else 'end_date'] for p in row.get('employment_periods',[])]
 else:values=[row.get(key+'_iso',row.get(key,''))]
 return any(v and (not f['from'] or v>=f['from']) and (not f['to'] or v<=f['to']) for v in values)

def filter_export(rows,payload):
 f=validate_range(payload.get('report_range',{}));status=payload.get('employment_status','all')
 if status not in ['all','active','ended']:raise ValueError('وضعیت همکاری نامعتبر است.')
 return [r for r in enrich(rows) if (status=='all' or r['employment_status']==status) and range_match(r,f)]

def check_employee_values(u,old,new,creating=False,importing=False):
 if not ac.within(u,new) or old and not ac.within(u,old):raise HTTPException(403,'پرونده خارج از محدوده واحد یا محل مجاز شماست.')
 if importing:ac.require(u,'import.create' if creating else 'import.update')
 for key in A.SETTLEMENT_KEYS:
  if str(new.get(key,'') or '')!=str((old or {}).get(key,'') or ''):ac.require(u,'settlement.pay' if key=='settlement_paid_date' else 'settlement.edit')

def public_schema(schema,u):
 if ac.can(u,'employees.read'):allowed=set(schema['keys'])
 else:allowed={'code','name','department','location'}|A.SETTLEMENT_KEYS
 if not ac.can(u,'settlement.read'):allowed-=A.SETTLEMENT_KEYS
 result=dict(schema);result['fields']=[(k,v) for k,v in schema['fields'] if k in allowed];result['keys']=[k for k in schema['keys'] if k in allowed];result['dates']=[k for k in schema['dates'] if k in allowed];result['defs']=[d for d in schema['defs'] if d['key'] in allowed];result['options']={k:v for k,v in schema['options'].items() if k in allowed}
 return result

def public_rows(rows,u):
 if ac.can(u,'employees.read'):
  if not ac.can(u,'settlement.read'):
   for row in rows:
    for k in A.SETTLEMENT_KEYS:row.pop(k,None);row.pop(k+'_iso',None)
  return rows
 allowed={'id','version','code','name','department','location','employment_status','employment_state_label','settlement_eligible'}|A.SETTLEMENT_KEYS|{k+'_iso' for k in A.SETTLEMENT_KEYS}
 return [{k:v for k,v in row.items() if k in allowed} for row in rows]

def register(module):
 app=module.app
 def permitted(key):
  async def dependency(request:Request):u=await A.require_user(request);ac.require(u,key);return u
  return dependency
 A.permitted=permitted
 @app.get('/api/access/catalog',dependencies=[Depends(A.require_admin)])
 async def catalog():return {'permissions':ac.PERMISSIONS,'presets':ac.PRESETS}
 @app.put('/api/users/{ident}/access',dependencies=[Depends(A.require_admin)])
 async def set_access(request:Request,ident:int):
  p=await A.json_data(request)
  with A.db() as c:
   c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT * FROM users WHERE id=?',(ident,)).fetchone()
   if old is None:raise HTTPException(404,'حساب پیدا نشد.')
   try:role,perms,full,ds,ls,disabled=ac.validate_settings(p,old)
   except ValueError as e:raise HTTPException(400,str(e))
   if old['role']=='admin' and (role!='admin' or disabled) and not c.execute("SELECT 1 FROM users WHERE role='admin' AND disabled=0 AND id<>?",(ident,)).fetchone():raise HTTPException(400,'آخرین مدیر اصلی را نمی‌توان غیرفعال یا از مدیریت خارج کرد.')
   c.execute('UPDATE users SET role=?,permissions=?,scope_all=?,department_scope=?,departments_json=?,locations_json=?,can_export=?,disabled=? WHERE id=?',(role,json.dumps(perms) if perms is not None else old['permissions'],int(full),ds[0] if len(ds)==1 else '',json.dumps(ds,ensure_ascii=False),json.dumps(ls,ensure_ascii=False),int(role=='admin' or (bool(set(perms)&{'export.excel','export.pdf'}) if perms is not None else bool(old['can_export']))),int(disabled),ident))
   c.execute('DELETE FROM sessions WHERE user_id=?',(ident,));c.execute('DELETE FROM import_previews WHERE user_id=?',(ident,));c.execute('DELETE FROM vehicle_import_previews WHERE user_id=?',(ident,));c.execute('DELETE FROM record_import_previews WHERE user_id=?',(ident,));c.execute('DELETE FROM unified_excel_previews WHERE user_id=?',(ident,));A.audit(request,c,'تغییر سطح دسترسی و ابطال نشست‌ها',str(ident))
  return {'ok':True,'relogin_required':True}
 @app.post('/api/workforce/range',dependencies=[Depends(A.require_user)])
 async def report_range(request:Request):
  try:f=validate_range(await A.json_data(request))
  except ValueError as e:raise HTTPException(400,str(e))
  return {**f,'from_fa':A.fa_date(date.fromisoformat(f['from'])) if f['from'] else '', 'to_fa':A.fa_date(date.fromisoformat(f['to'])) if f['to'] else ''}
 @app.get('/api/employees/{ident}/history',dependencies=[Depends(permitted('audit.read'))])
 async def history(request:Request,ident:int):
  u=await A.require_user(request)
  with A.db() as c:
   r=c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone()
   if r is None or not ac.within(u,dict(r)):raise HTTPException(404,'پرونده مجاز پیدا نشد.')
   rows=[]
   for h in c.execute('SELECT h.*,u.name AS actor FROM employee_history h LEFT JOIN users u ON u.id=h.user_id WHERE employee_id=? ORDER BY h.id DESC LIMIT 200',(ident,)):
    def unpack(v):return json.loads(A.CIPHER.decrypt(v)) if v else {}
    b=unpack(h['before_data']);a=unpack(h['after_data']);changes=[]
    for key in set(a)|set(b):
     if key in ['id','version'] or a.get(key)==b.get(key):continue
     if key in A.SETTLEMENT_KEYS and not ac.can(u,'settlement.read'):continue
     def display(value):
      if (key in A.DATE_KEYS or key=='event_date') and isinstance(value,str) and len(value)==10 and '-' in value:
       try:return A.fa_date(date.fromisoformat(value))
       except ValueError:pass
      return value
     changes.append({'key':key,'before':display(b.get(key,'')),'after':display(a.get(key,''))})
    rows.append({'id':h['id'],'action':h['action'],'actor':h['actor'] or 'سیستم','created_at':h['created_at'],'changes':changes})
  return {'rows':rows,'note':'سوابق قبل از فعال‌سازی این قابلیت بازسازی نشده‌اند؛ مبنای اولیه، وضعیت زمان فعال‌سازی است.'}
 @app.post('/api/employees/{ident}/employment',dependencies=[Depends(permitted('employment.manage'))])
 async def employment(request:Request,ident:int):
  u=await A.require_user(request);p=await A.json_data(request)
  try:
   day=A.parse_date(p.get('date'));action=p.get('action');reason=str(p.get('reason','')).strip();note=str(p.get('note','')).strip()
   if not day or day>A.tehran_today().isoformat() or action not in ['end','rehire']:raise ValueError('تاریخ معتبر تا امروز و نوع عملیات لازم است.')
   if len(reason)>180 or len(note)>1000:raise ValueError('توضیحات بیش از حد طولانی است.')
   with A.db() as c:
    c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone()
    if row is None or not ac.within(u,dict(row)):raise HTTPException(404,'پرونده مجاز پیدا نشد.')
    before=dict(row)
    if type(p.get('version')) is not int or p['version']!=before['version']:raise HTTPException(409,'پرونده تغییر کرده است؛ تازه‌سازی کنید.')
    periods=[dict(r) for r in c.execute('SELECT * FROM employment_periods WHERE employee_id=? ORDER BY id',(ident,))];last=periods[-1]
    if action=='end':
     if last['end_date']:raise ValueError('این دوره قبلاً پایان یافته است؛ برای بازگشت، دوره جدید ثبت کنید.')
     if last['start_date'] and day<=last['start_date']:raise ValueError('تاریخ اتمام باید پس از شروع دوره باشد.')
     c.execute('UPDATE employment_periods SET end_date=?,reason=?,note=? WHERE id=?',(day,reason,note,last['id']))
    else:
     if not last['end_date']:raise ValueError('برای فرد در حال همکاری نمی‌توان دوره باز دیگری ساخت.')
     if day<last['end_date']:raise ValueError('شروع همکاری مجدد نباید پیش از اتمام دوره قبلی باشد.')
     c.execute('INSERT INTO employment_periods(employee_id,start_date,note) VALUES(?,?,?)',(ident,day,note))
    c.execute('UPDATE employees SET version=version+1 WHERE id=?',(ident,));after=dict(c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone());capture(c,u['id'],'اتمام همکاری' if action=='end' else 'همکاری مجدد',before,after)
    A.audit(request,c,'اتمام همکاری' if action=='end' else 'همکاری مجدد',before['code']+'؛ '+day+'؛ '+reason)
    # Store event details, independently from current profile values.
    event={'id':ident,'event_date':day,'event_reason':reason,'event_note':note};capture(c,u['id'],'جزئیات تغییر وضعیت همکاری',{'id':ident},event)
   return {'ok':True}
  except ValueError as e:raise HTTPException(400,str(e))
 @app.patch('/api/employees/{ident}/settlement')
 async def edit_settlement(request:Request,ident:int):
  u=await A.require_user(request);ac.require(u,'settlement.read');p=await A.json_data(request)
  if set(p)-A.SETTLEMENT_KEYS-{'version'}:raise HTTPException(400,'این مسیر فقط برای تاریخ‌های تسویه است.')
  with A.db() as c:
   c.execute('BEGIN IMMEDIATE');r=c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone()
   if r is None or not ac.within(u,dict(r)):raise HTTPException(404,'پرونده مجاز پیدا نشد.')
   old=dict(r)
   if type(p.get('version')) is not int or p['version']!=old['version']:raise HTTPException(409,'پرونده تغییر کرده است؛ تازه‌سازی کنید.')
   changes={}
   try:
    for key in A.SETTLEMENT_KEYS&set(p):
     value=A.parse_date(p[key]);ac.require(u,'settlement.pay' if key=='settlement_paid_date' else 'settlement.edit');changes[key]=value
   except ValueError as e:raise HTTPException(400,str(e))
   if not changes:raise HTTPException(400,'تاریخی انتخاب نشده است.')
   c.execute('UPDATE employees SET '+','.join(k+'=?' for k in changes)+',version=version+1 WHERE id=?',list(changes.values())+[ident]);after=dict(c.execute('SELECT * FROM employees WHERE id=?',(ident,)).fetchone());capture(c,u['id'],'ویرایش مراحل تسویه',old,after);A.audit(request,c,'ویرایش مراحل تسویه',old['code'])
  return {'ok':True}
 @app.get('/api/report-presets',dependencies=[Depends(permitted('reports.read'))])
 async def presets(request:Request):
  u=await A.require_user(request)
  with A.db() as c:rows=[{'id':r['id'],'name':r['name'],'spec':json.loads(r['spec'])} for r in c.execute('SELECT * FROM report_presets WHERE user_id=? ORDER BY name',(u['id'],))]
  return {'rows':rows}
 @app.post('/api/report-presets',dependencies=[Depends(permitted('reports.read'))])
 async def save_preset(request:Request):
  u=await A.require_user(request);p=await A.json_data(request);name=p.get('name');spec=p.get('spec')
  if not isinstance(name,str) or not 1<=len(name.strip())<=80 or not isinstance(spec,dict) or len(json.dumps(spec))>20000:raise HTTPException(400,'نام یا تنظیمات گزارش نامعتبر است.')
  if set(spec)-{'groups','metric','title','type','columns','range','filters','status'}:raise HTTPException(400,'تنظیمات ناشناخته است.')
  try:A.validate_spec(spec,A.current_schema()['fields']);validate_range(spec.get('range',{}))
  except ValueError as e:raise HTTPException(400,str(e))
  with A.db() as c:
   if c.execute('SELECT COUNT(*) FROM report_presets WHERE user_id=?',(u['id'],)).fetchone()[0]>=50 and not c.execute('SELECT 1 FROM report_presets WHERE user_id=? AND name=?',(u['id'],name.strip())).fetchone():raise HTTPException(400,'حداکثر ۵۰ گزارش ذخیره‌شده برای هر حساب.')
   c.execute('INSERT INTO report_presets(user_id,name,spec) VALUES(?,?,?) ON CONFLICT(user_id,name) DO UPDATE SET spec=excluded.spec',(u['id'],name.strip(),json.dumps(spec,ensure_ascii=False)));A.audit(request,c,'ذخیره تنظیمات گزارش',name.strip())
  return {'ok':True}
 @app.delete('/api/report-presets/{ident}',dependencies=[Depends(permitted('reports.read'))])
 async def delete_preset(request:Request,ident:int):
  u=await A.require_user(request)
  with A.db() as c:c.execute('DELETE FROM report_presets WHERE id=? AND user_id=?',(ident,u['id']))
  return {'ok':True}
 @app.post('/api/admin/backup',dependencies=[Depends(A.require_admin)])
 async def backup(request:Request):
  u=await A.require_user(request);p=await A.json_data(request)
  if not A.reauthenticate(u,p.get('password','')):raise HTTPException(403,'رمز مدیر نادرست است.')
  import tempfile
  from contextlib import closing
  with tempfile.TemporaryDirectory() as t:
   target=Path(t)/'hr.sqlite3'
   with A.db() as c:
    A.audit(request,c,'دریافت پشتیبان کامل — شامل اطلاعات حساس');c.commit()
    with closing(sqlite3.connect(target)) as dest:
     c.backup(dest);dest.execute('PRAGMA journal_mode=DELETE');dest.commit()
   files={'hr.sqlite3':target.read_bytes(),'security.key':(A.DATA_DIR/'security.key').read_bytes(),'session.key':A.SECRET_PATH.read_bytes()}
   config=A.DATA_DIR/'behnova-server.json'
   if config.exists():files[config.name]=config.read_bytes()
   manifest={k:hashlib.sha256(v).hexdigest() for k,v in files.items()};b=io.BytesIO()
   with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED) as z:
    for k,v in files.items():z.writestr(k,v)
    z.writestr('BACKUP-SHA256.json',json.dumps(manifest))
   return A.Response(b.getvalue(),media_type='application/zip',headers={'Content-Disposition':'attachment; filename="BEHNOVA-Backup.zip"'})
