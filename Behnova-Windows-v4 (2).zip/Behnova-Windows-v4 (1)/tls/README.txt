This folder contains NO certificate or private key.
START-SHARED generates a UNIQUE private LAN CA and server certificate if absent. IT may instead provide server.crt, server.key and ca.crt.
Certificate must cover 127.0.0.1 and the actual LAN IPs; the CA must be trusted by clients.
Do not ignore certificate warnings. Protect the private key with restrictive NTFS ACLs.
IT must trust ONLY the public BEHNOVA-Root-CA.crt on clients and the server. NEVER share private keys or the data/runtime folders. Keep server IP fixed. Use STOP.cmd to stop completely. Read README.html.
